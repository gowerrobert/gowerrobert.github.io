#include <iostream>
using std::ofstream;
#include <string.h>
#include <stdio.h>
#include <sys/time.h>
#include <math.h>
#include <sys/types.h>
#include "function_input.h"
#include <adolc.h>
#include <vector>
#include <iomanip>
#include <adolc.h>

double k_getTime() {
   struct timeval v;
   struct timezone z;
   gettimeofday(&v, &z);
   return ((double)v.tv_sec)+((double)v.tv_usec)/1000000;
}

using namespace std;
#define tagc 1
#define tagf 2
#define tagL 3

void    init_nm(int *n, int *m, int dim);
adouble feval_ad(adouble *x);
void ceval_ad(adouble *x, adouble *c);

// LuksanVlcek1
// begin

#if 0

double *y_d_;
int N_;

int y_index(int i, int j) 
  {
    return j + (N_+2)*i;
  }

double y_d_cont(double x1, double x2)
  {
    return 3. + 5.*(x1*(x1-1.)*x2*(x2-1.));
  }

void    init_nm(int *n, int *m, int dim)
{
    N_ = dim;
    *n = N_;
    *m = N_-2;
}


adouble feval_ad(adouble *x)
{
  // return the value of the objective function
  adouble obj_value = 0.;
  adouble a1, a2;

  for (int i=0; i<N_-1; i++) {
    a1 = x[i]*x[i]-x[i+1];
    a2 = x[i] - 1.;
    obj_value += 100.*a1*a1 + a2*a2;
  }
 
  return obj_value;

}

/***************************************************************************/

void ceval_ad(adouble *x, adouble *c) {

  for (int i=0; i<N_-2; i++) {
    c[i] = 3.*pow(x[i+1],3.) + 2.*x[i+2] - 5.
           + sin(x[i+1]-x[i+2])*sin(x[i+1]+x[i+2]) + 4.*x[i+1]
           - x[i]*exp(x[i]-x[i+1]) - 3.;
  }
}

#endif
// end LuksanVlcek1



// LuksanVlcek5
// begin

#if 1
int N_;

void    init_nm(int *n, int *m, int dim) 
{
    N_ = dim;
    *n = N_+2;
    *m = N_-4;
}


adouble feval_ad(adouble *x)
{
  // return the value of the objective function
  adouble obj_value = 0.;
  adouble b;
  double p = 7.0/3.0;

  for (int i=1; i<=N_; i++) {
    b = (3.-2.*x[i])*x[i] - x[i-1] - x[i+1] + 1.;
    obj_value += pow(fabs(b),p);
  }

  return obj_value;

}

/***************************************************************************/

void ceval_ad(adouble *x, adouble *c) {

  for (int i=0; i<N_-4; i++) {
    c[i] = 8.*x[i+3]*(x[i+3]*x[i+3]-x[i+2])
           - 2.*(1-x[i+3])
           + 4.*(x[i+3]-x[i+4]*x[i+4])
           + x[i+2]*x[i+2]
           - x[i+1]
           + x[i+4]
           - x[i+5]*x[i+5];
  }
}

#endif
// end LuksanVlcek5


FILE    *fp;

int main()
{
  int n, m, dim;
    double *x, *c, *xls, f;
    adouble *xad, *cad, *lad, fad;
    double sig;
    double t_f_1, t_f_2, div_exf, div_cf, div_exL, div_cL;
    size_t tape_stats[STAT_SIZE];
    int output;
    int i, ii, j, k, l;
    int nonl;
    int nnzf, nnzL;

    scanf("%d",&dim);

//     dim = 100;
    init_nm(&n,&m,dim);

    printf(" n %d  m %d\n",n,m);
    x = new double[n];
    xls = new double[n+m+1];
    c = new double[m];

    xad = new adouble[n];
    cad = new adouble[m];
    lad = new adouble[m];


/****************************************************************************/
/*******                function evaluation                   ***************/
/****************************************************************************/

    for(i=0;i<n;i++)
	 x[i] = cos(0.21*i);

    /* Tracing of function f(x) */

    trace_on(tagf);
      for(i=0;i<n;i++)
        xad[i] <<= x[i];

      fad = feval_ad(xad);

      fad >>= f;
    trace_off();

    /* Tracing of function L(x) */

    if (m > 0)
      {
	trace_on(tagL);
	for(i=0;i<n;i++)
	  {
	    xad[i] <<= x[i];
	    xls[i] = x[i];
	  }
	for(i=0;i<m;i++)
	  {
	    lad[i] <<= 1.0;
	    xls[i+n] = 1.0;
	  }
	sig = 1.0;
	xls[n+m] = 1.0;
	
	fad = feval_ad(xad);
	fad *= sig;
	ceval_ad(xad,cad);
	
	for(i=0;i<m;i++)
	  // 	fad = fad + lad[i]*cad[i];
	  fad = fad + lad[i]*cad[i];
	
	fad >>= f;
	
	trace_off();

      }   

    Graph *H;
    Graph *H_pat;
    
    /*Necessary flag for first run            */
    H_pat = NULL;
    H = NULL;
    /* ---------------------------------------*/
    
    t_f_1 = k_getTime();

    Sparsity_pattern( tagf,  &H_pat,  n);

    t_f_2 = k_getTime();

    // H_pat->print();
    // H_pat->print_square(1);       

    div_exf = (t_f_2 - t_f_1); 
    printf("XXX The time needed for exact pattern (target):  %10.6f \n \n", div_exf);

    if (m > 0)
      {
	Graph *HL;
	Graph *HL_pat;
	/*Necessary flag for first run            */
	HL_pat = NULL;
	HL = NULL;
	/* ---------------------------------------*/
	t_f_1 = k_getTime();

	Sparsity_pattern( tagL,  &HL_pat,  n+m);

	t_f_2 = k_getTime();

	div_exf = (t_f_2 - t_f_1); 

	// HL_pat->print();
	// HL_pat->print_square(1);       

	printf("XXX The time needed for exact pattern (target):  %10.6f \n \n", div_exf);

      }
    
return 0;

}


