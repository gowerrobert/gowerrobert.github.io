#include <unistd.h>
#include <ios>
#include <fstream>
#include <stdio.h>
#include <math.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <ctime>
#include "../function_input.h"
#include <iomanip>
#include <adolc/adolc.h>
using namespace std;

int main()
{
  int  N,M;	int i,j,k,nz;
  int tape_num =1;
  cout<<"Dimension?"<<endl;
  cin>>N;
  /* ---------------------------------------*/
  //----------------------------------------*/
  // Variables associated to function calculation and the functions tape!
  /*--------------------------------------------------------------------------*/
  adouble yp;
  double y;
  adouble * xp;
  double * x;
  double * direction;
  x = new double [N]; 
  direction = new double [N]; 
  xp = new adouble [N];
  
  for(j=0; j<N; j++){
    x[j] =   1.0+double(2.0*j);
    direction[j] = 1;
  }
  
  trace_on(tape_num);
  
  for(i=0; i<N ;i++) 
  {
    xp[i] <<= x[i];				  // active independs        //  
  } 
  
  //There's a bunch of function already programmed in Functions folder, just pick one.
  yp = sinquad(xp, N);
  yp >>= y;
  
  trace_off();
  
  /*Preparing for tensor vector calculation*/
  Graph *Td;  // Stores the tensor vector product
  Graph * HG; // Stores the Hessian matrix 
  double * gradient; // Stores the gradient matrix 
  
  HG = NULL; //Necessary flag for first call
  Td= NULL; //Necessary flag for first call
  gradient = NULL; //Necessary flag for first call
  //First Call
  reverse_tensorv( tape_num,  x, &gradient, &HG, &Td,  N, direction,NULL);
  Td->print();
  Td->print_square(1);

  for(j=0; j<N; j++){
    x[j] =   (double)j+0.1;
    direction[j] = (double)j;
  }
  //Repeated calls reusing data structure
  reverse_tensorv( tape_num,  x, &gradient, &HG, &Td,  N, direction,NULL);  
  Td->print();
  Td->print_square(1);
  
  //If you don't want to work with the Graph structure, convert to 
  // standard 3 sparse arrays
  
  nz = Td->nz;
  int *I =NULL, *J = NULL;
  double *val = NULL;
  
  //Convert and Print the sparse 3-array representation 
  int array_size  = Td->to_coordinates_arrays( &I, &J, &val);
  
  //Have a look if you want
  for(i =0; i<array_size; i++)
    cout<< "(i,j,Td[i,j]) ="<<"("<<I[i]<<","<<J[i]<<","<<val[i]<<")"<<endl;
  
  delete [] val;
  delete [] I;
  delete [] J;  //*/
  
  
  delete [] x;
  delete [] xp;
  delete [] direction;
  delete HG;
  delete Td;
  delete [] gradient; //*/
  return 0;
  
}
