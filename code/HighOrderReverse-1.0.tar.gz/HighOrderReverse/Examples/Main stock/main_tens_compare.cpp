#include <unistd.h>
#include <ios>
#include <fstream>
#include <stdio.h>
#include <math.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <ctime>
#include "../function_input.h"
#include <iomanip>
#include <adolc/adolc.h>
using std::ofstream;
using namespace std;

struct pt2func { 
  adouble  (*pt)(adouble *, int);
  string name;
};


void printmat(const char* kette, int n, int m, double** M);
void process_mem_usage(double& vm_usage, double& resident_set);
void compare_hessian_reverse(Graph * HG,   double **H_mat, int N);
void build_Td_ADOLC(int tape_num, double * direction, double *x, Graph * Td_ADOLC,  double ep);
double tape_tensord_time(struct pt2func pt2Func, int tape_num, int N,
			  double * x, adouble *xp, double y, adouble yp, double * direction, bool test_it);
void setup_func_pointer(struct pt2func pt2funcs[]);
#define NUM_FUNCS 19
//


int main()
{
  int  N,M;	int i,j,k,nz;
  int tape_num =1;
  cout<<"Dimension?"<<endl;
  cin>>N;
  /* ---------------------------------------*/
  //----------------------------------------*/
  // Variables associated to function calculation and the functions tape!
  /*--------------------------------------------------------------------------*/
  adouble yp;
  double y;
  adouble * xp;
  double * x;
  double * direction;
  x = new double [N]; 
  direction = new double [N]; 
  xp = new adouble [N];
  
  cout<<"NUM_FUNCS "<<NUM_FUNCS<<endl;
  struct pt2func pt2funcs[NUM_FUNCS];
  setup_func_pointer(pt2funcs);
    
  for(j=0; j<N; j++){
    x[j] =   1.0+sin(double(2.0*j));
    direction[j] = j;
  }

 bool test_it = 1;
 for(i=0; i<NUM_FUNCS-1; i++ ){ //NUM_FUNCS is reserved for tailor tests
  tape_num =i;
  tape_tensord_time( pt2funcs[i],   tape_num, N, x, xp,  y,  yp, direction, test_it);
 }//*/
  cout<<"Finnished tests"<<endl;
   delete [] x;
   delete [] xp;
   return 0;
   
}
double tape_tensord_time( struct pt2func pt2Func, int tape_num, int N,
			  double * x, adouble *xp, double y, adouble yp, double * direction, bool test_it){
  int i,j;
  int getusageout;
  double ep = 1e-9;
  double sec,usec, start, end;
  int test;
  int target;
  struct rusage  ruse;
  Graph *Td;
  Graph * HG;
  Graph * Td_ADOLC;
  double * grad =NULL;
  HG = NULL;
  Td= NULL;
  Td_ADOLC = NULL;
  
  trace_on(tape_num);
  for(i=0; i<N ;i++) 
    xp[i] <<= x[i];				  // active independs        //  
    
  yp = pt2Func.pt(xp, N);
  yp >>= y;
  trace_off();
  clock_t startclock = clock();
  
  reverse_tensorv( tape_num,  x, &grad, &HG, &Td,  N, direction,NULL);
  cout<<pt2Func.name; 
  clock_t endclock = clock();
  double cpu_time = static_cast<double>( endclock - startclock ) /CLOCKS_PER_SEC;
  cout<<"	:"<<cpu_time<<endl;
  //cout<<":	"<<double(Td->count_diagonal())/double(N)<<endl;
  //cout<<"	:"<<(2.0*(double(Td->nz -Td->count_diagonal() ))+Td->count_diagonal())/double(N)<<endl;
  
  if(test_it){
    Td_ADOLC= new Graph (N); 
    build_Td_ADOLC(tape_num, direction,x, Td_ADOLC,  ep);
   /* cout<<"Td"<<endl;   
    Td->print_square(0);
    cout<<"Td_ADOLC"<<endl;
    Td_ADOLC->print(); //*/
    cout<<"Is Td_ADOLC contained in Td?"<<endl;
    Td->compare(Td_ADOLC,ep);
    cout<<"Is Td contained in Td_ADOLC?"<<endl;
    Td_ADOLC->compare(Td,ep);
    delete Td_ADOLC;
  }
 
  delete grad;
  delete Td;
  delete HG; //*/
}
void build_Td_ADOLC(int tape_num, double * direction, double *x,  Graph * Td_ADOLC,  double ep){
  double tempval1 =0.0,tempval2 =0.0;
  int i,j,k;
  int n = Td_ADOLC->N;
  int p,d,dim;
  p = n;
  d = 3;
  int indice [d];
  double** S = new double*[n];
  double** tensor = new double*[n];
  
  for (i=0; i<n; i++) {
    S[i] = new double[p];
    for(j=0;j<p;j++){
      S[i][j]=0.0;
      if(j==i)
	S[j][j] =1;
    }
  }
  dim = binomi(p+d,d);                                      
  tensor = myalloc2(n,dim); 
  tensor_eval(tape_num,1,n,d,p,x,tensor,S); //*/
  
  for (i=1; i<n+1; i++) {
    for (j=i; j<n+1; j++){
      for(k=1; k<n+1; k++){
	if(k<=i){
	  indice[0]= k;
	  indice[1]= i;
	  indice[2]= j;
	  
	}
	else if(k<=j){
	  indice[0]= i;
	  indice[1]= k;
	  indice[2]= j;
	}
	else{
	  indice[0]= i;
	  indice[1]= j;
	  indice[2]= k; 
	}
	tempval1 =tensor[0][address(d,indice)]*direction[k-1];
	//cout<<"tempval: "<< tempval1<<endl;
	if( tempval1>ep || tempval1<-ep  ){
	  //cout<<"inserting Td "<<j<<" "<<i<<" vk "<<k<<" val: "<<tempval1<<endl;
	  Td_ADOLC->insert_edge_inorder(j-1,i-1,tempval1);  
	}
      }
    }
  }
    free((char*) *tensor);
    free((char*)tensor);
}
void setup_func_pointer(struct pt2func pt2funcs[]){
  pt2funcs	[	0	]	.name 	=	"	cosine	";
  pt2funcs	[	0	]	.pt 	=		cosine	;
  pt2funcs	[	1	]	.name 	=	"	bc4	";
  pt2funcs	[	1	]	.pt 	=		bc4	;
  pt2funcs	[	2	]	.name 	=	"	cragglevy	";
  pt2funcs	[	2	]	.pt 	=		cragglevy	;
  pt2funcs	[	3	]	.name 	=	"	chainwood	";
  pt2funcs	[	3	]	.pt 	=		chainwood	;
  pt2funcs	[	4	]	.name 	=	"	morebv	";
  pt2funcs	[	4	]	.pt 	=		morebv	;
  pt2funcs	[	5	]	.name 	=	"	scon1dls	";
  pt2funcs	[	5	]	.pt 	=		scon1dls	;
  pt2funcs	[	6	]	.name 	=	"	bdexp	";
  pt2funcs	[	6	]	.pt 	=		bdexp	;
  pt2funcs	[	7	]	.name 	=	"	pspdoc	";
  pt2funcs	[	7	]	.pt 	=		pspdoc	;
  pt2funcs	[	8	]	.name 	=	"	augmlagn	";
  pt2funcs	[	8	]	.pt 	=		augmlagn	;
  pt2funcs	[	9	]	.name 	=	"	brybnd	";
  pt2funcs	[	9	]	.pt 	=		brybnd	;
  pt2funcs	[	10	]	.name 	=	"	chainros\_trigexp 	";
  pt2funcs	[	10	]	.pt 	=		chainros_trigexp 	;
  pt2funcs	[	11	]	.name 	=	"	toiqmerg 	";
  pt2funcs	[	11	]	.pt 	=		toiqmerg 	;
  pt2funcs	[	12	]	.name 	=	"	arwhead	";
  pt2funcs	[	12	]	.pt 	=		arwhead	;
  pt2funcs	[	13	]	.name 	=	"	nondquar	";
  pt2funcs	[	13	]	.pt 	=		nondquar	;
  pt2funcs	[	14	]	.name 	=	"	sinquad	";
  pt2funcs	[	14	]	.pt 	=		sinquad	;
  pt2funcs	[	15	]	.name 	=	"	bdqrtic	";
  pt2funcs	[	15	]	.pt  	=		bdqrtic	;
  pt2funcs	[	16	]	.name  	=	"	noncvxu2	";
  pt2funcs	[	16	]	.pt  	=		noncvxu2	;
  pt2funcs	[	17	]	.name  	=	"	ncvxqp3 	";
  pt2funcs	[	17	]	.pt	=		ncvxqp3 	;
  pt2funcs[18].pt = function_input;
  pt2funcs[18].name= "function_input";  
  //*/
}
