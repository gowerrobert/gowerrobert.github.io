#include "../function_input.h"


adouble sinquad(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */


//   Source:   in CUTE  sinquad
//   N. Gould, private communication.

//   SIF input: N. Gould, Dec 1989.
	fad = pow((x[0]-1),4);
	for(i=1; i<n; i++)
	  fad = fad+pow((sin(x[i]-x[n-1])-pow(x[1],2)+pow(x[i],2)),2);
	fad = fad+pow((pow(x[n-1],2)-pow(x[1],2)),2);
	
    return(fad);
}
double sinquad(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            


//   Source:   in CUTE  sinquad
//   N. Gould, private communication.

//   SIF input: N. Gould, Dec 1989.
	fad = pow((x[0]-1),4);
	for(i=1; i<n; i++)
	   fad = fad+pow((sin(x[i]-x[n-1])-pow(x[1],2)+pow(x[i],2)),2);
	fad = fad+pow((pow(x[n-1],2)-pow(x[1],2)),2);
return(fad);
}



