#include "../function_input.h"


adouble brybnd(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
//B r o y d e n  b a n d e d  f u n c t i o n as in:   name:
//Testing unconstrained optimization software.
//As a minimun squared sum : name: brybnd
   // fi = 0;  
   if(n<7){
     cout<<"dimension must be bigger then 7!!"<<endl;
     return(fad); 
   }
   fad =0;
    for(i=1; i<7; i++){
       fi = x[i-1]*(2+5*x[i-1])+ 1;
       for(j=1; j<i+1; j++)
          fi = fi + x[j-1]*(1+x[j-1]);
       fad = fad +fi*fi;
       fi=0;
    }
    
    for(i=7; i<n; i++){
       fi = x[i-1]*(2+5*x[i-1])+ 1;
       for(j=i-5; j<=i+1; j++)
          fi = fi + x[j-1]*(1+x[j-1]);
       fad = fad+ fi*fi;
       fi=0;
    }    
   
  fi = x[n-1]*(2+5*x[n-1])+ 1;
    for(j=n-5; j<=n; j++)
	fi = fi + x[j-1]*(1+x[j-1]);
    fad = fad+ fi*fi;

    return(fad);
}
double brybnd(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            
//B r o y d e n  b a n d e d  f u n c t i o n as in:   name:
//Testing unconstrained optimization software.
//As a minimun squared sum : name: brybnd
   // fi = 0;  
   
   fad =0;
    for(i=1; i<7; i++){
       fi = x[i-1]*(2+5*x[i-1])+ 1;
       for(j=1; j<i+1; j++)
          fi = fi + x[j-1]*(1+x[j-1]);
       fad = fad +fi*fi;
       fi=0;
    }
    
    for(i=7; i<n; i++){
       fi = x[i-1]*(2+5*x[i-1])+ 1;
       for(j=i-5; j<=i+1; j++)
          fi = fi + x[j-1]*(1+x[j-1]);
       fad = fad+ fi*fi;
       fi=0;
    }    
   
  fi = x[n-1]*(2+5*x[n-1])+ 1;
    for(j=n-5; j<=n; j++)
	fi = fi + x[j-1]*(1+x[j-1]);
    fad = fad+ fi*fi;


return(fad);
}



