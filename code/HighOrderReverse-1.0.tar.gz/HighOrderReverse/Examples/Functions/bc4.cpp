#include "../function_input.h"


adouble bc4(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
  
//Brachistochrone Problem NAME: bc4, princeton noncute
//fad =1;
double * param;
param = new double [n];
adouble * dydx;
dydx = new adouble [n];

for(i=0;i<n;i++)
     param[i] = pow(((double)i/(double)n),4);

for(i=1;i<n;i++)
   dydx[i] = (x[i] - x[i-1])/(param[i] - param[i-1]);

for(i=1;i<n;i++){
    fad = fad +  sqrt( (1+pow(dydx[i],2))/x[i-1] )*(param[i]-param[i-1]);
}
    return(fad);
}
double bc4(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            
  
//Brachistochrone Problem NAME: bc4, princeton noncute
//fad =1;
double * param;
param = new double [n];
double * dydx;
dydx = new double [n];

for(i=0;i<n;i++)
     param[i] = pow(((float)i/(float)n),4);

for(i=1;i<n;i++)
   dydx[i] = (x[i] - x[i-1])/(param[i] - param[i-1]);

for(i=1;i<n;i++){
    fad = fad +  sqrt( (1+pow(dydx[i],2))/x[i-1] )*(param[i]-param[i-1]);
}
return(fad);
}
