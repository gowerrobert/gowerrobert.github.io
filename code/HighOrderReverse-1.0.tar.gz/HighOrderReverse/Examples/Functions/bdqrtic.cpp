#include "../function_input.h"


adouble bdqrtic(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

//minimize f:
//NAME: bdqrtic
//arrow + 3-7 D
   for(i=0; i<n-4; i++)
        fad = fad + pow(-4*x[i]+3.0,2)
              +pow((pow(x[i],2)+2*pow(x[i+1],2)
	      +3*pow(x[i+2],2)+4*pow(x[i+3],2)
	      +5*pow(x[n-1],2)),2);
    return(fad);
}
double bdqrtic(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            
//minimize f:
//NAME: bdqrtic
//arrow + 3-7 D
   for(i=0; i<n-4; i++)
        fad = fad + pow(-4*x[i]+3.0,2)
              +pow((pow(x[i],2)+2*pow(x[i+1],2)
	      +3*pow(x[i+2],2)+4*pow(x[i+3],2)
	      +5*pow(x[n-1],2)),2);


return(fad);
}



