#include "../function_input.h"


adouble ncvxbqp1(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
//Name: ncvxbqp1	
// AMPL Model by Hande Y. Benson
// Copyright (C) 2001 Princeton University
//param N:=10000;  <--- large domain
//EdgePushing kicks ass on these nonconv approx
int N =n;
int M =N/2;
int NPLUS = N/4;

	for(i=1; i<NPLUS; i++) 
	    fad =fad+ 0.5*pow((x[i]+x[(2*i-1) % N ] +x[(3*i-1) % N ]),2);
	for(i=NPLUS+1; i<n; i++) 
	    fad = fad - 0.5*pow((x[i]+x[(2*i-1) % N] +x[(3*i-1) % N]),2) ;	

    return(fad);
}
double ncvxbqp1(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            
//Name: ncvxbqp1	
// AMPL Model by Hande Y. Benson
// Copyright (C) 2001 Princeton University
//param N:=10000;  <--- large domain
//EdgePushing kicks ass on these nonconv approx

int M =N/2;
int NPLUS = N/4;

	for(i=1; i<NPLUS; i++) 
	    fad =fad+ 0.5*pow((x[i]+x[(2*i-1) % N ] +x[(3*i-1) % N ]),2);
	for(i=NPLUS+1; i<n; i++) 
	    fad = fad - 0.5*pow((x[i]+x[(2*i-1) % N] +x[(3*i-1) % N]),2) ;	


return(fad);
}



