#include "../function_input.h"
/*
void setup_func_pointer(struct pt2func pt2funcs[]){
  //pt2funcs[0].pt = function_input;
  //pt2funcs[0].name= "function_input";  
  pt2funcs[0].pt = pspdoc;
  pt2funcs[0].name= "pspdoc";
  pt2funcs[1].pt = scon1dls;
  pt2funcs[1].name = "scon1dls";
  pt2funcs[2].pt = sinquad;
  pt2funcs[2].name = "sinquad";
  pt2funcs[3].pt = nondquar;
  pt2funcs[3].name = "nondquar";
  pt2funcs[4].pt = bc4;
  pt2funcs[4].name = "bc4";  
  pt2funcs[5].pt = cragglevy;
  pt2funcs[5].name = "cragglevy";  
  pt2funcs[6].pt = augmlagn;
  pt2funcs[6].name = "augmlagn";  
  pt2funcs[7].pt = arwhead;
  pt2funcs[7].name = "arwhead";  
  pt2funcs[8].pt = cosine;
  pt2funcs[8].name = "cosine";  
  pt2funcs[9].pt = bdexp;
  pt2funcs[9].name = "bdexp";  
  pt2funcs[10].pt = brybnd;
  pt2funcs[10].name = "brybnd";  
  pt2funcs[11].pt = bdqrtic;
  pt2funcs[11].name = "bdqrtic";  
  pt2funcs[12].pt = lminsurf;
  pt2funcs[12].name = "lminsurf";  
  pt2funcs[13].pt = chainwood;
  pt2funcs[13].name = "chainwood";  
  pt2funcs[14].pt = morebv;
  pt2funcs[14].name = "morebv";  
  pt2funcs[15].pt = noncvxu2;
  pt2funcs[15].name = "noncvxu2";  
  pt2funcs[16].pt = ncvxqp3;
  pt2funcs[16].name = "ncvxqp3";  
  pt2funcs[17].pt = ncvxbqp1;
  pt2funcs[17].name = "ncvxbqp1";
  pt2funcs[18].pt = chainros_trigexp;
  pt2funcs[18].name = "chainros_trigexp"; 
  pt2funcs[19].pt = binary;
  pt2funcs[19].name = "binary"; 
  pt2funcs[20].pt = toiqmerg;
  pt2funcs[20].name = "toiqmerg";   
  
  
}//*/
