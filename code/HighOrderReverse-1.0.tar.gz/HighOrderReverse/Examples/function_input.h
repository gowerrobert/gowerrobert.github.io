
// #ifdef IS_ADOLC2_3
// #include <adolc/adolc.h>
// #else
// #include <adolc.h>
// #endif
#include <adolc/adolc.h>
#include <cstdlib>
#include <cstdio>
#include <vector> 

adouble function_input(adouble * x, int n);
adouble function_input1(adouble * x, int n);
adouble pspdoc(adouble * x, int n);
adouble scon1dls(adouble * x, int n);
adouble sinquad(adouble * x, int n);
adouble nondquar(adouble * x, int n);
adouble bc4(adouble * x, int n);
adouble cragglevy(adouble * x, int n);
adouble augmlagn(adouble * x, int n);
adouble arwhead(adouble * x, int n);
adouble cosine(adouble * x, int n);
adouble bdexp(adouble * x, int n);
adouble brybnd(adouble * x, int n);
adouble bdqrtic(adouble * x, int n);
adouble lminsurf(adouble * x, int n);
adouble chainwood(adouble * x, int n);
adouble morebv(adouble * x, int n);
adouble noncvxu2(adouble * x, int n);
adouble ncvxqp3(adouble * x, int n);
adouble ncvxbqp1(adouble * x, int n);
adouble chainros_trigexp(adouble * x, int n);
adouble binary(adouble * x, int n);  
adouble toiqmerg(adouble * x, int n);
adouble unstable(adouble * x, int n);
