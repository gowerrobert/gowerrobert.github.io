
#include <iostream>
#include <vector>
#include <math.h>
#include <sys/time.h>
#include <adolc/highorder/graph_blocks.h>
#include <adolc/highorder/reverse_hessian_internal_blocks.h>
#include <adolc/highorder/translate_tape.h>
#include "oplate.h"
#define is_increment (func==eq_plus_d||func==eq_plus_a||func==eq_min_d||func==eq_min_a||func== eq_mult_d||func==eq_mult_a)
#define is_eq_prod (func==eq_plus_prod || func==eq_min_prod)
/*eq_plus_d,  //  5
eq_plus_a,    //  6
eq_min_d, //  7
eq_min_a, //  8
eq_mult_d,    //  9
eq_mult_a,    //  10
eq_plus_prod,   //  54
eq_min_prod,  //  55
*/
using namespace std;
//GLOBAL n and m, ARE YOU SURE?
int reverse_hessian_internal_blocks(opt_list * v, Graph * values, Graph *E, int N){
  int i,j,k;
  bool print_stuff =1;
  int n= N;
  int m = v->max_active+1;
  
  /* Allocating variables */
  deriv_info * der = new deriv_info;
  double * Adjoints = new double [m];
  Block * reused_node_block;
  reused_node_block =new  Block; 
  
  /*------------------------*/
  
  for(i=0; i<m; i++)
    Adjoints[i]=0.0;
  
  int max_v=m, dep, func, factor,xx, start, last;
  int indep=N-1;
  int total_iter =0;
  double ww;
  opt * aux;
  bool start_indep =1;
  
  aux = v->head;
  //Loops through all elements in tape
  while(aux!=NULL){
    func = aux->func;
    j = aux->vi;
    total_iter++;
    
    //The hall of shame
    switch(aux->func){
      case assign_d_zero:
	aux = aux->next;
	continue;
	break;
      case assign_d_one:
	aux = aux->next;
	continue;
	break;
      case assign_dep:
	// The start adjoint
	Adjoints[j]=1.0; 
	aux = aux->next;
	continue;
	break;
      case death_not:
	aux = aux->next;
	continue;
	break;   
      case assign_ind:
	indep--;
	aux = aux->next;
	continue;
	break;
      default:
	break;
    }  
    
    derivative_info(aux, der, values);  
    //  print_der(der);
    /*------------ Pushing--------*/
    if(aux->son[0]!=-1 || aux->son[1]!=-1){
     // last = E->B[j].end_pos;
     // start = E->B[j].start_pos;
     start= E->get_first_position(j);
     last= E->get_last_position(j);
     
      for(k=start; k< last+1; k++){  
	//xx = E->B[j].x[k];
	//ww = E->B[j].w[k];
	xx=E->get_neighbor_node(j,k);
	ww=E->get_edge_weight(j,k);
	if(xx!=-1)
	  push_edge(xx, ww, aux,  der,  E,reused_node_block);    
      }//end of Pushing  
      }
      // cout<<"reset_real"<<endl;
      E->B[j].reset();
      /*------------Edge Creating--------*/
      create_edges(aux, der, Adjoints[j], E,reused_node_block);
      /*------------Calculating Adjoint values--------*/
      calculate_adjoint(aux, der, Adjoints);
      /*  cout<<"Adjoints: "<<endl;
      for(i = 0; i<m ; i++)
      cout<<Adjoints[i]<<"  ";
      cout<<endl; //*/    
      
      //cout<<"Removing Value from tape"<<endl;
      values->remove_end(j);
      
      // In case of re-used variable   
      if( reused_node_block->end_pos!=-1){
	E->B[j] = *reused_node_block;
	reused_node_block =new  Block;
      }
      aux = aux->next;
      // E->print();
    }//end of while(aux) tape loop 
    
    //Shifting the naming of the independent variables so that is starts at zero
    E->N = N;  
    
    delete reused_node_block;
    delete[] Adjoints;
    delete der;
    return(0);
    }
    void push_edge(int xx, double ww, opt * v, deriv_info * der, Graph * E, Block * reused_node_block){
      int func,i;
      int son[2], vi;
      son[0] = v->son[0]; 
      son[1] = v->son[1];
      vi = v->vi;
      func = v->func;
      double partialx = der->partialx;
      double partialy = der->partialy;
      int indep =  xx;
      //cout<<"xx  ww  vi   "<<xx<<"  "<<ww<<"  "<<vi<<endl;  
      if(indep != vi){
	// for(i=0; i<2; i++){
 if(son[0]!= -1 && partialx!=0.0){
   //    cout<<"pushing "<<indep<<" to son: "<<son[0]<<endl;
   if(son[0] ==indep)
     increment_edge(vi,indep, indep, 2*partialx*ww,   E,reused_node_block);
   else{ 
     increment_edge(vi,indep, son[0], partialx*ww,   E,reused_node_block);
   }
 }
 if(son[1]!= -1  && partialy!=0.0){      
   if(son[1] ==indep)
     increment_edge(vi,indep, indep, 2*partialy*ww,   E,reused_node_block);
   else 
     increment_edge(vi,indep, son[1], partialy*ww,  E,reused_node_block);    
 }
      }
      else{
	if(son[0]!= -1 && son[1]!= -1){
	  if(son[0]==son[1]  && (partialx!=0.0 || partialy!=0.0 ))
	    increment_edge(vi,son[1], son[0], (partialx*partialx +2*partialx*partialy+partialy*partialy)*ww, E,reused_node_block);    
	  
	  else{  
	    if(partialx!=0.0 && partialy!=0.0)
	      increment_edge(vi,son[1], son[0], partialx*partialy*ww,   E,reused_node_block); 
	    if(partialx!=0.0)  
	      increment_edge(vi,son[0], son[0], partialx*partialx*ww,   E,reused_node_block);
	    if(partialy!=0.0)
	      increment_edge(vi,son[1], son[1], partialy*partialy*ww,   E,reused_node_block);
	  }
	}
	else if(son[0]!= -1 && partialx!=0.0)
	  increment_edge(vi,son[0], son[0], partialx*partialx*ww,   E,reused_node_block);
	else if(son[1]!=-1 && partialy!=0.0)
	  increment_edge(vi,son[1], son[1], partialy*partialy*ww,   E,reused_node_block); 
      }
      // if(is_eq_prod)
      //    ww = ww*partialx*partialy;
    }
    int create_edges(opt * v, deriv_info * der, double Adj, Graph * E, Block * reused_node_block){
      int i;
      int  son[2], vi;
      son[0] = v->son[0]; 
      son[1] = v->son[1]; 
      vi = v->vi;
      double partialxy = der->partialxy;
      double partialyy =der->partialyy;
      double partialxx =der->partialxx;   
      //cout<<vi<<"  sons are: "<<son[0]<<"  and  "<<son[1]<<endl;
      //cout<<"vi adjoint: "<<Adj<<endl;
      int opt = v->func;
      
      if(partialxx!=0.0){
	increment_edge(vi, son[0], son[0], partialxx*Adj,   E,reused_node_block);
      }
      if(partialyy!=0.0)
	increment_edge(vi,son[1], son[1], partialyy*Adj,   E,reused_node_block);
      if(partialxy!= 0.0){
	if( son[0] ==son[1])
	  increment_edge(vi,son[0], son[1], 2*partialxy*Adj,  E,reused_node_block);
	else
	  increment_edge(vi,son[0], son[1], partialxy*Adj,  E,reused_node_block);
      }
      return(0);
    }
    int increment_edge(int vi, int x, int y, double ww,  Graph * E, Block * reused_node_block){
      int big, small;
      long double c0,c1;
      if(ww==0.0)
	return(0);
      
      // lower triangle
      if(x>=y){
	big = x;
	small = y;
      }
      else{
	big = y;
	small = x;
      }
      if(big== vi){
	reused_node_block->insert_inorder( small,ww);
	return (1);
      }
      
      // cout<<"incrementing "<<small<<" in B"<<big<<endl; 
      E->insert_edge_inorder(big, small,ww);    
      return 0;
    }
    void calculate_adjoint(opt * v, deriv_info* der, double *Adjoint){
      int son[2], vi,func;
      son[0] = v->son[0]; 
      son[1] = v->son[1];
      vi = v->vi;
      func = v->func;
      double partialx = der->partialx;
      double partialy = der->partialy; 
      //Adjoint[vi]*partialx;    
      double temp = Adjoint[vi];
      //If you were a self increment, you still have a father...?
      //  if(!is_increment){
 //      cout<<"funs if no increment "<<func<<endl;
 // if(!is_eq_prod)
 Adjoint[vi] = 0.0;
 //    }
 if((son[1]!=-1) && (son[0]!=-1)){
   if(son[0]==son[1]){
     //Adjoint[son[0]] =0.0;
     Adjoint[son[0]] += 2*temp*partialx;     
   }
   else{
     Adjoint[son[1]] += temp*partialy;
     Adjoint[son[0]] += temp*partialx; 
   }  
 }
 else if(son[1]!= -1){
   //Adjoint[son[1]] =0.0;
   Adjoint[son[1]] += temp*partialy;
 }
 else if(son[0]!= -1){ 
   //Adjoint[son[0]] =0.0;  
   Adjoint[son[0]] += temp*partialx;
 }
 
 }
 int derivative_info(opt * operation, deriv_info * der, Graph * values){
   int opt,i,temp;
   int son[2], vi;
   double x=0.0,y=0.0,z=0.0, const_double=0.0;    
   son[0] = operation->son[0]; 
   son[1] = operation->son[1];
   vi = operation->vi;
   const_double = operation->const_double;    
   opt = operation->func;
   
   der->partialx = 0.0;
   der->partialy = 0.0;
   der->partialxy = 0.0;
   der->partialyy = 0.0;
   der->partialxx = 0.0;
   
   //    cout<<"vi: "<<vi<<endl;
   // values.print(vi, 0);
   if(values->get_last_position(vi)==-1){
     // cout<<"NO VALUE RECORED"<<endl;
     //  cout<<"num_null_access: "<<num_null_access<<endl;
     // cout<<"vi: "<<vi<<endl;
     z= 0.0;
     const_double =0.0;
   }
   else{
     z= values->get_last_edge_weight(vi);
    // z = values->B[vi].get_lastw();
     //   cout<<"z: "<<z<<endl;
     //  const_double = values.V_L[vi].head->const_double;
   }
   //cout<<"son 0"<<endl;
   if(son[0]!=-1){
     if(values->get_last_position(son[0]) !=-1){
       if(son[0]!=vi)
	 x = values->get_last_edge_weight(son[0]);
       //If vi same node as son, get the value at the end but one
       else if(values->get_last_position(son[0])!= 
	 values->get_first_position(son[0])){
	 temp = values->get_last_position(son[0]);
         x= values->get_edge_weight(son[0],temp-1);
       //x = values->B[son[0]].w[temp-1]; 
       } 
     }
   }   
   // cout<<"x: "<<x<<endl;
   // cout<<"son 1"<<endl;
   if(son[1]!=-1){
     if(values->B[son[1]].end_pos !=-1){
       if(son[1]!=vi)
	 y = values->get_last_edge_weight(son[1]);
	 //y = values->B[son[1]].get_lastw();
       //If vi same node as son, get the value at the end but one       
       else if( values->get_last_position(son[1]) != values->get_first_position(son[1])){
	 temp = values->get_last_position(son[1]);
	 y= values->get_edge_weight(son[1],temp-1);
	 //temp = values->B[son[1]].end_pos;
	 // y = values->B[son[1]].w[temp-1]; 
       } 
     }
   }  
   //cout<<"y: "<<y<<endl;
   switch (opt){
     case  assign_ind: 	//	1
       break;
     case  assign_dep: 	//	2
       der->partialx = 1.0;
       break;
     case  assign_a: 	//	3
       der->partialx = 1.0;
       break;
     case  assign_d:	//	4
       break;
     case eq_plus_d: //	5
       der->partialy = 1.0;
       break;
     case eq_plus_a: //	6
       der->partialx = 1.0;
       der->partialy = 1.0;
       break;
     case  eq_min_d: //	7
       //der->partialx = 1.0;
       der->partialy = 1.0;
       break;	    
     case eq_min_a  : //	8
       der->partialx = -1.0;
       der->partialy = 1.0;
       break;
     case eq_mult_d: //	9
       //der->partialx = -1.0;
       der->partialy = const_double;
       break;	
     case eq_mult_a: //	10
       //der->partialx = -1.0;
       der->partialx = y;
       der->partialy = x;	       
       der->partialxy = 1.0;
       break;	
     case plus_a_a:	//	11
       der->partialx = 1.0;
       der->partialy = 1.0;	
       break;
     case plus_d_a:	//	12
       der->partialx = 1.0;
       break;
     case  min_a_a:	//	13
       der->partialx = 1.0;
       der->partialy = -1.0;	
       break;
     case min_d_a:	//	14
       der->partialx = 1.0;
       break;
     case mult_a_a:	//	15
       der->partialx = y;
       der->partialy = x;	       
       der->partialxy = 1.0;	
       break;
     case  mult_d_a:	//	16
       // if(x!=0.0)
       //     der->partialx = z/x;
       // else //...need that constant!
       // {  der->partialx = z; } 
       der->partialx = const_double;
       break;
       
     case  div_a_a:	//	17
       if(y==0.0)  cout<<"Divided by zero in div_a_a"<<endl;
       else{
	 der->partialx = 1/y;
	 der->partialxx = 0.0;
	 der->partialy = -x/(y*y);
	 der->partialyy = 2*x/(y*y*y);
	 der->partialxy = -1/(y*y); 
       }
       break;
       
     case  div_d_a:	//	18
       if(x==0.0)  cout<<"Divided by zero in div_d_a"<<endl;
       else{
	 der->partialx = -(const_double)/(x*x);
	 der->partialxx= 2*const_double/(x*x*x);		  		
       }
       break;
     case  exp_op:	//	19
       der->partialx = z;       
       der->partialxx = z;	
       
       break;
     case cos_op:	//	20
       der->partialx = -sin(x);       
       der->partialxx = -cos(x);
       
       break;
     case sin_op:	//	20
       der->partialx = cos(x);       
       der->partialxx = -sin(x);
       
       break;
       //	atan_op,	//	22 arc tangent
     case log_op:	//	23
       if(x!=0.0){
	 der->partialx = 1/x;       
	 der->partialxx = -1/(x*x);
       }else{
	 cout<<"singularity, x=0.0 for log"<<endl; 
       }
       break;
     case pow_op:	//	24
       // there is no actual x^y only x^c.
       if(const_double-1 <0 && x==0.0){ cout<<"1 divided by zero! singular"<<endl;}
       else{
	 //cout<<"const_double>=1 && x==0.0"<<endl;
	 der->partialx = const_double*pow(x,const_double-1);  //how much is why?     
       }
       if(const_double-2<0 && x==0.0) {cout<<"1 divided by zero! singular"<<endl;}
       else { 
	 //cout<<"const_double>=2 && x==0.0"<<endl;
	 der->partialxx = const_double*(const_double-1)*pow(x,const_double-2);
       }
       
       break;	       
       //	asin_op,	//	25
       //	acos_op,	//	26     
       
     case sqrt_op:	//	20
       der->partialx = 0.5*pow(x,-0.5);       
       der->partialxx = -0.25*pow(x,-1.5);   ;
       break;
       /*	       
       asinh_op,	//	28
       acosh_op,	//	29
       atanh_op,	//	30
       gen_quad,	//	31
       end_of_tape,	//	32
       start_of_tape,	//	33
       end_of_op,	//	34
       end_of_int,	//	35
       end_of_val,	//	36*/
       case cond_assign:	//	37 put an if case to eliminate a son
	 /*
	 cond_assign(a,b,c,d) =
	 if(b>0)
	 a=c;
	 else     
	   a=d;
	 
	 in our case:
	 
	 cond_assign(z,x.y. const_double)
	 
	 */
	 //cout<<"condassign   x, y, z, const; "<<x<<" ,"<<y<<" ,"<<z<<" ,"<<const_double<<" "<<endl;
	 //cin>>i;
	 if(const_double >0)
	   der->partialx = 1;
	 else
	   der->partialy = 1;
	 //der->partialx = 1;
	 //der->partialy = 1;
	 break;
       case cond_assign_s:	//	38
	 if(x==z)
	   der->partialx = 1;
	 else if(y==z)
	   der->partialy = 1;
	 //der->partialx = 1;
	 //der->partialy = 1;
	 break;
	 /*
	 take_stock_op,	//	39
	 */
	 case assign_d_one:	//	42 ??
	   der->partialx = 0;
	   der->partialy = 0;		
	   break;  
	 case assign_d_zero:	//	42 ??
	   der->partialx = 0;
	   der->partialy = 0;		
	   break;	  
	 case incr_a:	//	42 ??
	   der->partialx = 1;
	   break;	  
	 case  decr_a:	//	43 ??
	   der->partialx = 1;
	   break;
	 case neg_sign_a:	//	44
	   der->partialx = -1;
	   break;
	 case pos_sign_a:	//	45
	   der->partialx = 1;
	   break;
	 case min_op:	//	46
	   if(x>y){
	     der->partialy = 1;
	   }
	   else if(x==y){
	     cout<<"x==y"<<endl;
	     cin>>z;
	     der->partialx = 1;
	     der->partialy = 1;
	   }
	   else if(x<y){
	     der->partialx = 1;
	   }
	   break;
	 case abs_val:	//	47
	   if(x>=0)
	     der->partialx = 1;
	   else
	     der->partialx = -1;	
	   break;
	   /*eq_zero,	//	48 these dont really work in ADOL-c
	   neq_zero,	//	49
	   le_zero,	//	50
	   gt_zero,	//	51
	   ge_zero,	//	52
	   
	   lt_zero,	//	53*/
	   //	
	 case eq_plus_prod:	//	54
	   der->partialx = y;
	   der->partialy = x;	       
	   der->partialxy = 1;	
	   break;
	 case eq_min_prod:	//	55
	   der->partialx = -y;
	   der->partialy = -x;	       
	   der->partialxy = -1;	
	   break;	       
	   /*
	   erf_op,	//	56
	   ceil_op,	//	57 //constant or discontinious
	   floor_op,	//	58 //constant or discontinious
	   ext_diff,	//	59
	   ignore_me,	//	60 */
	   default: //cout<<"dont know this opt:"<<opt<<endl; 
	   break;
 }
 return(0);
 
    }
    
    
    