#include <iostream>

#include <math.h>
#include <adolc/highorder/graph_blocks.h>
#include <adolc/highorder/sparsity_pattern_internal_blocks.h>
#include <oplate.h>
using namespace std;
int sparsity_pattern_internal_blocks(opt_list * v, int N,  Graph * E){
  int i,j,k;
  int n, m;
  n= N;
  m = v->max_active+1;
  /* Allocating variables */
  deriv_info * der = new deriv_info;
  Block * reused_node_block;
  Block * indep_move;
  reused_node_block =new  Block;
  /*------------------------*/
  
  int max_v,factor, dep,  func, total_iter=0, xx, last, first;
  bool first_indep =1;
  int indep=N-1;
  opt * aux;
  aux = v->head;
  long double c0,c1,c2;
    double x_var[3] = {1,1,1};
  /*Loops through all elements in tape. */
  while(aux!=NULL){
    j = aux->vi;
    total_iter++;
    
    //   cout<<j<<" "<<aux->son[0]<<" "<<aux->son[1]<<"  iteration:"<<total_iter<<" func "<<aux->func<<endl;          
    
    if(aux->func==assign_dep){ 
      aux = aux->next;
      continue;
    }
    
    else if(aux->func==death_not){
      aux = aux->next; 
      continue;
    }
    else if(aux->func==assign_ind){
      indep--;
      aux = aux->next;
      continue;
    }
    
    derivative_info_sp(aux, der);  
    //derivative_info_internal( der, 0.0, aux->func, x_var);
    //    print_der(der);  
    
    /*------------Edge Pushing--------*/
    if(aux->son[0]!=-1 || aux->son[1]!=-1){ 
      last = E->B[j].last_pos;
      first = E->B[j].first_pos;
      for(k=first; k< last+1; k++){  
	xx = E->B[j].x[k];
	/*    cout<<"pushing: ("<<j<<" , "<<xx<<")"<<endl;
	cout<<"push to sons:"<<aux->son[0]<<" , "<<aux->son[1]<<endl;//*/
	push_edge_sp(xx, aux,  der,  E,reused_node_block);  
      }
      
    }//end of Edge Pushing  
    
    /* Reseting this block for possible re-use later */ 
    E->B[j].reset();
    
    /*------------Edge Creating--------*/
    create_edges_sp(aux, der, E,reused_node_block);
    
    
    if( reused_node_block->last_pos!=-1){
    //  E->B[j].copy(*reused_node_block);
      E->copy_neighbors(*reused_node_block , j);
      reused_node_block->reset();
    }
    aux = aux->next; 
    }//end of while(aux)     
    E->N = N;
    delete reused_node_block;
    delete der;
    return(0);
    }
    void push_edge_sp(int xx, opt * v, deriv_info * der, Graph * E, Block * reused_node_block){
      int opt;
      int son[2], vi;
      son[0] = v->son[0]; 
      son[1] = v->son[1];
      vi = v->vi;
      opt = v->func;
      double grad[2];
      
      grad[0]= der->grad[0];
      grad[1] = der->grad[1];
      
      int indep =  xx;
      
      if(indep != vi){
	if(son[0]!= -1 && grad[0]!=0.0){
	  increment_edge_sp(vi,indep, son[0], 0,   E,reused_node_block);
	}
	if(son[1]!= -1  && grad[1]!=0.0){      
	  increment_edge_sp(vi,indep, son[1], 0,  E,reused_node_block); 
	}
      }
      else{ 
	if(son[0]!= -1 && grad[0]!=0.0){
	  if(son[1]!= -1  && grad[1]!=0.0){
	    increment_edge_sp(vi,son[0], son[1], 0,  E,reused_node_block); 
	  }
	  increment_edge_sp(vi,son[0], son[0], 0,   E,reused_node_block);
	}
	if(son[1]!= -1 && grad[1]!=0.0)
	{  
	  increment_edge_sp(vi,son[1], son[1], 0,   E,reused_node_block);
	}
      }
      
    }
    int create_edges_sp(opt * v, deriv_info * der, Graph * E, Block * reused_node_block){
      int i;
      int  son[2], vi;
      son[0] = v->son[0]; 
      son[1] = v->son[1]; 
      vi = v->vi;
      double hess[2][2];
      hess[1][0] = der->hess[1][0];
      hess[1][1] =der->hess[1][1];
      hess[0][0] =der->hess[0][0];   
      int opt = v->func;
      
      if(hess[0][0]!=0.0){
	increment_edge_sp(vi, son[0], son[0], 0,   E,reused_node_block);
      }
      if(hess[1][1]!=0.0)
	increment_edge_sp(vi,son[1], son[1], 0,   E,reused_node_block);
      if(hess[1][0]!= 0.0){
	increment_edge_sp(vi,son[0], son[1], 0,  E,reused_node_block);
      }
      return(0);
    }
    int increment_edge_sp(int vi, int x, int y, double w,  Graph * E, Block * reused_node_block){
      int big, small;
      
      
      // lower triangle
      if(x>=y){
	big = x;
	small = y;
      }
      else{
	big = y;
	small = x;
      }
      
      if(big== vi){ 
	reused_node_block->insert_inorder( small,0.0);
	return (1);
      }
      E->insert_edge_inorder(big, small,0.0);
      
      return 0;
    }
    int derivative_info_sp(opt * v, deriv_info * der){
      int opt,i;
      int son[2], vi;
      son[0] = v->son[0]; 
      son[1] = v->son[1];
      
      vi = v->vi;
      opt = v->func;
      der->grad[0] = 0.0;
      der->grad[1] = 0.0;
      der->hess[1][0] = 0.0;
      der->hess[1][1] = 0.0;
      der->hess[0][0] = 0.0;
      
      
      //   cout<<"y: "<<y<<endl;
      switch (opt){
	case  assign_ind:   //  1
	  break;
	case  assign_dep:   //  2
	  der->grad[0] = 1.0;
	  break;
	case  assign_a:     //  3
	  der->grad[0] = 1.0;
	  break;
	case  assign_d: //  4
	  
	case eq_plus_d: //	5
	  der->grad[1] = 1.0;
	  break;
	case eq_plus_a: //	6
	  der->grad[0] = 1.0;
	  der->grad[1] = 1.0;
	  break;
	case  eq_min_d: //	7
	  //der->grad[0] = 1.0;
	  der->grad[1] = 1.0;
	  break;	    
	case eq_min_a  : //	8
	  der->grad[0] = 1.0;
	  der->grad[1] = 1.0;
	  break;	  
	case eq_mult_d: //	9
	  //der->grad[0] = -1.0;
	  der->grad[1] = 1.0;
	  break;	
	case eq_mult_a: //	10
	  der->grad[0] = 1.0;
	  der->grad[1] = 1.0;	       
	  der->hess[1][0] = 1.0;
	  break;	  
	case plus_a_a:  //  11
	  der->grad[0] = 1.0;
	  der->grad[1] = 1.0; 
	  break;
	case plus_d_a:  //  12
	  der->grad[0] = 1.0;
	  break;
	case  min_a_a:  //  13
	  der->grad[0] = 1.0;
	  der->grad[1] = 1.0; 
	  break;
	case min_d_a:   //  14
	  der->grad[0] = 1.0;
	  break;
	case mult_a_a:  //  15
	  der->grad[0] = 1.0;
	  der->grad[1] = 1.0;        
	  der->hess[1][0] = 1.0;    
	  break;
	case  mult_d_a: //  16
	  der->grad[0] = 1.0;
	  der->hess[0][0] = 1.0;   
	  break;
	  
	case  div_a_a:  //  17
	  der->grad[0] = 1.0;
	  der->grad[1] = 1.0;
	  der->hess[1][0] =1.0;
	  der->hess[1][1] =1.0;
	  break;
	  
	case  div_d_a:  //  18
	  der->grad[0] = 1.0;
	  der->hess[0][0] = 1.0;
	  break;
	case  exp_op:   //  19
	  der->grad[0] = 1.0; 
	  der->hess[0][0] = 1.0;
	  break;
	case cos_op:    //  20
	  der->grad[0] = 1.0;       
	  der->hess[0][0] = 1.0;
	  
	  break;
	case sin_op:    //  20
	  der->grad[0] = 1.0;       
	  der->hess[0][0] = 1.0;
	  
	  break;
	  //  atan_op,    //  22 arc tangent
	case log_op:    //  23
	  der->grad[0] = 1.0;       
	  der->hess[0][0] = 1.0;
	  
	  break;
	case pow_op:    //  24
	  // there is no actual x^y only x^c.
	  der->grad[0] = 1.0;       
	  der->hess[0][0] = 1.0;         
	  break;          
	  //  asin_op,    //  25
	  //  acos_op,    //  26     
	  
	case sqrt_op:   //  20
	  der->grad[0] = 1.0;       
	  der->hess[0][0] = 1.0; 
	  break;
	case asinh_op:    //  28
	  der->grad[0] = 1.0;       
	  der->hess[0][0] = 1.0;
	  break;
	  /*         
	  asinh_op,  //  28
	  acosh_op, //  29
	  atanh_op, //  30
	  gen_quad, //  31
	  end_of_tape,  //  32
	  start_of_tape,    //  33
	  end_of_op,    //  34
	  end_of_int,   //  35
	  end_of_val,   //  36*/
	  case cond_assign:   //  37 put an if case to eliminate a son
	    //if(x==z)
	    der->grad[0] = 1.0;
	    //else if(y==z)
	    der->grad[1] = 1.0;
	    //der->grad[0] = 1;
	    //der->grad[1] = 1;
	    break;
	  case cond_assign_s: //  38
	    //if(x==z)
	    der->grad[0] = 1.0;
	    //else if(y==z)
	    der->grad[1] = 1.0;
	    //der->grad[0] = 1;
	    //der->grad[1] = 1;
	    break;
	    /*
	    take_stock_op,    //  39
	    assign_d_one, //  40
	    assign_d_zero,    //  41
	    */
	    case incr_a:    //  42 ??
	      der->grad[0] = 1.0;
	      break;    
	    case  decr_a:   //  43*/ ??
	      der->grad[0] = 1.0;
	      break;
	    case neg_sign_a:    //  44
	      der->grad[0] = 1.0;
	      break;
	    case pos_sign_a:    //  45
	      der->grad[0] = 1.0;
	      break;
	    case min_op:    //  46*/
	    //    if(x>y){
	      der->grad[1] = 1.0;
	      //}
	      //else if(x==y){
	      der->grad[0] = 1.0;
	      der->grad[1] = 1.0;
	      //  }
	      //  else if(x<y){
	      der->grad[0] = 1.0;
	      //  }
	      break;      
	    case abs_val:   //  47
	      der->grad[0] = 1.0;
	      break;
	      /*eq_zero,    //  48 these dont really work in ADOL-c
	      neq_zero, //  49
	      le_zero,  //  50
	      gt_zero,  //  51
	      ge_zero,  //  52
	      lt_zero,  //  53*/
	    case eq_plus_prod:	//	54
	      der->grad[0] = 1.0;
	      der->grad[1] = 1.0;	       
	      der->hess[1][0] = 1.0;	
	      break;
	    case eq_min_prod:	//	55
	      der->grad[0] = 1.0;
	      der->grad[1] = 1.0;	       
	      der->hess[1][0] = 1.0;	
	      break;
	      
	     /* erf_op,   //  56
	      ceil_op,  //  57 //constant or discontinious
	      floor_op, //  58 //constant or discontinious
	      ext_diff, //  59
	      ignore_me,    //  60 */
	      default:// cout<<"dont know this opt:"<<opt<<endl; 
	      break;
    }
    return(0);
    
  }
  
  /*
  if(indep != vi){
 if(son[0]!= -1 && grad[0]!=0.0){
 //    cout<<"pushing "<<indep<<" to son: "<<son[0]<<endl;
 if(son[0] ==indep)
 increment_edge_sp(vi,indep, indep, 0,   E,reused_node_block);
 else{ 
   increment_edge_sp(vi,indep, son[0], 0,   E,reused_node_block);
}
}
if(son[1]!= -1  && grad[1]!=0.0){      
 if(son[1] ==indep)
 increment_edge_sp(vi,indep, indep, 0,   E,reused_node_block);
 else 
   increment_edge_sp(vi,indep, son[1], 0,  E,reused_node_block); 
}
}
else{
  if(son[0]!= -1 && son[1]!= -1){
 if(son[0]==son[1]  && (grad[0]!=0.0 || grad[1]!=0.0 ))
 increment_edge_sp(vi,son[1], son[0],0, E,reused_node_block);    
 
 else{  
   if(grad[0]!=0.0 && grad[1]!=0.0)
   increment_edge_sp(vi,son[1], son[0], 0,   E,reused_node_block); 
   if(grad[0]!=0.0)  
   increment_edge_sp(vi,son[0], son[0], 0,   E,reused_node_block);
   if(grad[1]!=0.0)
   increment_edge_sp(vi,son[1], son[1],0,   E,reused_node_block);
}
}
else if(son[0]!= -1 && grad[0]!=0.0)
increment_edge_sp(vi,son[0], son[0],0,   E,reused_node_block);
else if(son[1]!=-1 && grad[1]!=0.0)
increment_edge_sp(vi,son[1], son[1], 0,   E,reused_node_block); 
}
*/
  