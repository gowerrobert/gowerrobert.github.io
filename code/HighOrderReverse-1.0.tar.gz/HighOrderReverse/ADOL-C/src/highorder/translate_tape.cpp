

/*----------------------------------------------------------------------------
ADOL-C -- Automatic Differentiation by Overloading in C++
File:     tapedoc/tapedoc.c
Revision: $Id: tapedoc.c 62 2009-12-07 17:49:24Z awalther $
Contents: Routine tape_doc(..) writes the taped operations in LaTeX-code 
to the file tape_doc.tex

Copyright (c) Andrea Walther, Andreas Griewank, Andreas Kowarz, 
Hristo Mitev, Sebastian Schlenkrich, Jean Utke, Olaf Vogel 

This file is part of ADOL-C. This software is provided as open source.
Any use, reproduction, or distribution of the software constitutes 
recipient's acceptance of the terms of the accompanying license file.

----------------------------------------------------------------------------*/
#include <iostream>
#include <adolc/highorder/translate_tape.h>
#include "oplate.h"
#include "taping_p.h"
#include <adolc/adalloc.h>
#include <math.h>
#include <string.h>

BEGIN_C_DECLS

/****************************************************************************/
/*                                                                   MACROS */
#define computenumbers true
#define is_increment (func==eq_plus_d||func==eq_plus_a||func==eq_min_d||func==eq_min_a||func== eq_mult_d||func==eq_mult_a)
#define is_eq_prod (func==eq_plus_prod || func==eq_min_prod)

/****************************************************************************/
/*                                                         STATIC VARIABLES */

/*--------------------------------------------------------------------------*/
static short tag;
int ind_count_rob =0;
deriv_info * global_derivative_info;
//int dep_index =0;

void forward_directional(unsigned short opcode, int *son, double *values, Graph * vd_values);
void rename_independents(opt_list *vlist, Graph * v_values, Graph * vd_values, int * new_loc, int n);


void robtape_start( int opcode, opt_list * vlist, Graph * v_values, Graph * vd_values, double * direction) {
  // char *fileName;
  int num;
  num = ADOLC_CURRENT_TAPE_INFOS.stats[NUM_MAX_LIVES];
  // printf("start tape  MAX_LIVES: %i\n",ADOLC_CURRENT_TAPE_INFOS.stats[NUM_MAX_LIVES]);
  if(v_values!=NULL){
    v_values->initiate(num+3);
  }
  vlist->max_active = num+2;
  
  if(vd_values!=NULL){
    vd_values->initiate(num+3);
    global_derivative_info= new deriv_info;
  }
}

/****************************************************************************/
/* robtape( opcode number, number locations, locations, values,           */
/*            number constants, constants )                                 */
/****************************************************************************/
void forward_indep(unsigned short opcode, int nloc, int *loc,
		   double *val,int ncst, double* cst,Graph * vd_values, double * direction, int indep_index){
  int vi;
  //cout<<"forward_indep: "<< loc[nloc -1]<<" , "<<indep_index<<" , "<<direction[indep_index]<<endl;
  vi =loc[nloc -1];
  vd_values->insert_edge(vi,0,direction[indep_index]);

}                            
void forward_directional(unsigned short opcode, int *vi_loc, double *values, Graph * vd_values){
  int i;
  int vi =-1;
  double grad[2];
  double vd[3] = {0.0,0.0,0.0};
  double x_var[3] = {0.0,0.0,0.0};
  
  vi = vi_loc[3];
  
  x_var[0] = values[5];
  if(vi_loc[1]==-1){
    x_var[1] = values[4];
    x_var[2] = 0; 
    if(vi_loc[2]!=-1)
      vd[0]  = vd_values->get_last_edge_weight(vi_loc[2]);
  }
  else{
    x_var[1] = values[3];
    x_var[2] = values[4];   
    vd[0]  = vd_values->get_last_edge_weight(vi_loc[1]);
    if(vi_loc[2]!=-1)
      vd[1]  = vd_values->get_last_edge_weight(vi_loc[2]);
  }
  /*cout<<"x_var: ";
  for(i=0; i<3; i++)
    cout<<x_var[i]<<" , "; 
  cout<<endl;//*/
  derivative_info_internal( global_derivative_info,  (double)(values[1]) ,  opcode,  x_var);
  for(i=0; i<2; i++)
    vd[2] += vd[i]*global_derivative_info->grad[i];
 // cout<<"vd: "<<vd[2]<<endl;  
  vd_values->insert_edge(vi,0,vd[2]);
}
void robtape( unsigned short opcode, int nloc, int *loc,
	      double *val,int ncst, double* cst, opt_list * vlist, Graph * v_values, Graph * vd_values) {
  int i;
  double fake =0.0;
  int max_active=0;
  int vi =-1;
  int son[4] = { -1, -1, -1, -1};
  double values[6] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  opt * temp;
  max_active = vlist->max_active;
  int func = opcode;
  //     /* write opcode number */
  i=0;
  if (opcode!=ext_diff) { /* default */
    for(i=0; i<nloc; i++)
      son[4-nloc+i] = loc[i];
  } else { /* ext_diff */
    for(i=1; i<nloc; i++)
      son[4-nloc+i] = loc[i];
  }
  /* write values */
  #ifdef computenumbers /* values + constants */
  /* constants (max 2) */
  if (opcode==ext_diff)
    nloc=0;
  if(v_values!=NULL)   
    for(i=0; i<ncst; i++)
      values[2-ncst +i] = cst[i];

  /* values (max 4) */
  if(v_values!=NULL)  
    if (nloc) {
      for(i=0; i<nloc-1; i++)
        values[2+(4-nloc)+i] = val[i]; 
      values[5] = val[nloc-1]; 	    
    } 
    #else /* constants only */
    /* constants (max 2) */
    if(v_values!=NULL){
      if (ncst) {
	for(i=0; i<ncst-1; i++)
	  values[2-ncst+i] = cst[i];
	values[ncst-1]  = val[ncst-1]
      }
    }
    #endif
    vi = son[3];
    if(vi!=-1){    
      //printf("%d %d %d %d %d %Le %Le \n", func, son[0], son[1], son[2], vi, (values[1]), (values[5])); 
      if(opcode==take_stock_op)
	return;
      temp = new opt;
      temp->vi =vi;
      if(son[1]==-1){
	temp->son[0] = son[2];
	temp->son[1] = -1;      
      }
      else{
	temp->son[0] = son[1];
	temp->son[1] = son[2];
      }
      temp->func = opcode;
      
      if(is_increment)
	temp->son[1] = vi;
      if(is_eq_prod){ // breaking up the +=* into  + and *
	//cout<<"max_active is"<<max_active<<endl;
	// cout<<"is_eq_prod   sons: "<<temp->son[0]<<" and "<<temp->son[1]<<endl;
	temp->func = mult_a_a;
	temp->vi = max_active-1;   
	temp->next = vlist->head;
	vlist->head = temp;
	
	vlist->length++;
	if(v_values!=NULL){//sparsity pattern cares not for values
	  // cout<<"insertint dummy in v_values"<<endl;
	  v_values->insert_edge(max_active-1,0,0.0);
	  // v_values->V_L[max_active-1].insert_head((double)(0.0)); //dummy value
	}
	temp = new opt;
	if(opcode == eq_min_prod)
	  temp->func = min_a_a;	     
	else  
	  temp->func = plus_a_a;
	temp->son[0] = vi;
	temp->son[1] = max_active-1;
	temp->vi = vi;
      }  
      //  printf("v_values \n");
      if(v_values!=NULL){//sparsity pattern cares not for values
	// cout<<"vi: "<<vi<<"  val: "<<values[5]<<" val1 "<<values[1]<<endl;
	//  v_values->print();
	v_values->insert_edge(vi,0,values[5]);
	//v_values->B[vi].print();
	if((double)(values[1])!= 0.0)
	  temp->const_double = (double)(values[1]);
      }
      temp->next = vlist->head;
      vlist->head = temp;
      vlist->length++;
      
      if(vd_values != NULL){
	if (opcode !=black_list)
	  forward_directional(opcode, son, values, vd_values);
      }
    }
// printf("leaving robtape\n");
}

/*--------------------------------------------------------------------------*/
void robtape_end( int opcode, opt_list * vlist) {
  // printf("GAME OVER AND THANK YOU FOR PLAYING< PRESENTED TO YOU BY NervSol and Nerv Incorporate \n");
  // vlist->print();
}

/*--------------------------------------------------------------------------*/
/* operation names */

/****************************************************************************/
/*                                                             NOW THE CODE */
void translate_tape(short tnum, double * basepoint, opt_list * vlist, Graph * v_values, Graph * vd_values, 
		    double * direction, int indcheck, int depcheck, int num_ops) 
{ 
    unsigned char operation;

    locint size = 0;
    locint res  = 0;
    locint arg  = 0;
    locint arg1 = 0;
    locint arg2 = 0;
    int rob_count =0;
    double coval = 0, *d = 0;
    double valuepoint[1];
    valuepoint[0] =0.0;
    int indexi = 0, indexd = 0;
    /* loop indices */
    int  l;
   //cout<<"indcheck: "<<indcheck<<endl;
    /* Taylor stuff */
    double *dp_T0;
    
    /* interface temporaries */
    int loc_a[4];
    double val_a[4], cst_d[2];
    
    ADOLC_OPENMP_THREAD_NUMBER;
    ADOLC_OPENMP_GET_THREAD_NUMBER;

    /****************************************************************************/
    /*                                                                    INITs */

    init_for_sweep(tnum);
    tag = tnum;

 //   read_cnt = 0;NUM_MAX_LIVES
 //   file_cnt = 80;
    
    if ((depcheck != ADOLC_CURRENT_TAPE_INFOS.stats[NUM_DEPENDENTS]) ||
            (indcheck != ADOLC_CURRENT_TAPE_INFOS.stats[NUM_INDEPENDENTS]) ) {
        fprintf(DIAG_OUT,"ADOL-C error: Tape_doc on tape %d  aborted!\n",tag);
        fprintf(DIAG_OUT,"Number of dependent (%d) and/or independent (%d) "
                "variables passed to Tape_doc is\ninconsistant with "
                "number recorded on tape %d (%d:%d)\n", depcheck,
                indcheck, tag, ADOLC_CURRENT_TAPE_INFOS.stats[NUM_DEPENDENTS],
                ADOLC_CURRENT_TAPE_INFOS.stats[NUM_INDEPENDENTS]);
        exit (-1);
    }

    dp_T0 = myalloc1(ADOLC_CURRENT_TAPE_INFOS.stats[NUM_MAX_LIVES]);
    //cout<<"num_ops: "<<num_ops<<"  NUM_MAX_LIVES  "<<NUM_MAX_LIVES+1<<endl;
    int num_deps = ADOLC_CURRENT_TAPE_INFOS.stats[NUM_MAX_LIVES];
    int * new_loc = new int [num_deps];
    int tempi;
    int last_ind =-1;
    
    for (tempi =0; tempi<num_deps; tempi++)
      new_loc[tempi] = -1;
  //  cout<<"num_deps "<<num_deps<<" indcheck "<<indcheck <<endl;
    
    operation=get_op_f();
    while (operation !=end_of_tape) {
      //printf("operation %d \n", operation);
        switch (operation) {

                /****************************************************************************/
                /*                                                                  MARKERS */

                /*--------------------------------------------------------------------------*/
            case end_of_op:                                          /* end_of_op */
                robtape(operation,0,loc_a,val_a,0,cst_d, vlist,v_values, vd_values);
                get_op_block_f();
                operation=get_op_f();
                /* Skip next operation, it's another end_of_op */
                break;

                /*--------------------------------------------------------------------------*/
            case end_of_int:                                        /* end_of_int */
                robtape(operation,0,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
                get_loc_block_f();
                break;

                /*--------------------------------------------------------------------------*/
            case end_of_val:                                        /* end_of_val */
                robtape(operation,0,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                get_val_block_f();
                break;

                /*--------------------------------------------------------------------------*/
            case start_of_tape:                                  /* start_of_tape */
                robtape_start(operation, vlist,v_values, vd_values, direction);
		//cout<<"finnished start"<<endl;
		//v_values->print();
                break;

                /*--------------------------------------------------------------------------*/
            case end_of_tape:                                      /* end_of_tape */
                break;


                /****************************************************************************/
                /*                                                               COMPARISON */

                /*--------------------------------------------------------------------------*/
            case eq_zero  :                                            /* eq_zero */
            case neq_zero :                                           /* neq_zero */
            case le_zero  :                                            /* le_zero */
            case gt_zero  :                                            /* gt_zero */
            case ge_zero  :                                            /* ge_zero */
            case lt_zero  :                                            /* lt_zero */
                arg  = get_locint_f();
                loc_a[0] = arg;
#ifdef computenumbers
                val_a[0] = dp_T0[arg];
#endif
                robtape(operation,1,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;


                /****************************************************************************/
                /*                                                              ASSIGNMENTS */

                /*--------------------------------------------------------------------------*/
            case assign_a:           /* assign an adouble variable an    assign_a */
                /* adouble value. (=) */
                arg = get_locint_f();
                res = get_locint_f();
                loc_a[0]=arg;
                loc_a[1]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                dp_T0[res]= dp_T0[arg];
                val_a[1]=dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case assign_d:            /* assign an adouble variable a    assign_d */
                /* double value. (=) */
                res  = get_locint_f();
                cst_d[0]=get_val_f();
                loc_a[0]=res;
#ifdef computenumbers
                dp_T0[res]= cst_d[0];
                val_a[0]=dp_T0[res];
#endif
                robtape(operation,1,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case assign_d_one:    /* assign an adouble variable a    assign_d_one */
                /* double value. (1) (=) */
                res  = get_locint_f();
                loc_a[0]=res;
#ifdef computenumbers
                dp_T0[res]= 1.0;
                val_a[0]=dp_T0[res];
#endif
                robtape(operation,1,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case assign_d_zero:  /* assign an adouble variable a    assign_d_zero */
                /* double value. (0) (=) */
                res  = get_locint_f();
                loc_a[0]=res;
#ifdef computenumbers
                dp_T0[res]= 0.0;
                val_a[0]=dp_T0[res];
#endif
                robtape(operation,1,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case assign_ind:       /* assign an adouble variable an    assign_ind */
                /* independent double value (<<=) */
                res = get_locint_f();
		//Mark this node as the indexi th independent
		new_loc[res] = indexi;
                loc_a[0]=res;
#ifdef computenumbers
                dp_T0[res]= basepoint[indexi];
                cst_d[0]= basepoint[indexi];
                val_a[0]=dp_T0[res];
                robtape(operation,1,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		if(vd_values!= NULL)
		  forward_indep(operation,1,loc_a,val_a,0,cst_d, vd_values, direction,indexi);
#else
                robtape(operation,1,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		if(vd_values!= NULL)
		  forward_indep(operation,1,loc_a,val_a,0,cst_d, vd_values, direction,indexi);
#endif
		// Renaming all intermediate nodes that came before this independent and after the last independent found
		for (rob_count = last_ind+1; rob_count < res; rob_count++){
		    new_loc[rob_count] = indcheck+(rob_count-indexi);
		}
                indexi++;
		last_ind = res;
                break;

                /*--------------------------------------------------------------------------*/
            case assign_dep:           /* assign a float variable a    assign_dep */
                /* dependent adouble value. (>>=) */
                res = get_locint_f();
		
                loc_a[0]=res;
		//dep_index = res;
		//cout<<"DEP:::  res :"<<res<<" dp_T0[res] "<<dp_T0[res]<<endl;
#ifdef computenumbers
                val_a[0]=dp_T0[res];
                valuepoint[indexd++]=dp_T0[res];
#endif
                robtape(operation,1,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;


                /****************************************************************************/
                /*                                                   OPERATION + ASSIGNMENT */

                /*--------------------------------------------------------------------------*/
            case eq_plus_d:            /* Add a floating point to an    eq_plus_d */
                /* adouble. (+=) */
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0] = res;
                cst_d[0] = coval;
#ifdef computenumbers
                dp_T0[res] += coval;
                val_a[0] = dp_T0[res];
#endif
                robtape(operation,1,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case eq_plus_a:             /* Add an adouble to another    eq_plus_a */
                /* adouble. (+=) */
                arg  = get_locint_f();
                res  = get_locint_f();
                loc_a[0]=arg;
                loc_a[1]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                dp_T0[res]+= dp_T0[arg];
                val_a[1]=dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case eq_plus_prod:    /* Add an product to an            eq_plus_prod */
                /* adouble. (+= x1*x2) */
                arg1 = get_locint_f();
                arg2 = get_locint_f();
                res  = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                val_a[1]=dp_T0[arg2];
                dp_T0[res] += dp_T0[arg1]*dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case eq_min_d:       /* Subtract a floating point from an    eq_min_d */
                /* adouble. (-=) */
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0] = res;
                cst_d[0] = coval;
#ifdef computenumbers
                dp_T0[res] -= coval;
                val_a[0] = dp_T0[res];
#endif
                robtape(operation,1,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case eq_min_a:        /* Subtract an adouble from another    eq_min_a */
                /* adouble. (-=) */
                arg  = get_locint_f();
                res  = get_locint_f();
                loc_a[0]=arg;
                loc_a[1]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                dp_T0[res]-= dp_T0[arg];
                val_a[1]=dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case eq_min_prod:     /* Subtract an product from an      eq_min_prod */
                /* adouble. (+= x1*x2) */
                arg1 = get_locint_f();
                arg2 = get_locint_f();
                res  = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                val_a[1]=dp_T0[arg2];
                dp_T0[res] -= dp_T0[arg1]*dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case eq_mult_d:              /* Multiply an adouble by a    eq_mult_d */
                /* flaoting point. (*=) */
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0] = res;
                cst_d[0] = coval;
#ifdef computenumbers
                dp_T0[res] *= coval;
                val_a[0] = dp_T0[res];
#endif
                robtape(operation,1,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case eq_mult_a:       /* Multiply one adouble by another    eq_mult_a */
                /* (*=) */
                arg  = get_locint_f();
                res  = get_locint_f();
                loc_a[0]=arg;
                loc_a[1]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                dp_T0[res]*= dp_T0[arg];
                val_a[1]=dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case incr_a:                        /* Increment an adouble    incr_a */
                res = get_locint_f();
                loc_a[0] = res;
#ifdef computenumbers
                dp_T0[res]++;
                val_a[0] = dp_T0[res];
#endif
                robtape(operation,1,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case decr_a:                        /* Increment an adouble    decr_a */
                res = get_locint_f();
                loc_a[0] = res;
#ifdef computenumbers
                dp_T0[res]--;
                val_a[0] = dp_T0[res];
#endif
                robtape(operation,1,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;


                /****************************************************************************/
                /*                                                        BINARY OPERATIONS */

                /*--------------------------------------------------------------------------*/
            case plus_a_a:                 /* : Add two adoubles. (+)    plus a_a */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                val_a[1]=dp_T0[arg2];
                dp_T0[res]=dp_T0[arg1]+dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case plus_d_a:             /* Add an adouble and a double    plus_d_a */
                /* (+) */
                arg   = get_locint_f();
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0] = arg;
                loc_a[1] = res;
                cst_d[0] = coval;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                dp_T0[res]= dp_T0[arg] + coval;
                val_a[1]=dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case min_a_a:              /* Subtraction of two adoubles     min_a_a */
                /* (-) */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                val_a[1]=dp_T0[arg2];
                dp_T0[res]=dp_T0[arg1]-dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case min_d_a:                /* Subtract an adouble from a    min_d_a */
                /* double (-) */
                arg   = get_locint_f();
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0] = arg;
                loc_a[1] = res;
                cst_d[0] = coval;
#ifdef computenumbers
                val_a[0] = dp_T0[arg];
                dp_T0[res]  = coval - dp_T0[arg];
                val_a[1] = dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case mult_a_a:               /* Multiply two adoubles (*)    mult_a_a */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                val_a[1]=dp_T0[arg2];
                dp_T0[res]=dp_T0[arg1]*dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case mult_d_a:         /* Multiply an adouble by a double    mult_d_a */
                /* (*) */
                arg   = get_locint_f();
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0] = arg;
                loc_a[1] = res;
                cst_d[0] = coval;
#ifdef computenumbers
                val_a[0] = dp_T0[arg];
                dp_T0[res]  = coval * dp_T0[arg];
                val_a[1] = dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case div_a_a:           /* Divide an adouble by an adouble    div_a_a */
                /* (/) */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                val_a[1]=dp_T0[arg2];
                dp_T0[res]=dp_T0[arg1]/dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case div_d_a:             /* Division double - adouble (/)    div_d_a */
                arg   = get_locint_f();
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0] = arg;
                loc_a[1] = res;
                cst_d[0] = coval;
#ifdef computenumbers
                val_a[0] = dp_T0[arg];
                dp_T0[res]  = coval / dp_T0[arg];
                val_a[1] = dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;


                /****************************************************************************/
                /*                                                         SIGN  OPERATIONS */

                /*--------------------------------------------------------------------------*/
            case pos_sign_a:                                        /* pos_sign_a */
                arg  = get_locint_f();
                res  = get_locint_f();
                loc_a[0]=arg;
                loc_a[1]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                dp_T0[res]= dp_T0[arg];
                val_a[1]=dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case neg_sign_a:                                        /* neg_sign_a */
                arg  = get_locint_f();
                res  = get_locint_f();
                loc_a[0]=arg;
                loc_a[1]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                dp_T0[res]= -dp_T0[arg];
                val_a[1]=dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;


                /****************************************************************************/
                /*                                                         UNARY OPERATIONS */

                /*--------------------------------------------------------------------------*/
            case exp_op:                          /* exponent operation    exp_op */
                arg  = get_locint_f();
                res  = get_locint_f();
                loc_a[0]=arg;
                loc_a[1]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                dp_T0[res]= exp(dp_T0[arg]);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case sin_op:                              /* sine operation    sin_op */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                /* olvo 980923 changed order to allow x=sin(x) */
                val_a[0]=dp_T0[arg1];
                dp_T0[arg2]= cos(dp_T0[arg1]);
                dp_T0[res] = sin(dp_T0[arg1]);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case cos_op:                            /* cosine operation    cos_op */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                /* olvo 980923 changed order to allow x=cos(x) */
                val_a[0]=dp_T0[arg1];
                dp_T0[arg2]= sin(dp_T0[arg1]);
                dp_T0[res] = cos(dp_T0[arg1]);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case atan_op:                                              /* atan_op */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                dp_T0[res] = atan(dp_T0[arg1]);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case asin_op:                                              /* asin_op */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                dp_T0[res] = asin(dp_T0[arg1]);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case acos_op:                                              /* acos_op */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                dp_T0[res] = acos(dp_T0[arg1]);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

#ifdef ATRIG_ERF

                /*--------------------------------------------------------------------------*/
            case asinh_op:                                            /* asinh_op */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                dp_T0[res] = asinh(dp_T0[arg1]);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case acosh_op:                                           /* acosh_op */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                dp_T0[res] = acosh(dp_T0[arg1]);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case atanh_op:                                            /* atanh_op */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                dp_T0[res] = atanh(dp_T0[arg1]);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case erf_op:                                                /* erf_op */
                arg1 = get_locint_f();
                arg2 = get_locint_f();
                res  = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                dp_T0[res] = erf(dp_T0[arg1]);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

#endif
                /*--------------------------------------------------------------------------*/
            case log_op:                                                /* log_op */
                arg  = get_locint_f();
                res  = get_locint_f();
                loc_a[0]=arg;
                loc_a[1]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                dp_T0[res]= log(dp_T0[arg]);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case pow_op:                                                /* pow_op */
                arg  = get_locint_f();
                res  = get_locint_f();
                coval   = get_val_f();
                cst_d[0]=coval;
                loc_a[0]=arg;
                loc_a[1]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                dp_T0[res] = pow(dp_T0[arg],coval);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case sqrt_op:                                              /* sqrt_op */
                arg  = get_locint_f();
                res  = get_locint_f();
                loc_a[0]=arg;
                loc_a[1]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                dp_T0[res]= sqrt(dp_T0[arg]);
                ADOLC_OPENMP_RESTORE_THREAD_NUMBER;
                val_a[1]=dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case gen_quad:                                            /* gen_quad */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                cst_d[0] = get_val_f();
                cst_d[1] = get_val_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                loc_a[2]=res;
#ifdef computenumbers
                val_a[0]=dp_T0[arg1];
                dp_T0[res] = cst_d[1];
                val_a[1]=dp_T0[arg2];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,2,cst_d, vlist,v_values,vd_values);
                break;

                /*--------------------------------------------------------------------------*/
            case min_op:                                                /* min_op */
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0] = arg1;
                loc_a[1] = arg2;
                loc_a[2] = res;
                cst_d[0] = coval;
#ifdef computenumbers
                val_a[0] = dp_T0[arg1];
                val_a[1] = dp_T0[arg2];
                if (dp_T0[arg1] > dp_T0[arg2])
                    dp_T0[res] = dp_T0[arg2];
                else
                    dp_T0[res] = dp_T0[arg1];
                val_a[2] = dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
                break;

                /*--------------------------------------------------------------------------*/
            case abs_val:                                              /* abs_val */
                arg   = get_locint_f();
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0] = arg;
                loc_a[1] = res;
                cst_d[0] = coval;
#ifdef computenumbers
                val_a[0] = dp_T0[arg];
                dp_T0[res]  = fabs(dp_T0[arg]);
                val_a[1] = dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case ceil_op:                                              /* ceil_op */
                arg   = get_locint_f();
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0] = arg;
                loc_a[1] = res;
                cst_d[0] = coval;
#ifdef computenumbers
                val_a[0] = dp_T0[arg];
                dp_T0[res]  = ceil(dp_T0[arg]);
                val_a[1] = dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case floor_op:                 /* Compute ceil of adouble    floor_op */
                arg   = get_locint_f();
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0] = arg;
                loc_a[1] = res;
                cst_d[0] = coval;
#ifdef computenumbers
                val_a[0] = dp_T0[arg];
                dp_T0[res]  = floor(dp_T0[arg]);
                val_a[1] = dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;


                /****************************************************************************/
                /*                                                             CONDITIONALS */

                /*--------------------------------------------------------------------------*/
            case cond_assign:                                      /* cond_assign */
                arg   = get_locint_f();
                arg1  = get_locint_f();
                arg2  = get_locint_f();
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0]=arg;
                loc_a[1]=arg1;
                loc_a[2]=arg2 ;
                loc_a[3]=res;
                cst_d[0]=coval;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                val_a[1]=dp_T0[arg1];
                val_a[2]=dp_T0[arg2];
                if (dp_T0[arg]>0)
                    dp_T0[res]=dp_T0[arg1];
                else
                    dp_T0[res]=dp_T0[arg2];
                val_a[3]=dp_T0[res];
#endif
                robtape(operation,4,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
                break;

                /*--------------------------------------------------------------------------*/
            case cond_assign_s:                                  /* cond_assign_s */
                arg   = get_locint_f();
                arg1  = get_locint_f();
                res   = get_locint_f();
                coval = get_val_f();
                loc_a[0]=arg;
                loc_a[1]=arg1;
                loc_a[2]=res;
                cst_d[0]=coval;
#ifdef computenumbers
                val_a[0]=dp_T0[arg];
                val_a[1]=dp_T0[arg1];
                if (dp_T0[arg]>0)
                    dp_T0[res]=dp_T0[arg1];
                val_a[2]=dp_T0[res];
#endif
                robtape(operation,3,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
                break;


                /****************************************************************************/
                /*                                                          REMAINING STUFF */

                /*--------------------------------------------------------------------------*/
            case take_stock_op:                                  /* take_stock_op */
                size = get_locint_f();
                res  = get_locint_f();
                d    = get_val_v_f(size);
                loc_a[0] = size;
                loc_a[1] = res;
                cst_d[0] = d[0];
#ifdef computenumbers
                for (l=0; l<size; l++)
                    dp_T0[res+l] = d[l];
                val_a[0] = make_nan();
                val_a[1] = dp_T0[res];
#endif
                robtape(operation,2,loc_a,val_a,1,cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            case death_not:                                          /* death_not */
                arg1 = get_locint_f();
                arg2 = get_locint_f();
                loc_a[0]=arg1;
                loc_a[1]=arg2;
                robtape(operation,2,loc_a,val_a,0,cst_d, vlist,v_values,vd_values);
		
                break;

                /****************************************************************************/
            case ext_diff:
                loc_a[0] = get_locint_f() + 1; /* index */
                loc_a[1] = get_locint_f(); /* n */
                loc_a[2] = get_locint_f(); /* m */
                loc_a[3] = get_locint_f(); /* xa[0].loc */
                loc_a[3] = get_locint_f(); /* ya[0].loc */
                loc_a[3] = get_locint_f(); /* dummy */
                robtape(operation, 3, loc_a, val_a, 0, cst_d, vlist,v_values,vd_values);
		
                break;

                /*--------------------------------------------------------------------------*/
            default:                                                   /* default */
                /* Die here, we screwed up */
                fprintf(DIAG_OUT,"ADOL-C error: Fatal error in tape_doc for op %d\n",
                        operation);
                break;

        } /* endswitch */

        /* Read the next operation */
        operation=get_op_f();
    }  /* endwhile */

    if (operation == end_of_tape) {
        robtape_end(operation, vlist);
//	for( tempi =0; tempi < num_deps ; tempi++){
//	  cout<<"new_loc["<<tempi<<"] "<<new_loc[tempi]<<endl;
//	}
	rename_independents(vlist,v_values,vd_values, new_loc, indcheck);
	delete[] new_loc;		
    }

    free(dp_T0);
    dp_T0 = NULL;

    end_sweep();
  }
  
  void rename_independents(opt_list *vlist, Graph * v_values,Graph * vd_values, int * new_loc, int n){
    int temp;
    int tempi,j ;
    Block tempB;
    opt * aux;
    Block * temp_values =NULL;
    int graph_size;
    aux = vlist->head;
    // vlist->print();
    int num_dependents = 	ADOLC_CURRENT_TAPE_INFOS.stats[NUM_MAX_LIVES];
    
    if(v_values!=NULL){
      //  cout<<"v_values->N "<<v_values->N<<endl;
      temp_values = new Block [num_dependents]; 
      //First swap the values associated to nodes    
      for(j=0; j<num_dependents ; j++){
	if(new_loc[j]!=-1)
	 // &(temp_values[new_loc[j]]) = &(v_values->B[j]);
	  temp_values[new_loc[j]].copy(v_values->B[j]);
      }// end of for j
    }//Values != Null
    while(aux!=NULL){
      // cout<<aux->vi<<" "<<aux->son[0]<<" "<<aux->son[1]<<" func "<<aux->func<<endl; 
      // Then swap their names    
      if(new_loc[aux->vi]!=-1)
	aux->vi = new_loc[aux->vi];
      
      if(aux->son[0]>0)
	if(new_loc[aux->son[0]]!=-1)
	  aux->son[0] = new_loc[aux->son[0]];
	if(aux->son[1]>0)
	  if(new_loc[aux->son[1]]!=-1)
	    aux->son[1] = new_loc[aux->son[1]];  
	  // cout<<aux->vi<<" "<<aux->son[0]<<" "<<aux->son[1]<<" func "<<aux->func<<endl;
	aux = aux->next;
    }// End of while*/
    
    if(v_values!=NULL){
      for(j =0; j<num_dependents; j++){
	if(!temp_values[j].isempty()){
	  v_values-> copy_neighbors(temp_values[j],j);
	}
      }
    }
  
  if(vd_values!=NULL){
    //  cout<<"v_values->N "<<v_values->N<<endl;
    //First swap the values associated to nodes    
    for(j=0; j<num_dependents ; j++){
      if(new_loc[j]!=-1)
	temp_values[new_loc[j]].copy(vd_values->B[j]);
    }// end of for j
  }//Values != Null
  if(vd_values!=NULL){
    for(j =0; j<num_dependents; j++){
      //	cout<<"temp_values[j].isempty() "<<temp_values[j].isempty()<<endl;
      if(!temp_values[j].isempty()){
	vd_values->B[j].copy(temp_values[j]);
	//	    cout<<"temp values "<<j<<endl;
	//	    temp_values[j].print();
      }
    }
  }//*/
  
    if(temp_values!= NULL)
      delete [] temp_values;
  }
  void deriv_info::print(){
    int i ,j ,k;
    for(i = 0; i<2 ;i++)
	if(grad[i]!=0.0)
	  cout<<"grad["<<i<<"] "<<grad[i]<<endl;    
  
    for(i = 0; i<2 ;i++)
      for(j = 0; j<i+1 ;j++)
	  if(hess[i][j] !=0)
	    cout<<"hess["<<i<<"]["<<j<<"] "<<hess[i][j]<<endl;    
	
    for(i = 0; i<2 ;i++)
      for(j = 0; j<i+1 ;j++)
	for(k = 0; k<j+1 ;k++){
	  if(tens[i][j][k] !=0)
	   cout<<"tens["<<i<<"]["<<j<<"]["<<k<<"] "<<tens[i][j][k]<<endl;    
	}
    }
    void  opt_list::print(){
     opt * temp;
     temp = head;
     while(temp!=NULL){
      if(temp->const_double== 0.0 )
       cout<<temp->vi<<" "<<temp->son[0]<<" "<<temp->son[1]<<" "<<temp->func<<endl;
      else
       cout<<temp->vi<<" "<<temp->son[0]<<" "<<temp->son[1]<<" "<<temp->func<<" const "<<temp->const_double<<endl;
      temp = temp->next;
     }
    }
    void  opt::print(){
     cout<<vi<<" "<<son[0]<<" "<<son[1]<<" "<<func<<" const "<<const_double<<endl;
    }    
    
    int derivative_info_internal(deriv_info * der, double const_double, int opcode, double * x_var){
      /*
      return 0 if failed (singularity, discontinuity ..)
      return 1 if success.
      */
      int i,j,k;
      double z = x_var[0];
      double x = x_var[1];
      double y = x_var[2];  
      
      der->grad[0] = 0.0;
      der->grad[1] = 0.0;
      der->hess[1][0] = 0.0;
      der->hess[1][1] = 0.0;
      der->hess[0][0] = 0.0;
      
      for(i = 0; i<2 ;i++)
	for(j = 0; j<i+1 ;j++)
	  for(k = 0; k<j+1 ;k++)
	      der->tens[i][j][k] =0.0;
      
      switch (opcode){
	case  assign_ind: 	//	1
	  break;
	case  assign_dep: 	//	2
	  der->grad[0] = 1.0;
	  break;
	case  assign_a: 	//	3
	  der->grad[0] = 1.0;
	  break;
	case  assign_d:	//	4
	  break;
	case eq_plus_d: //	5
	  der->grad[1] = 1.0;
	  break;
	case eq_plus_a: //	6
	  der->grad[0] = 1.0;
	  der->grad[1] = 1.0;
	  break;
	case  eq_min_d: //	7
	  //der->grad[0] = 1.0;
	  der->grad[1] = 1.0;
	  break;	    
	case eq_min_a  : //	8
	  der->grad[0] = -1.0;
	  der->grad[1] = 1.0;
	  break;
	case eq_mult_d: //	9
	  //der->grad[0] = -1.0;
	  der->grad[1] = const_double;
	  break;	
	case eq_mult_a: //	10
	  der->grad[0] = y;
	  der->grad[1] = x;	       
	  der->hess[1][0] = 1.0;
	  break;	
	case plus_a_a:	//	11
	  der->grad[0] = 1.0;
	  der->grad[1] = 1.0;	
	  break;
	case plus_d_a:	//	12
	  der->grad[0] = 1.0;
	  break;
	case  min_a_a:	//	13
	  der->grad[0] = 1.0;
	  der->grad[1] = -1.0;	
	  break;
	case min_d_a:	//	14
	  der->grad[0] = -1.0;
	  break;
	case mult_a_a:	//	15
	  der->grad[0] = y;
	  der->grad[1] = x;	       
	  der->hess[1][0] = 1.0;	
	  break;
	case  mult_d_a:	//	16
	  der->grad[0] = const_double;
	  break;
	  
	case  div_a_a:	//	17
	  // x/y
	  if(y==0.0)  cout<<"Divided by zero in div_a_a"<<endl;
	  else{
	    der->grad[0] = 1/y;
	    der->grad[1] = -x/(y*y);
	    der->hess[1][1] = 2*x/(pow(y,3));
	    der->hess[1][0] = -1/(y*y); 
	    der->tens[1][1][0] = 2/(pow(y,3));
	    der->tens[1][1][1] = -6*x/(pow(y,4));
	    //der->tens[1][0] = -1/(y*y); 
	  }
	  break;
	  
	case  div_d_a:	//	18
	  //const_double /x
	  if(x==0.0)  cout<<"Divided by zero in div_d_a"<<endl;
	  else{
	    der->grad[0] = -(const_double)/(x*x);
	    der->hess[0][0]= 2*const_double/(pow(x,3));
	    der->tens[0][0][0]= -6*const_double/(pow(x,4));
	  }
	  break;
	case  exp_op:	//	19
	  der->grad[0] = z;       
	  der->hess[0][0] = z;	
	  der->tens[0][0][0] = z;
	  break;
	case cos_op:	//	20
	  der->grad[0] = -sin(x);       
	  der->hess[0][0] = -cos(x);
	  der->tens[0][0][0] = sin(x);	  
	  break;
	case sin_op:	//	20
	  der->grad[0] = cos(x);       
	  der->hess[0][0] = -sin(x);
	  der->tens[0][0][0] = -cos(x);	 
	  break;
	  //	atan_op,	//	22 arc tangent
	case log_op:	//	23
	  if(x!=0.0){
	    der->grad[0] = 1/x;       
	    der->hess[0][0] = -1/(x*x);
	    der->tens[0][0][0] = 2/(x*x*x);	 
	  }else{
	    cout<<"singularity, x=0.0 for log"<<endl; 
	  }
	  break;
	case pow_op:	//	24
	  // there is no actual x^y only x^c.
	  if(const_double ==0){ break;}
	  else if(const_double-1 <0 && x==0.0){ cout<<"pow_op divided by zero! grad singular"<<endl;}
	  else{
	    der->grad[0] = const_double*pow(x,const_double-1);  
	    if(const_double ==1.0){ break;}
	    else if(const_double-2.0<0 && x==0.0){cout<<"pow_op divided by zero! hess singular"<<endl;}
	    else{
	       der->hess[0][0] = const_double*(const_double-1)*pow(x,const_double-2);
	       if(const_double ==2.0){ break;}
	       else if(const_double-3.0<0 && x==0.0) {cout<<"pow_op divided by zero! tens singular"<<endl;}
	       else der->tens[0][0][0] = const_double*(const_double-1)*(const_double-2)*pow(x,const_double-3);
	    } 
	  }//*/
	 /*  der->grad[0] = const_double*pow(x,const_double-1);
	   der->hess[0][0] = const_double*(const_double-1)*pow(x,const_double-2);
	   der->tens[0][0][0] = const_double*(const_double-1)*(const_double-2)*pow(x,const_double-3);//*/
	  break;	       
	  //	asin_op,	//	25
	 //	acos_op,	//	26     
	case sqrt_op:	//	20
	  if(x==0.0) {cout<<"sqrt_op divided by zero! Ders are singular"<<endl;}
	  else{
	    der->grad[0] = 0.5*pow(x,-0.5);       
	    der->hess[0][0] = -0.25*pow(x,-1.5);  
	    der->tens[0][0][0] = (0.375)*pow(x,-2.5);  }
	  break;
	  /*	       
	  asinh_op,	//	28
					    acosh_op,	//	29
					    atanh_op,	//	30
					    gen_quad,	//	31
					    end_of_tape,	//	32
					    start_of_tape,	//	33
					    end_of_op,	//	34
					    end_of_int,	//	35
					    end_of_val,	//	36*/
	  case cond_assign:	//	37 put an if case to eliminate a son
	    /*
	    cond_assign(a,b,c,d) =
	    if(b>0)
	    a=c;
	    else     
	      a=d;
	    
	    in our case:
	    
	    cond_assign(z,x.y. const_double)
	    
	    */
	    //cout<<"condassign   x, y, z, const; "<<x<<" ,"<<y<<" ,"<<z<<" ,"<<const_double<<" "<<endl;
	    //cin>>i;
	    if(const_double >0)
	      der->grad[0] = 1;
	    else
	      der->grad[1] = 1;
	    //der->grad[0] = 1;
	    //der->grad[1] = 1;
	    break;
	  case cond_assign_s:	//	38
	    if(x==z)
	      der->grad[0] = 1;
	    else if(y==z)
	      der->grad[1] = 1;
	    //der->grad[0] = 1;
	    //der->grad[1] = 1;
	    break;
	    /*
	    take_stock_op,	//	39
	    */
	    case assign_d_one:	//	42 ??
	      der->grad[0] = 0;
	      der->grad[1] = 0;		
	      break;  
	    case assign_d_zero:	//	42 ??
	      der->grad[0] = 0;
	      der->grad[1] = 0;		
	      break;	  
	    case incr_a:	//	42 ??
	      der->grad[0] = 1;
	      break;	  
	    case  decr_a:	//	43 ??
	      der->grad[0] = 1;
	      break;
	    case neg_sign_a:	//	44
	      der->grad[0] = -1;
	      break;
	    case pos_sign_a:	//	45
	      der->grad[0] = 1;
	      break;
	    case min_op:	//	46
	      if(x>y){
		der->grad[1] = 1;
	      }
	      else if(x==y){
		cout<<"x==y"<<endl;
		cin>>z;
		der->grad[0] = 1;
		der->grad[1] = 1;
	      }
	      else if(x<y){
		der->grad[0] = 1;
	      }
	      break;
	    case abs_val:	//	47
	      if(x>=0)
		der->grad[0] = 1;
	      else
		der->grad[0] = -1;	
	      break;
	      /*eq_zero,	//	48 these dont really work in ADOL-c
	      neq_zero,	//	49
	      le_zero,	//	50
	      gt_zero,	//	51
	      ge_zero,	//	52
	      
	      lt_zero,	//	53*/
	      //	
	    case eq_plus_prod:	//	54
	      der->grad[0] = y;
	      der->grad[1] = x;	       
	      der->hess[1][0] = 1;	
	      break;
	    case eq_min_prod:	//	55
	      der->grad[0] = -y;
	      der->grad[1] = -x;	       
	      der->hess[1][0] = -1;	
	      break;	       
	      /*
	      erf_op,	//	56
	      ceil_op,	//	57 //constant or discontinious
	      floor_op,	//	58 //constant or discontinious
	      ext_diff,	//	59
	      ignore_me,	//	60 */
	      default: //cout<<"dont know this opt:"<<opt<<endl; 
	      break;
      }
      return(0);
    }   
/****************************************************************************/
/*                                                               THAT'S ALL */


END_C_DECLS
