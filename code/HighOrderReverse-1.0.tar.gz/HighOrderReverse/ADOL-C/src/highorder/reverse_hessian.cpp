
#include <string.h>
#include <stdio.h>
#include <sys/time.h>
//#include <dos.h>
#include <math.h>
#include <sys/types.h>
#include <adolc/highorder/graph_blocks.h>
#include <adolc/highorder/reverse_hessian.h>
#include <adolc/highorder/translate_tape.h>
#include <adolc/highorder/reverse_hessian_internal_blocks.h>
#include <adolc/highorder/sparsity_pattern_internal_blocks.h>
#include <oplate.h>
using namespace std;

void insert_lag_head(opt_list * vlist, Graph * v_values, double *la, int m);

int sparsity_pattern(short tape_num,  Graph ** G, int N){
  int num_ops =0, nz,i;
  opt_list * vlist = new opt_list;
  //Graph values;
  double * x = new double [N];
  
  for(i=0; i<N;i++)
    x[i] = 1;
  
  num_ops = -1; //signals dont want values
  translate_tape(tape_num, x, vlist, NULL, NULL,NULL, N,1, num_ops); //&values
 // vlist->print();
  reuse_graph(G,vlist->max_active+1);
  //cout<<"pattern"<<endl;
  sparsity_pattern_internal_blocks(vlist, N, *G);
  delete [] x;
  delete vlist;
  //G.graph_to_sparse_matrix(&I, &J,&vals,&nz);  
}
int reverse_hessian(short tape_num, double * x, double ** grad, Graph ** G, int N, int * options)
{ 
  int num_ops =0,i;
  int max_active;
  opt_list * vlist = new opt_list;
  Graph * values;
  values = new Graph;
 
  translate_tape(tape_num, x, vlist, values, NULL,NULL, N,1, num_ops);
  //Getting the number of unique labels in tape. 
  max_active = vlist->max_active+1;
  //vlist->print();
  
  reuse_graph(G,max_active);
  if((*grad)==NULL)
      (*grad) = new double [max_active];
  reverse_hessian_internal_blocks(vlist, values, *grad, *G, N);
  (*G)->count_nz();
  
  delete(vlist);
  delete(values);
  return(1);
}
/*
int reverse_hessian_lag(short tape_num, double *x, double *la, Graph ** E, int N, int M, int repeat ){
  
  double c0,c1;
  int num_ops =0, nz,i;
  int max_active;
  opt_list * vlist = new opt_list;
  Graph * values;
  values = new Graph;
  struct timeval start, end;
  long mtime, seconds, useconds;
  opt * aux;
  int extra =10;
  
  translate_tape(tape_num, x, vlist, values,N,M+1, num_ops);
  max_active = vlist->max_active;
  //   vlist->print();
  //   values->print();
  
  insert_lag_head(vlist, values, la, M );
  
  
  if(repeat==0){ cout<<"ALLOCATING GRAPH"<<endl; //cin>>i;
  *E = new Graph (max_active+extra);
  }
  else if((*E)==NULL){
    cout<<"Graph is empty when it should not be: EXITING"<<endl;
    return(0);
  }   
  else if((*E)->max_active != max_active+extra){
    cout<<"Needed graph with "<<max_active+extra<<" node, but supplied with "<<(*E)->N<<endl;
    cout<<"Call Reverse_hessian_lag witgh repeat= 0"<<endl;
    return(0);
  }
  
  
  (*E)->N = max_active+extra;
  (*E)->max_active = max_active+extra;
  
  gettimeofday(&(start), NULL);
  reverse_hessian_internal_blocks(vlist, values, *E, N);
  gettimeofday(&(end), NULL);
  
  seconds  = end.tv_sec  - start.tv_sec;
  useconds = end.tv_usec - start.tv_usec;
  
  (*E)->count_nz();
  nz = (*E)->nz;
  
  //mtime = ((seconds) * 1000 + useconds/1000.0) + 0.5;
  // printf("edge_pushing: %ld milliseconds\n", mtime);
  
  delete(vlist);
  delete(values);
  return(1);
  
}

int reverse_hessian_lag_3(short tape_num, double *x, double *la, int * nnz,  int ** row, int ** col, double **val, int N, int M, int repeat ){
  
  double c0,c1;
  int num_ops =0, nz,i;
  int max_active;
  opt_list * vlist = new opt_list;
  Graph * values;
  values = new Graph;
  struct timeval start, end;
  long mtime, seconds, useconds;
  opt * aux;
  
  translate_tape(tape_num, x, vlist, values,N,M+1, num_ops);
  
  max_active = vlist->max_active;
  cout<<"max_active+3 "<<max_active+3<<endl;
  static Graph * E = new Graph (max_active+3);
  vlist->print();
  values->print();
  //  insert_lag_head(vlist, values, la, M );
  cout<<"after lad head"<<endl;
  vlist->print();
  values->print();
  cout<<"lambda: "<<endl;
  for(i=0; i<M; i++)
    cout<<la[i]<<" ";
  cout<<endl;
  cin>>i;
  
  E->N = max_active+3;
  E->max_active = max_active+3;
  E->print_square(0);
  
  cout<<"calling internal"<<endl;
  gettimeofday(&(start), NULL);
  reverse_hessian_internal_blocks(vlist, values, E, N);
  gettimeofday(&(end), NULL);
  cout<<"leaving"<<endl;
  seconds  = end.tv_sec  - start.tv_sec;
  useconds = end.tv_usec - start.tv_usec;
  
  
  E->convert_3_arrays((*row), (*col), (*val));
  (*nnz) = E->count_nz();
  
  //mtime = ((seconds) * 1000 + useconds/1000.0) + 0.5;
  //printf("edge_pushing: %ld milliseconds\n", mtime);
  
  delete(vlist);
  delete(values);
  cout<<"end internal Hess lang"<<endl;
  return(1);
  
}//*/

void insert_lag_head(opt_list * vlist, Graph * values, double * la, int m){
  /*
  Add an option that says "Lagrangian"
  Then allow F: R^n - R^{m+1}  tape input.
  Allow input parameters Lambda \in R^m. 
  
  then Add to tape m-1 elements which sum
  F_1 + \sum F_i \lambda_i = output node
  
  Calculate this Hessian.
  
  Sweep back through tape until you find all 
  m+1 dependentes and their numbers.
  
  
  I will have to use 
  max_active+1
  max_active+2
  max_active+3
  
  */
  
  int i;
  int * vdep = new int [m+1];
  int max_active = vlist->max_active;
  opt * aux, *temp, *newhead;
  int tophead = max_active+1;
  int latemp = max_active;
  int depnum;
  double cval;
  
  aux = vlist->head;
  temp = aux;
  i=0;
  while(aux!=NULL){
    while(aux!=NULL && aux->func!= assign_dep)
      aux= aux->next;
    
    if(aux!=NULL){     
      depnum = aux->vi; 
      
      if(i==m)
	break;
      temp = new opt;
      temp->next = aux->next;
      aux->next = temp;
      temp->vi =  depnum;
      temp->func = mult_d_a;
      temp->son[0] =  depnum;
      temp->son[1] = -1;
      values->insert_edge( depnum,0,0.0);
      vlist->length++;
      temp->const_double =la[m-i-1];
      i++;
      aux= aux->next;
    }
  }
  
  
  return;
}
