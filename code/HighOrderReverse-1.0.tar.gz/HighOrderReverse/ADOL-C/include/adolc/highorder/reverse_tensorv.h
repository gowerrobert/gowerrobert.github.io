#if !defined(adolc_highorder_reverse_tensorv)
#define adolc_highorder_reverse_tensorv 1

#include <iostream>
#include <adolc/common.h>
#include <adolc/highorder/graph_blocks.h>
BEGIN_C_DECLS

/****************************************************************************/
/*                                                                 tape_doc */
/* tape_doc(tag, m, n, x[n], y[m])                                          */
ADOLC_DLL_EXPORT int reverse_tensorv(short, double *x, double ** grad, Graph ** E,Graph ** Td, int, double * direction, int * options);
END_C_DECLS

#endif