
#if !defined(adolc_reverse_internal)
#define adolc_reverse_internal 1

#include <adolc/common.h>
#include <adolc/highorder/graph_blocks.h>
#include <adolc/highorder/translate_tape.h>
#include <vector>
BEGIN_C_DECLS
#define Lin 0
#define NonL 1
#define BiL 2
#define Not_son -1

using namespace std;

int reverse_tensorv_internal(opt_list * v,Graph * values,  Graph * vd_values, double * grad, Graph *W, Graph *Td, int n);
void get_vd_predecessors(int vi, Graph * vd, int * son, double * vd_pred);
void creating_threeD(opt * v, deriv_info * der, double Adj, double * vd_pred, Graph * Td, Block * reused_node_block);
void connecting_twoD(opt * v, deriv_info * der, double * vd_pred, Graph * vd_values, Graph * W, Graph * Td, Block * reused_node_block);
END_C_DECLS

#endif
