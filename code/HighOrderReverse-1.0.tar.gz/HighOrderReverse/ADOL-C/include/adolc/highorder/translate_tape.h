
#if !defined(adolc_translate_tape)
#define adolc_translate_tape 1
#include <adolc/highorder/graph_blocks.h> //this order is important, everything uses graphs
//#include <adolc/highorder/ReverseHessian_internal_blocks.h>
//#include <iostream>
#include <adolc/common.h>
#define black_list (death_not || assign_ind)
BEGIN_C_DECLS
/****************************************************************************/
/*                                                                 tape_doc */
/* tape_doc(tag, m, n, x[n], y[m])   
*/
/*typedef struct deriv_info{
  double grad[3];
  double hess[3][3];  
  double tens[3][3][3];  
}deriv_info; */
//void print_der(deriv_info * der);
using namespace std;

class deriv_info{
  public:
    double grad[3];
    double hess[3][3];  
    double tens[3][3][3];    
    void print();
};


class opt{
   public:
   int vi;
   double const_double;
   int son[3];
//  int type[2];
// son[0] the index of the first variable 
//if son[1] is not -1,the index of the second variable  
   int func;
   opt * next;
   opt(){
      next = NULL;
      son[0] =-1;
      son[1] =-1;
      son[2] =-1;
   }
void print();
};

class opt_list{
  public:
opt * head;
int max_active;
int length;
   opt_list(){
      head = NULL;  
      length =0;
      max_active =0;
   }
  ~opt_list(){
       opt * start;
       opt *temp;
       start = head;
       if(start==NULL){  return; } 

       while(start!=NULL){
	 
	  temp = start;
	  start = start->next;
//	  if(temp->next!=NULL)
//	     temp->next->print();
	  delete(temp);
       }
       head=NULL;
       //cout<<"end list destructor"<<endl;   
  }
  void print();
};


void translate_tape(short tnum, double * x, opt_list * vlist, Graph * v_values, Graph * vd_values, double * direction, int N, int M, int num_ops); 
int derivative_info_internal(deriv_info * der, double const_double, int opcode, double *x_var);
END_C_DECLS

#endif
