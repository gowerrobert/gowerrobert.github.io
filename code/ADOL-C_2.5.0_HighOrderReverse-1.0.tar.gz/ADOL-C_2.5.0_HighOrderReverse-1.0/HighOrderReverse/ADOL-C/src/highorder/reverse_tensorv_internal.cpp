
#include <iostream>
#include <math.h>
#include <sys/time.h>
#include <adolc/highorder/graph_blocks.h>
#include <adolc/highorder/reverse_tensorv_internal.h>
#include <adolc/highorder/reverse_hessian_internal_blocks.h>
#include <adolc/highorder/translate_tape.h>
#include "oplate.h"

using namespace std;
void order_pair(int j, int k, int * ljk, int * sjk);
int reverse_tensorv_internal(opt_list * v, Graph * values,  Graph * vd_values, double* adjoints, Graph *W, Graph *Td, int n){
  
  // Just copy fos forward, it's almost exactly what you want. Just keep all the values (they obviously overwrite!)
  //Actually use translate_tape as template, uni5_for is a nightmare
  // Keep a simple long array of vd (v dots)
  int i,j,vi,k;
  int m = v->max_active+1;
  /* Allocating variables */
  deriv_info * der = new deriv_info;
  double * vd_pred = new double [2];
  Block * W_reused_neighbors;
  Block * Td_reused_neighbors;
  W_reused_neighbors =new  Block; 
  Td_reused_neighbors =new  Block;
  /*------------------------*/
  for(i=0; i<m; i++)
    adjoints[i]=0.0;
  
  int total_iter =0;
  opt * aux;
  
  aux = v->head;
  //Loops through all elements in tape
  while(aux!=NULL){
    vi = aux->vi;
    switch(aux->func){
      case assign_dep:
	// The start adjoint
	adjoints[vi]=1.0; 
	aux = aux->next;
	continue;
	break;
	//  case black_list:
      case death_not:
	aux = aux->next;
	continue;
	break;   
      case assign_ind:
        //derivative_info(aux, der, values);  
	//calculate_adjoint(aux, der, adjoints);
	aux = aux->next;
	continue;
	break;
      default:
	break;
    }  
    //cout<<"node: "<<vi<<" func "<<aux->func<<" sons "<<aux->son[0]<<","<<aux->son[1]<<endl;
    derivative_info(aux, der, values);  
    //der->print();
    get_vd_predecessors(vi,vd_values, aux->son,  vd_pred);
  //  cout<<"vd_pred: "<<vd_pred[0]<<","<<vd_pred[1]<<endl;
    if(aux->son[0]!= -1 || aux->son[1]!= -1 ){
      pushing(aux,  der,  Td, Td_reused_neighbors);
      connecting_twoD(aux,  der,  vd_pred,  vd_values,  W, Td, Td_reused_neighbors);
      creating_threeD(aux,  der,  adjoints[vi],  vd_pred,  Td,  Td_reused_neighbors);
    }
    reverse_hessian_iteration( aux, der, adjoints, values, W,  W_reused_neighbors);
    //removing current vi value from lists
    values->remove_end(vi);
    vd_values->remove_end(vi);
    //Reseting neighborhood structure for re-use
    Td->reset_neighbors(vi);
    if( Td_reused_neighbors->isempty()==0){
      Td->copy_neighbors(*Td_reused_neighbors, vi);
      Td_reused_neighbors->reset();
    }
    calculate_adjoint(aux, der, adjoints);
  /*  cout<<"adjoints: ";
    for(i=0; i<m; i++)
      cout<<adjoints[i]<<" ,";
    cout<<endl;//*/
    aux = aux->next;
    //  cout<<"print Td"<<endl;
    //  Td->print();
  }//end of while(aux) tape loop 
  W->N = n;  
  Td->N = n;
  delete W_reused_neighbors;
  delete Td_reused_neighbors;  
  delete[] vd_pred;
  delete der;
  return(0);
}
void get_vd_predecessors(int vi, Graph * vd, int * son, double * vd_pred){
  int i;
  //cout<<"get_vd_predecessors"<<endl;
  for (i = 0; i<2; i++)
    if(son[i]!=-1){
      // cout<<"getting for son "<<son[i]<<endl;
      vd_pred[i] = get_graph_last_in_value(vd,  vi, son[i]);
    }
}
void creating_threeD(opt * v, deriv_info * der, double Adj, double * vd_pred, Graph * Td, Block * reused_node_block){
  int p,j,k;
  int  son[2], vi;
  son[0] = v->son[0]; 
  son[1] = v->son[1]; 
  vi = v->vi; 
  /*cout<<"creating"<<endl;
  cout<<vi<<"  sons are: "<<son[0]<<"  and  "<<son[1]<<endl; //*/
  int opt = v->func;
  for(p=0; p<2; p++)
    for(j=0; j<2; j++)
      for(k=j; k<2;k++)
	if(son[j]!= -1 && son[k]!= -1){
	 // cout<<"(j,k,p)=("<<j<<","<<k<<","<<p<<")"<<endl;
	  if(p==0 && der->tens[k][j][0] != 0){ 
	    increment_edge(vi,son[k], son[j], der->tens[k][j][0]*Adj*vd_pred[0],  Td,reused_node_block);
	      //cout<<"create 3d by "<<vi<<" to ("<<son[k]<<","<<son[j]<<")"<<"  w  "<<der->tens[k][j][0]*Adj*vd_pred[0]<<endl;
	  }
	  else if(p==1 && der->tens[1][k][j]!= 0){
	    increment_edge(vi,son[k], son[j], der->tens[1][k][j]*Adj*vd_pred[1],  Td,reused_node_block);
	      //cout<<"create 3d by "<<vi<<" to ("<<son[k]<<","<<son[j]<<")"<<"  w  "<<der->tens[1][k][j]*Adj*vd_pred[1]<<endl;
	  }
	}
	//sons share a name! Fore each p, there should have been created three edge, two for each node. Instead,
	// only scanned once due to only tens[1][1][0] or tens[1][0][0] non-zero
	if(son[0]==son[1]  &&  son[1]!= -1){
	  for(p=0; p<2; p++)
	    if(p==0 && der->tens[1][0][0] != 0){
	      increment_edge(vi,son[k], son[j], der->tens[1][0][0]*Adj*vd_pred[0],  Td,reused_node_block);
	    }
	    else if(der->tens[1][1][0]!= 0){
	      increment_edge(vi,son[k], son[j], der->tens[1][1][0]*Adj*vd_pred[1],  Td,reused_node_block);
	    }
	}//*/	
}
void connecting_twoD(opt * v, deriv_info * der, double * vd_pred, Graph * vd_values, Graph * W, Graph * Td, Block * reused_node_block){
  int  z, start, last,k,j,p, lpj, lpz, spj, spz, neigh_count;
  double ww;
  double weight;
  double vdk;
  int opt = v->func;
  int  son[2], vi;
  son[0] = v->son[0]; 
  son[1] = v->son[1]; 
  vi = v->vi;
  
  start= W->get_first_position(vi);
  last= W->get_last_position(vi);
  
 // cout<<"connecting"<<endl;
  for(neigh_count=start; neigh_count< last+1; neigh_count++){  
    k=W->get_neighbor_node(vi,neigh_count);
    ww=W->get_edge_weight(vi,neigh_count);
   // cout<<"(vi,k,ww) ="<<"("<<vi<<","<<k<<","<<ww<<")"<<endl;
    if(k!=-1){
      if(k == vi){
	for(p=0; p<2; p++){
	  for(j=0; j<2; j++){
	    for(z=j; z<2;z++){
	      if(son[j]!= -1 && son[z]!= -1){
		//Get the largest index for the hess partial derivative
		order_pair(j, p, &lpj, &spj);
		order_pair(p, z, &lpz, &spz);
		weight = ww*vd_pred[p]*(der->grad[j]*der->hess[lpz][spz] +der->grad[z]*der->hess[lpj][spj]  + der->grad[p]*der->hess[z][j] );
		increment_edge(vi,son[z], son[j], weight,  Td,reused_node_block);
		/*cout<<"vd_pred[p]: "<<vd_pred[p]<<" ww  "<<ww<<" der->grad[j]*der->hess[lpz][spz]  "<<der->grad[j]*der->hess[lpz][spz]
		<<"der->grad[z]*der->hess[lpj][spj]  "<<der->grad[z]*der->hess[lpj][spj]<<" der->grad[p]*der->hess[z][j] "<<
		der->grad[p]*der->hess[z][j]<<endl;
		cout<<"Connecting 2D wii by "<<vi<<" to ("<<son[z]<<","<<son[j]<<")"<<"  w  "<<weight<<endl;//*/
	      }}}
	      //Account for sons sharing a name ?
	      if(son[0]==son[1]  &&  son[1]!= -1){
		j=0; z=1;
		order_pair(j, p, &lpj, &spj);
		order_pair(p, z, &lpz, &spz);
		weight = ww*vd_pred[p]*(der->grad[j]*der->hess[lpz][spz] +der->grad[z]*der->hess[lpj][spj]  + der->grad[p]*der->hess[z][j] );
		increment_edge(vi,son[0], son[1], weight,  Td,reused_node_block);
		//cout<<"connect 2D artifical loop! "<<vi<<" to ("<<son[0]<<","<<son[1]<<")"<<"  w  "<<weight<<endl;
	      }//*/
	}
      }
      else{
	for(p=0; p<2; p++)
	  for(j=0; j<2; j++){
	    // der->print();
	    order_pair(j, p, &lpj, &spj);
	    //cout<<" lpj "<<lpj<<" spj "<<spj<<"  der->hess[lpj][spj]: "<<der->hess[lpj][spj]<<endl;
	    if(son[j] == -1)
	       continue;
	    if(son[j] == k){
	      weight =2*ww*der->hess[lpj][spj]*vd_pred[p];
	      increment_edge(vi, k, k, weight,  Td,reused_node_block);
	   //   cout<<"Connecting 2D wik by son[j] ==k "<<vi<<" to ("<<son[j]<<","<<son[j]<<")"<<"  w  "<<weight<<endl;  
	    }
	    if(son[j] != k){
	      weight =ww*der->hess[lpj][spj]*vd_pred[p];
	      increment_edge(vi, son[j], k, weight,  Td,reused_node_block);	 
	      //cout<<"Connecting 2D wik by son[j] > k"<<vi<<" to ("<<son[j]<<","<<k<<")"<<"  w  "<<weight<<endl;
	    }
	    if(son[j] >= son[p]){
	      vdk =get_graph_last_in_value(vd_values,  vi, k);
	      //cout<<" vdk: "<<vdk;
	      weight =ww*der->hess[lpj][spj]*vdk;
	    //  cout<<"Connecting 2D wik by son[j] >= son[p]: "<<vi<<" to ("<<son[p]<<","<<son[j]<<")"<<"  w  "<<weight<<endl;
	      increment_edge(vi, son[j], son[p], weight,  Td,reused_node_block);	      
	    }
	  }
      }   
    }//end k!= -1
  }//end for neigh_count
  
}

void order_pair(int j, int k, int * ljk, int * sjk){
  if(j>k){
    *ljk = j;
    *sjk = k;
  }
  else{
    *ljk =k;
    *sjk = j;
  }
}