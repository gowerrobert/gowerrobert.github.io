
#include <string.h>
#include <stdio.h>
#include <sys/time.h>
//#include <dos.h>
#include <math.h>
#include <sys/types.h>
#include <adolc/highorder/graph_blocks.h>
#include <adolc/highorder/reverse_tensorv.h>
#include <adolc/highorder/translate_tape.h>
#include <oplate.h>
#include <adolc/highorder/reverse_tensorv_internal.h>
using namespace std;

int reverse_tensorv(short tape_num, double * x, double ** grad, Graph ** W, Graph ** Td, int N, double * direction, int * options)
{ 
  int num_ops =0,i;
  int max_active;
  opt_list * vlist = new opt_list;
  Graph * v_values;
  Graph * vd_values;
  v_values = new Graph;
  vd_values = new Graph;
  translate_tape(tape_num, x, vlist, v_values, vd_values,direction, N,1, num_ops);
  //Getting the number of unique labels in tape. 
  max_active = vlist->max_active+1;
  //vlist->print();
  //v_values->print();
  //cout<<"vd_values"<<endl;
  //vd_values->print();

  reuse_graph(W,max_active);
  reuse_graph(Td,max_active);
  if((*grad)==NULL)
      (*grad) = new double [max_active];
  
  reverse_tensorv_internal(vlist, v_values, vd_values,*grad, *W,*Td, N);
  
  (*W)->count_nz();
  (*Td)->count_nz();
  delete(vlist);
  delete(v_values);
  delete(vd_values);
  return(1);
}
