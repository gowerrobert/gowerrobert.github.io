
#include <iostream>
#include <vector>
#include <math.h>
#include <sys/time.h>
#include <adolc/highorder/graph_blocks.h>
#include <adolc/highorder/reverse_hessian_internal_blocks.h>
#include <adolc/highorder/translate_tape.h>
#include "oplate.h"
#define is_increment (func==eq_plus_d||func==eq_plus_a||func==eq_min_d||func==eq_min_a||func== eq_mult_d||func==eq_mult_a)
#define is_eq_prod (func==eq_plus_prod || func==eq_min_prod)
/*eq_plus_d,  //  5
eq_plus_a,    //  6
eq_min_d, //  7
eq_min_a, //  8
eq_mult_d,    //  9
eq_mult_a,    //  10
eq_plus_prod,   //  54
eq_min_prod,  //  55
*/
using namespace std;
//GLOBAL n and m, ARE YOU SURE?
int reverse_hessian_internal_blocks(opt_list * v, Graph * values, double * adjoints, Graph *W, int n){
  int i, vi;
  int m = v->max_active+1;
  
  /* Allocating variables */
  deriv_info * der = new deriv_info;
  Block * reused_node_block;
  reused_node_block =new  Block; 
  
  /*------------------------*/
  for(i=0; i<m; i++)
    adjoints[i]=0.0;
  int total_iter =0;
  opt * aux;
  aux = v->head;
  //Loops through all elements in tape
  while(aux!=NULL){
    vi = aux->vi;
    total_iter++;
    //The hall of shame
    switch(aux->func){
      case assign_dep:
	// The start adjoint
	adjoints[vi]=1.0; 
	aux = aux->next;
	continue;
	break;
      case death_not:
	aux = aux->next;
	continue;
	break;   
      case assign_ind:
	aux = aux->next;
	continue;
	break;
      default:
	break;
    }  
   // cout<<"node: "<<vi<<" func "<<aux->func<<endl;
    derivative_info(aux, der, values);  
    reverse_hessian_iteration( aux, der, adjoints, values, W,  reused_node_block);
    values->remove_end(vi);
    /*------------Calculating Adjoint values--------*/
    /*  cout<<"adjoints: "<<endl;
    for(i = 0; i<m ; i++)
    cout<<adjoints[i]<<"  ";
    cout<<endl; //*/    
    
    calculate_adjoint(aux, der, adjoints);
    aux = aux->next;
   // W->print();
  }//end of while(aux) tape loop 
  
  //Shifting the naming of the independent variables so that is starts at zero
  W->N = n;  
  
  delete reused_node_block;
  delete der;
  return(0);
}

void reverse_hessian_iteration(  opt * aux,   deriv_info * der, double * adjoints, Graph * values, Graph *W, Block * reused_node_block){
  int  func;
  int  vi;
  vi = aux->vi;
  /*------------ Pushing--------*/
  if(aux->son[0]!=-1 || aux->son[1]!=-1)
     pushing(aux, der, W, reused_node_block);
  
  W->reset_neighbors(vi);
  /*------------Edge Creating--------*/
  create_edges(aux, der, adjoints[vi],W,reused_node_block);
  // Write a replace_neighbors function !
  if( reused_node_block->isempty()==0){
    W->copy_neighbors(*reused_node_block, vi);
    reused_node_block->reset();
  }
  
}
void pushing(opt * v, deriv_info * der, Graph * W, Block * reused_node_block){
  int  xx, start, last,k;
  int vi;
  double ww;
  vi = v->vi;

  start= W->get_first_position(vi);
  last= W->get_last_position(vi);
  
  for(k=start; k< last+1; k++){  
    //xx = E->B[j].x[k];
    //ww = E->B[j].w[k];
    xx=W->get_neighbor_node(vi,k);
    ww=W->get_edge_weight(vi,k);
    if(xx!=-1)
      push_edge(xx, ww, v,  der,  W,reused_node_block);    
  }//end of Pushing  
  
}
void push_edge(int xx, double ww, opt * v, deriv_info * der, Graph * E, Block * reused_node_block){
  int func,i,j;
  int son[2], vi;
  son[0] = v->son[0]; 
  son[1] = v->son[1];
  vi = v->vi;
  func = v->func;
  double grad[2];
  grad[0] = der->grad[0];
  grad[1] = der->grad[1];
  int indep =  xx;
 // cout<<"Pushing   "<<xx<<"  "<<vi<<endl;  
  if(indep != vi){
    for(i=0; i<2; i++){
      if(son[i]!= -1 && grad[i]!=0.0){
	if(son[i] ==indep) //doubles up on diagonal
	  increment_edge(vi,indep, indep, 2*grad[i]*ww,   E,reused_node_block);
	else{ 
	  increment_edge(vi,indep, son[i], grad[i]*ww,   E,reused_node_block);
	}
      }
    }
  }
  else{
    for(i=0; i<2; i++)
      for(j=i; j<2; j++)
	if(son[i]!= -1 && son[j]!= -1 && grad[i] != 0 && grad[j] != 0){
	  increment_edge(vi,son[i], son[j], grad[i]*grad[j]*ww,   E,reused_node_block); 
	//  cout<<"push loop in "<<vi<<" to ("<<son[i]<<","<<son[j]<<")"<<endl;
	}
	//Passing a loop on two same name but distinct sons. They "should have" had 3 hits in above loops, each receiving TWO edges. 
	// But instead only received one loop. Adding the extra artificially. Could overcome this if above loops treated 
	// same name nodes as different nodes
	if(son[0]==son[1]  && son[0]!= -1){
	  increment_edge(vi,son[1], son[0], grad[0]*grad[1]*ww,   E,reused_node_block);  
	 // cout<<"push artifical loop! "<<vi<<" to ("<<son[0]<<","<<son[1]<<")"<<endl;
	}
  }
}
int create_edges(opt * v, deriv_info * der, double Adj, Graph * E, Block * reused_node_block){
  int i,j;
  int  son[2], vi;
  son[0] = v->son[0]; 
  son[1] = v->son[1]; 
  vi = v->vi;
  double hess[3][3];
  hess[1][0] = der->hess[1][0];
  hess[1][1] =der->hess[1][1];
  hess[0][0] =der->hess[0][0];   
 /* cout<<"creating"<<endl;
  cout<<vi<<"  sons are: "<<son[0]<<"  and  "<<son[1]<<endl;
  cout<<"vi adjoint: "<<Adj<<endl; //*/
  int opt = v->func;
  
    for(i=0; i<2; i++)
      for(j=i; j<2; j++)
	if(son[i]!= -1 && son[j]!= -1 && hess[j][i] != 0){
	  increment_edge(vi,son[j], son[i], hess[j][i]*Adj,  E,reused_node_block);
	  //cout<<"create 2D by "<<vi<<" to ("<<son[i]<<","<<son[j]<<")"<<"  w  "<<hess[j][i]*Adj<<endl;
	}
	//sons share a name, they are only scanned once (because only hess[1][0] is non-zero?) in the above, when they should have been scanned three times and had
	// TWO edges created to each. (on edge is shared)
	if(son[0]==son[1]  &&  son[1]!= -1){
	  increment_edge(vi,son[0], son[1], hess[1][0]*Adj,  E,reused_node_block);
	  //cout<<"create 2D artifical loop! "<<vi<<" to ("<<son[0]<<","<<son[1]<<")"<<"  w  "<<hess[1][0]*Adj<<endl;
	}//*/
return(0);
}
int increment_edge(int vi, int x, int y, double ww,  Graph * E, Block * reused_node_block){
  int big, small;
  long double c0,c1;
  if(ww==0.0)
    return(0);
  
  // lower triangle
  if(x>=y){
    big = x;
    small = y;
  }
  else{
    big = y;
    small = x;
  }
  if(big== vi){
    reused_node_block->insert_inorder( small,ww);
    return (1);
  }
  
 // cout<<"incrementing ("<<big<<","<<small<<")"<<"  by "<<ww<<endl; 
  E->insert_edge_inorder(big, small,ww);    
  return 0;
}
void calculate_adjoint(opt * v, deriv_info* der, double *Adjoint){
  int son[2], vi,func;
  son[0] = v->son[0]; 
  son[1] = v->son[1];
  vi = v->vi;
  func = v->func;
  double grad[3];
  
  grad[0] = der->grad[0];
  grad[1] = der->grad[1]; 
  //Adjoint[vi]*grad[0];    
  double temp = Adjoint[vi];
  //If you were a self increment, you still have a father...?
  //  if(!is_increment){
 //      cout<<"funs if no increment "<<func<<endl;
 // if(!is_eq_prod)
 Adjoint[vi] = 0.0;
 //    }
 if((son[1]!=-1) && (son[0]!=-1)){
   if(son[0]==son[1]){
     //Adjoint[son[0]] =0.0;
     Adjoint[son[0]] += 2*temp*grad[0];     
   }
   else{
     Adjoint[son[1]] += temp*grad[1];
     Adjoint[son[0]] += temp*grad[0]; 
   }  
 }
 else if(son[1]!= -1){
   Adjoint[son[1]] += temp*grad[1];
 }
 else if(son[0]!= -1){ 
   Adjoint[son[0]] += temp*grad[0];
 }
 
}

int derivative_info(opt * operation, deriv_info * der, Graph * values){
  int i,temp;
  int son[2], vi;
  double z=0.0, const_double=0.0;    
  double x_var[3] = {0,0,0};
  son[0] = operation->son[0]; 
  son[1] = operation->son[1];
  vi = operation->vi;
  const_double = operation->const_double;    
  
  //    cout<<"vi: "<<vi<<endl;
  // values.print(vi, 0);
  if(values->get_last_position(vi)!=-1){
    x_var[0]= values->get_last_edge_weight(vi);
  }
  //cout<<"son 0"<<endl;
  for (i = 0; i<2; i++){
    if(son[i] != -1)
	x_var[i+1]= get_graph_last_in_value(values,  vi, son[i]);
  }
  derivative_info_internal( der, const_double, operation->func,  x_var);
  return(0);
  
}

double get_graph_last_in_value(Graph * valuesgraph, int vi, int target){
  if(vi== -1 || target ==-1){
    cout<<"ERROR< cannot retrieve value in graph vi: "<<vi<<" target:"<<target<<endl;
    return(0);
  }
  double val =0.0;
  double last_val = valuesgraph->get_last_edge_weight(target);
  double last_pos = valuesgraph->get_last_position(target);
  
  if(last_pos !=-1){
    if(target!=vi)
      val = last_val;
    //If vi same node as son, get the value at the end but one
    else if(last_pos!= valuesgraph->get_first_position(target)){
      val= valuesgraph->get_edge_weight(target,last_pos-1);
    } 
  }
  return(val);
}


