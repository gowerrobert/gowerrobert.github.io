
#if !defined(adolc_sparse_internal)
#define adolc_sparse_internal 1

#include <adolc/common.h>
#include <adolc/highorder/graph_blocks.h>
#include <adolc/highorder/translate_tape.h>
BEGIN_C_DECLS


int sparsity_pattern_internal_blocks(opt_list * v, int N,  Graph * E);
int derivative_info_sp(opt * v, deriv_info * der);

int increment_edge_sp(int vi, int x, int y, double ww,  Graph * E, Block * reused_node_block);
int create_edges_sp(opt * aux, deriv_info * der, Graph * E, Block * reused_node_block);
void  push_edge_sp(int xx, opt * v, deriv_info * der, Graph * E, Block * reused_node_block);

END_C_DECLS

#endif
