#include <stdio.h>
#include <math.h>
#include "../function_input.h"
#include <iomanip>
#include <adolc/adolc.h>
using namespace std;
/*
 * main.cpp
 *
 * this main tapes the function coded in function_input, then  
calls reverse_hessian() (also known as the edgepushing algorithm [1]) and sparsity_pattern() [2]
to calculate it`s Hessian and Hessian pattern, finally prints out the resulting Hessian.


[1] Gower, R. M., & Mello, M. P. (2012).
A new framework for the computation of Hessians. Optimization Methods and Software, 27(2), 251–273. doi:10.1080/10556788.2011.580098

[2] Gower, R. M., & Mello, M. P. (2012). 
Computing the Sparsity Pattern of Hessians using Automatic Differentiation. ACM Trans. Math. Software (to Appear), 1–16.


Copyright:    Robert Gower, 2013.


Questions and feedback please contact:

Robert Gower 
gowerrobert@gmail.com

 */
int main()
{
  int  N =10;	int i,j,k,nz;
  int tape_num =1;
  /*--------------------------------------------------------------------------*/
  // Variables associated to function calculation and the functions tape!
  /*--------------------------------------------------------------------------*/
  adouble yp;
  double y;
  adouble * xp;
  double * x;
  double * direction;
  x = new double [N]; 
  direction = new double [N]; 
  xp = new adouble [N];
  
  for(j=0; j<N; j++){
    x[j] =   1.0+sin(double(2.0*j));
    direction[j] = 1;
  }
  
  trace_on(tape_num);
  
  for(i=0; i<N ;i++) 
  {
    xp[i] <<= x[i];				  // active independs        //  
  } 
  
  //There's a bunch of function already programmed in Functions folder, just pick one.
  yp = function_input(xp, N);
  yp >>= y;
  
  trace_off();
  
  /*Preparing for Reverse Hessian calculation*/
  Graph *H_pat;  // Stores the Hessian Sparsity pattern
  Graph * HG; // Stores the Hessian matrix 
  double * gradient; 
  HG = NULL; //Necessary flag for first call
  H_pat= NULL; //Necessary flag for first call
  gradient = NULL;
  /*--------------------------------------------------------------------------*/
  
  //First Call
  reverse_hessian( tape_num,  x, &gradient, &HG,  N, NULL);
  sparsity_pattern( tape_num,  &H_pat,  N);
  HG->print();
  H_pat->print_square(1);

  //Testing repeated calls that reuse data structures
  /*--------------------------------------------------------------------------*/
  for(j=0; j<N; j++){
    x[j] =   1.0+cos(double(2.0*j));
  }

  reverse_hessian( tape_num,  x,  &gradient, &HG,  N, NULL);
  sparsity_pattern( tape_num,  &H_pat,  N); 
  HG->print();
  H_pat->print_square(1);
  
  //If you don't want to work with the Graph structure, convert to 
  // standard 3 sparse arrays or CSR as follows
  
  nz = HG->nz;
  int *I =NULL, *J = NULL;
  double *val = NULL;
  
  //Convert and Print the sparse 3-array representation 
  //int array_size  =  HG->to_coordinate_arrays( &I, &J, &val);
  int array_size  =  HG->to_CSR( &I, &J, &val);
  
  //Print 3-array coordinates format
  /* for(i =0; i<array_size; i++)
    cout<< "(i,j,HG[i,j]) ="<<"("<<I[i]<<","<<J[i]<<","<<val[i]<<")"<<endl; //*/
  
  // Print CSR
  /* cout<<"val: ";
   for(i =0; i<array_size; i++)
     cout<<val[i]<<" ";
   cout<<endl<<"I: ";
   for(i =0; i<N; i++)
     cout<<I[i]<<" ";   
   cout<<endl<<"J: ";
   for(i =0; i<array_size; i++)
     cout<<J[i]<<" "; //*/
   
  delete [] val;
  delete [] I;
  delete [] J;  //*/
  
  
  delete [] x;
  delete [] xp;
  delete HG;
  delete H_pat;
  delete [] gradient;
  return 0;
  
}
