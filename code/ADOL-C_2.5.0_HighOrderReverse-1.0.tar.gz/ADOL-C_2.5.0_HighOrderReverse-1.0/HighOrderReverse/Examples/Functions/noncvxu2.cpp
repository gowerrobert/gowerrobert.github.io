#include "../function_input.h"


adouble noncvxu2(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */


//Name: noncvxu2
//# AMPL Model by Hande Y. Benson
//#
//# Copyright (C) 2001 Princeton University
//EdgePushing super winner
for(i=1;i<n;i++){
         //cout<<"((3*i-2)%n): "<<((3*i-2)%n)<<endl;
         //cout<<"((7*i-3) % n): "<<((7*i-3) % n)<<endl;

         fad = fad + pow( (x[i] + x[((3*i-2)%n)] + x[((7*i-3) % n)]),2) +
	       4*cos(x[i] + x[((3*i-2) % n)] + x[((7*i-3) % n)]) ;
	       	
}

    return(fad);
}
double noncvxu2(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            

//Name: noncvxu2
//# AMPL Model by Hande Y. Benson
//#
//# Copyright (C) 2001 Princeton University
//EdgePushing super winner
for(i=1;i<n;i++){
         //cout<<"((3*i-2)%n): "<<((3*i-2)%n)<<endl;
         //cout<<"((7*i-3) % n): "<<((7*i-3) % n)<<endl;

         fad = fad + pow( (x[i] + x[((3*i-2)%n)] + x[((7*i-3) % n)]),2) +
	       4*cos(x[i] + x[((3*i-2) % n)] + x[((7*i-3) % n)]) ;
	       	
}


return(fad);
}



