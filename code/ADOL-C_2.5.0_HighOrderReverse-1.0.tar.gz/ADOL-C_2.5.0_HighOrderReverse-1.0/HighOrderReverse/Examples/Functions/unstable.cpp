#include "../function_input.h"
/*
This is a synthetic example for which 
the ADOL-C tensor_eval function suffers from numerical instability, and erronous fill-ins
in the resulting tensor pattern. The same does not occur with reverse_tensorv.
*/

adouble unstable(adouble * x, int n){
  int  i, j;
  adouble fad=0;
  fad = x[0]; 
  
  for(i=1; i<n -1; i++)
    fad = fad+ pow((exp(x[i-1])-x[i]),4.0) ;
  return fad;
}
double unstable(double *x,int n){
  int  i, j;
  double fad =0;
  fad = x[0];       

//cosine from CUTE
for(i=1; i<n -1; i++)
  fad = fad+ pow((exp(x[i-1])-x[i]),4.0) ;
return fad;
}



