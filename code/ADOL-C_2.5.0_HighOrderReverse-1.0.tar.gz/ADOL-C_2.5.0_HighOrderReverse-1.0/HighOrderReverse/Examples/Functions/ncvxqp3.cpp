#include "../function_input.h"


adouble ncvxqp3(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

//name: ncvxqp3
// AMPL Model by Hande Y. Benson   
// Copyright (C) 2001 Princeton University
int M =n/2;
int nPLUS = 3*n/4;

//var x{1..n} >= 0.1, <= 10.0, := 0.5;
//TERRIBLE numeric stability
//minimize f:
	for(i=1; i<nPLUS; i++) 
	    fad =fad+ pow((x[i]+x[(2*i-1) % n ] +x[(3*i-1) % n ]),2*i/2);
	for(i=nPLUS+1; i<n; i++) 
	    fad = fad - pow((x[i]+x[(2*i-1) % n] +x[(3*i-1) % n]),2*i/2) ;
    return(fad);
}
double ncvxqp3(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            


//name: ncvxqp3
// AMPL Model by Hande Y. Benson   
// Copyright (C) 2001 Princeton University
int M =n/2;
int nPLUS = 3*n/4;

//var x{1..n} >= 0.1, <= 10.0, := 0.5;
//TERRIBLE numeric stability
//minimize f:
	for(i=1; i<nPLUS; i++) 
	    fad =fad+ pow((x[i]+x[(2*i-1) % n ] +x[(3*i-1) % n ]),2*i/2);
	for(i=nPLUS+1; i<n; i++) 
	    fad = fad - pow((x[i]+x[(2*i-1) % n] +x[(3*i-1) % n]),2*i/2) ;
return(fad);
}



