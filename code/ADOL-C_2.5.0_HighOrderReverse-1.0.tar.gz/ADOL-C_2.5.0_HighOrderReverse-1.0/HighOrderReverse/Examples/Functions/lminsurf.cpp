#include "../function_input.h"


adouble lminsurf(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */


/*
lMinSurf as in:
 A Griewank and Ph. Toint,
#   "Partitioned variable metric updates for large structured
#   optimization problems",
*/
int P=125;
int h00 = 1;
int slopej = 4;
int slopei = 8;

float ston= slopei/(P-1);
float wtoe= slopej/(P-1);
float h01 = h00+slopej;
float h10 = h00+slopei;
  n = sqrt(n);
fad=0;
for(i=0; i<n-1; i++)
   for(j=0;j<n-1; j++)
	fad = fad + sqrt(pow((P-1),2)*(pow((x[i*n+j]-x[(i+1)*n+j+1]),2)+pow((x[(i+1)*n+j]-x[i*n+j+1]),2))/2+1)/pow((P-1),2);
    return(fad);
}
double lminsurf(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            


/*
lMinSurf as in:
 A Griewank and Ph. Toint,
#   "Partitioned variable metric updates for large structured
#   optimization problems",
*/
int P=125;
int h00 = 1;
int slopej = 4;
int slopei = 8;

float ston= slopei/(P-1);
float wtoe= slopej/(P-1);
float h01 = h00+slopej;
float h10 = h00+slopei;
  n = sqrt(n);
fad=0;
for(i=0; i<n-1; i++)
   for(j=0;j<n-1; j++)
	fad = fad + sqrt(pow((P-1),2)*(pow((x[i*n+j]-x[(i+1)*n+j+1]),2)+pow((x[(i+1)*n+j]-x[i*n+j+1]),2))/2+1)/pow((P-1),2);

return(fad);
}



