#include "../function_input.h"


adouble nondquar(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

//   Source: problem 57 in... name: nondquar
//   A.R. Conn, N.I.M. Gould, M. Lescrenier and Ph.L. Toint,
//   "Performance of a multi-frontal scheme for partially separable
//   optimization"
//   Report 88/4, Dept of Mathematics, FUNDP (Namur, B), 1988.

//   SIF input: Ph. Toint, Dec 1989
   for(i=0; i<n-1; i++)
       fad = fad + pow(x[i]+x[i+1]+x[n-1],4);      
    fad = fad + pow(x[1]-x[2],2)+pow(x[n-1]+x[n-2],2);
    return(fad);
}
double nondquar(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            
//   Source: problem 57 in... name: nondquar
//   A.R. Conn, N.I.M. Gould, M. Lescrenier and Ph.L. Toint,
//   "Performance of a multi-frontal scheme for partially separable
//   optimization"
//   Report 88/4, Dept of Mathematics, FUNDP (Namur, B), 1988.

//   SIF input: Ph. Toint, Dec 1989
   for(i=0; i<n-1; i++)
       fad = fad + pow(x[i]+x[i+1]+x[n-1],4);      
    fad = fad + pow(x[1]-x[2],2)+pow(x[n-1]+x[n-2],2);
return(fad);
}



