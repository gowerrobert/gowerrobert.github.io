#include "../function_input.h"


adouble cragglevy(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

//   Source:  problem 32 in
//   Ph. L. Toint,
//   "Test problems for partially separable optimization and results
//   for the routine PSPMIN",
//   Report 83/4, Department of Mathematics, FUNDP (Namur, B), 1983.

//   See  also Buckley#18
//   SIF input: Ph. Toint, Dec 1989.
//Very unstable numerically
//cragg and levy function  name: CRAGGLEVY
/*
Have to get in library
Study on a supermemory gradient method for the minimization of functions  
Jornal of optimization theory and applications. 191-205
*/
   for(i=1; i<n/2 -1; i++){
	fad = fad+ pow((exp(x[2*i-1])-x[2*i]),4.0) +
	100.0*pow(x[2*i]-x[2*i+1],6.0) +
	pow(cos(x[2*i+1]-x[2*i+2])/sin(x[2*i+1]-x[2*i+2])+x[2*i+1]-x[2*i+2],4.0) +
	pow(x[2*i-1],8.0) +
	pow(x[2*i+2]-1.0,2.0);
   }

    return(fad);
}
double cragglevy(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            

//   Source:  problem 32 in
//   Ph. L. Toint,
//   "Test problems for partially separable optimization and results
//   for the routine PSPMIN",
//   Report 83/4, Department of Mathematics, FUNDP (Namur, B), 1983.

//   See  also Buckley#18
//   SIF input: Ph. Toint, Dec 1989.
//Very unstable numerically
//cragg and levy function  name: CRAGGLEVY
/*
Have to get in library
Study on a supermemory gradient method for the minimization of functions  
Jornal of optimization theory and applications. 191-205
*/
   for(i=1; i<n/2 -1; i++){
	fad = fad+ pow((exp(x[2*i-1])-x[2*i]),4) +
	100*pow(x[2*i]-x[2*i+1],6) +
	pow(cos(x[2*i+1]-x[2*i+2])/sin(x[2*i+1]-x[2*i+2])+x[2*i+1]-x[2*i+2],4) +
	pow(x[2*i-1],8) +
	pow(x[2*i+2]-1.0,2);
   }

return(fad);
}



