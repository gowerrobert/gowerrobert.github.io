****************************************
ADOL-C_2.5.0_HighOrderReverse-1.0
******************************************
This is a short-cut compilation of ADOL-C-2.5.0 and HighOrderReverse. If it fails, download separately the newest release of the HighOrderReverse and ADOL-C package and follow the README.txt instructions in HighOrderReverse. 

To compile ADOL-C-2.5 and HighOrderReverse, cd into the folder ADOL-C_2.5.0_HighOrderReverse-1.0/ADOL-C-2.5.0 and type in the commands
$./configure
$make
$make install

This should compile ADOL-C-2.5.0 together with the HighOrderReverse Packages. Now type in the commands
$cd ../HighOrderReverse/Examples/ToyExample
$make
$./p

This compiles the example in HighOrderReverse/Examples/ToyExamples, which prints on screen two graph sparsity patterns.
The preceding commands are all in bashscript file ./compile. 

********************************************
Running and Linking
********************************************
No additional linking is required in relation to the standard ADOL-C linking procedure. Please see

HighOrderReverse/Examples/ToyExample/

where you will find an example  main.cpp and makefile. To reproduce the tests presented in [3], please see

HighOrderReverse/Examples/RefereeExample/

To compile and run these ready made example, please see the additional README.txt in

HighOrderReverse/Examples/


********************************************
Uninstall
********************************************
delete ${HOME}/adolc_base with the command
$ rm -r ${HOME}/adolc_base


*******************************************
Citations
******************************************
When citing this software, or it's methodology, please cite

[1] Gower, R. M., & Mello, M. P. (2012).
A new framework for the computation of Hessians. Optimization Methods and Software, 27(2), 251–273. doi:10.1080/10556788.2011.580098

[2] Gower, R. M., & Mello, M. P. (2012).
Computing the Sparsity Pattern of Hessians using Automatic Differentiation. ACM Trans. Math. Software (to Appear), 1–16.

[3] Gower, R., & Gower, A. (2014). Higher-order Reverse Automatic Differentiation with emphasis on the third-order. Mathematical Programming.

