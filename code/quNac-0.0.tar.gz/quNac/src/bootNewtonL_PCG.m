function bootNewtonL_PCG(x0,f_eval, g_eval, Hess_opt,opts)

DATA = [];
n = length(x0);

if(isfield(opts,'H0_opt_method'))
    DATA.H0_opt =  H0_method_select(x0,f_eval, g_eval, Hess_opt,opts);
else
    DATA.H0_opt = opts.H0_opt;
end

if(opts.PCG.memory_limit ==0)
    DATA.name=  'Newton\_CG';
else
    DATA.name= [opts.QuNic_type 'LQuNac'];
end

opts.PCG.x0 = zeros(n,1);
opts.PCG.iter =0;
% DELETE LATER
DATA.Krylov =[];
assignin('caller', 'opts', opts);
assignin('caller', 'DATA', DATA);


end