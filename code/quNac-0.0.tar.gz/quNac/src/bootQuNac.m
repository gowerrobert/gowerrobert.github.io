function bootQuNIC(x0, f_eval,g_eval, Hess_opt,opts)

DATA = [];
n = length(x0);
DATA.H0 =  H0_select(x0,f_eval, g_eval, Hess_opt,opts);
DATA.metric_reset_method =  metric_reset_method(x0,f_eval, g_eval, Hess_opt,opts);
DATA.H=DATA.H0;
% Setup PCG 
opts.PCG.x0 = zeros(n,1);
opts.PCG.iter =0;
%Taking a gradient step first
g0 = g_eval(x0);
stp = line_search(opts.line_search,x0,f_eval,g_eval,g0,-g0,Hess_opt);
DATA.delta = -stp*g0;
DATA.stp = stp;
%Take a quNIC step with H0
%x0 = x0+DATA.delta;

DATA.name= [opts.QuNic_type 'QuNac'];
DATA.x_CG = x0;

assignin('caller', 'x0', x0);
assignin('caller', 'opts', opts);
assignin('caller', 'DATA', DATA);


end