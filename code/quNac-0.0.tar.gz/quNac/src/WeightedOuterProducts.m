% Weighted Outproduct with weight W, left multiplied by L and
% right multiplied by R

% LQproj(D,A) =   Dl(D'*W*D)^{-1}Dr' 
%             = \sum_{i=1}^p (dl_i) (dr_i')/(d_i'*A*d_i)
function projDA = WeightedOuterProducts(Dl,Dr,D,WD)    
SD= size(D);
n = SD(1);
p = SD(2);
projDA = zeros(n,n);

for i =1:p
    d= D(:,i);
    dr= Dr(:,i);
    dl= Dl(:,i);    
    projDA = projDA +dl*(dr')/(d'*WD(:,i));  
end

end