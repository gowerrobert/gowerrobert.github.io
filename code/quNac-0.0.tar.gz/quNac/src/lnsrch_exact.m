function stp = lnsrch_exact(d,grad_cur,Ad)
d = d(:);
stp = -d'*grad_cur/(d'*Ad);
end