function test_result = sufficient_descent_angle(grad, s, tol)

cosgrads= abs(grad'*s)/(norm(grad)*norm(s));
%display(cosgrads);
if(cosgrads< tol)
    %fail descent criteria
    test_result =1;
else
    test_result =0;
end
end