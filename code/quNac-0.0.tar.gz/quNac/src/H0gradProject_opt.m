function [H0d] = H0gradProject_opt(x0, g_eval, Hess_opt,d)
% The Projected gradient H0 approximation applied to d
g0 = g_eval(x0);
Ad = Hess_opt(x0,-g0);
alpha = lnsrch_exact(-g0,g0,Ad);
H0d = d*alpha;

end