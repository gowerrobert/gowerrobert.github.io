

function [H0_opt] =  H0_method_select(x0,f_eval, g_eval, Hess_opt,opts)

switch opts.H0_opt_method
    case 'projected gradient'
        H0_opt = @(x, gg,HH,d)(H0gradProject_opt(x, gg,HH,d));
        % DELETE LATERs
     %   [H0, ~] = H0gradProject(x0, g_eval, Hess_opt);
    case 'identity'
        H0_opt = @(x, gg,HH,d)(d);
        % DELETE LATER
      %  n = length(x0);
      %  H0 = eye(n,n);
    case 'huber inverse'
        H0_opt = @(x,g,h, d) ( bsxfun(@times, 1./huber_hess_kimon(x,opts.hubermu),d));
   %     H0= diag( 1./huber_hess_kimon(x0,opts.mu));
    otherwise
        % Just hope the user has supplied a correct H0
        display('A user suppplied H0')
end
end