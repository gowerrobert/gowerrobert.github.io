function d = descentNewtonL_PCG(x, g_eval, Hess_opt ,~, opts)
% What should the Initial Hessian estimate be?
DATA = evalin('caller', 'DATA');
%n = length(x);

%% Updates for the inverse
g0 = g_eval(x);
DATA.H0_optx = @(d)(DATA.H0_opt(x,g_eval,Hess_opt,d));
%DATA.H0 = opts.H0_method_sele(x, g_eval, Hess_opt);
Hess_optx = @(d)(Hess_opt(x,d));
% The Preconditioner-vector operator
if(isfield(DATA,'D') && ~isempty(DATA.D))
    %M =  @(d)( L_P_inverseQuNIc_scaled(DATA.D,DATA.HeD, DATA.H0_optx ,d));
    M =  @(d)( L_P_inverseQuNac(DATA.D,DATA.HeD, DATA.H0_optx ,d));
else 
    M = DATA.H0_optx;
end
    
[opts.PCG , D, HeD] = PCG_bounded(Hess_optx,M,g0,opts.PCG);
%display(opts.PCG.flag);
if(strcmpi(opts.PCG.flag,'neg_preconditioner')) 
    display('Negative Curvature Flag');
    d = -g0;
else
    DATA.D = D;
    DATA.HeD = HeD;
    d = opts.PCG.x;
end
% If something about opts.PCG

%% Cleaning house

assignin('caller', 'DATA', DATA);
assignin('caller', 'opts', opts);
end