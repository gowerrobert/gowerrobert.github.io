% The direct quasi-Newton image contraint update E 
% E= proj_{D}^{\He_k} -H0\He_k proj_{D}^{\He_k H0 \He_k} \He_k H0
function E = directQuNac(D,HeD, H0)
projDHe = WeightedOuterProducts(D,D,D,HeD); %(Dl,Dr,D,W)
H0HeD = H0*HeD;
% Hopefully matlab knows the best way to invert this small pXp matrix
invHeDTHoHeD = (HeD'*H0*HeD)^(-1); 
E =projDHe - H0HeD*invHeDTHoHeD*H0HeD';
end