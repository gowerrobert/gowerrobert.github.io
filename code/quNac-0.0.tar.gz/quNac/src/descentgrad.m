function d = descentgrad(x, g_eval, Hess_opt ,tol, opts)
% What should the Initial Hessian estimate be?


%% Cleaning house
d = -g_eval(x);

end