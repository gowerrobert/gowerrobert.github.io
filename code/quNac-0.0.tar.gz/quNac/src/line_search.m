function stp = line_search(line_search_method,x,f_eval,g_eval, grad_cur, d,Hess_opt)
    switch line_search_method
        case 'none'
            stp =1;
        case 'armijo'
            stp0= 1;
            stp  = lnsrch_arm( x, d, grad_cur'*d, f_eval(x), stp0, @(y,mu)(f_eval(y)),@(y,iter,mu)(0), [], 0 );
        case 'backtrack'
            stp0= 1;
            stp  = lnsrch_bt( x, d, grad_cur'*d, f_eval(x), stp0, @(y,mu)(f_eval(y)),@(y,iter,mu)(0), [], 0 );  
        case 'strongwolfe'
            stp_max= 10;            
            stp = lnsrch_strongwolfe(f_eval, g_eval,grad_cur, d,x,stp_max);
        otherwise
            Ad = Hess_opt(x,d);
            stp = lnsrch_exact(d,grad_cur,Ad);
    end
    
end