function  OUTPUTS = all_methods(opts,f_eval,g_eval,Hess_opt)
OUTPUTS ={};
mem_lim_orig =  opts.PCG.memory_limit;
%% Full quNIC method
 %load_QuNIC_BFGS_settings
 opts.PCG.maxit =opts.PCG.memory_limit;
outquNIC = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootQuNIC, @descentQuNIC,   opts);
OUTPUTS = [ OUTPUTS {outquNIC}];
%% descent NewtonL_PCG method
% Often uses more CG iteration
opts.PCG.maxit =opts.PCG.memory_limit;
 outNewtonL_PCG= QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootNewtonL_PCG, ...
    @descentNewtonL_PCG,   opts);
OUTPUTS = [ OUTPUTS {outNewtonL_PCG}];
%% Continuous PCG_evolve quNIC method
% opts.PCG.maxit =opts.PCG.memory_limit;
% outPCG_evolve = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, ...
%     @bootPCG_evolve, @descentPCG_evolve,   opts);
% OUTPUTS = [ OUTPUTS {outPCG_evolve}];
% %% Limited PCG_evolve quNIC method
% opts.PCG.maxit = opts.PCG.memory_limit;%opts.n; 
% outPCG_evolve = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, ...
%     @bootLPCG_evolve, @descentLPCG_evolve,   opts);
% OUTPUTS = [ OUTPUTS {outPCG_evolve}];
%% Newton CG
opts.PCG.maxit = opts.n;
 outNewton_CG= QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootNewton_CG, ...
    @descentNewtonL_PCG,   opts);
OUTPUTS = [ OUTPUTS {outNewton_CG}];
%% descent_BFGS_Finite-differencing
% Implement the real BFGS with finite differencing!
opts.PCG.memory_limit =mem_lim_orig;
opts.finite_differencing =1;
outBFGSF = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootBFGS, @descentBFGS,   opts);
OUTPUTS =[OUTPUTS {outBFGSF}]; 
%% descent_LBFGS_Finite-differencing
% Implement the real BFGS with finite differencing!
opts.finite_differencing =1;
opts.PCG.memory_limit =mem_lim_orig;
outLBFGSF = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootLBFGS, @descentLBFGS,   opts);
OUTPUTS =[OUTPUTS {outLBFGSF}]; 

end