

function [H0] =  H0_select(x0,f_eval, g_eval, Hess_opt,opts)

if(isfield(opts,'H0_method'))
    switch lower(opts.H0_method)
        case 'projected gradient'
            [H0, ~] = H0gradProject(x0, g_eval, Hess_opt);
        case 'identity'
            n = length(x0);
            H0 = eye(n,n);
        case 'huber inverse'
            H0= diag( 1./huber_hess_kimon(x0,opts.hubermu));    
        otherwise
            display('Non-existent H0 method! Choosing identity');
            n = length(x0);
            H0 = eye(n,n);
    end
else
    [H0, ~] = H0gradProject(x0, g_eval, Hess_opt);
end

end