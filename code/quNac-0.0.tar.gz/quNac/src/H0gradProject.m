function [H0, delta] = H0gradProject(x0, g_eval, Hess_opt)

% The Projected gradient H0 approximation
g0 = g_eval(x0);
d= -g0;
Ad = Hess_opt(x0,d);
alpha = lnsrch_exact(d,g0,Ad);
delta = alpha*d;

n = length(x0);
I = diag(ones(1,n));
H0 = I*alpha;

end