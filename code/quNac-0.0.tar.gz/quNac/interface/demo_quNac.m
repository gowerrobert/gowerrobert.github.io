%demo_quNac runs the full and limited memory implemenation of the quNac
%Newton-PCG methods with standard parameters on the Watson function.
% Copyright (c) 2014.  Robert Gower.
%% Load the Watson Problem
n =100;             % Select dimension
problem =7;         % The problem Watson Problem
tol = 1.0e-8;          % Desired tolerance
opts =[];
% Loading the Watson problem with specified dimension
[opts,f_eval,g_eval,Hess_opt ] = load_TEST_OPT(problem,n,tol,opts);
% loads standard parameters of quNac methods
load_standard_parameters;
opts.plotting= 1;                           % 1 - record information for plotting, 0 - otherwise
OUTPUTS ={};
%% Run the full memory quNac
outquNIC = QuNacsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootQuNac, @descentQuNac,   opts);
OUTPUTS = [ OUTPUTS {outquNIC}];
%% Run the limited memory quNac
outNewtonL_PCG= QuNacsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootNewtonL_PCG, ...
    @descentNewtonL_PCG,   opts);
OUTPUTS = [ OUTPUTS {outNewtonL_PCG}];
%% Run the Newton-CG method
opts.PCG.maxit =opts.n;
opts.PCG.memory_limit =0;
outNewton_CG= QuNacsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootNewtonL_PCG, ...
    @descentNewtonL_PCG,   opts);
OUTPUTS = [ OUTPUTS {outNewton_CG}];
%% plot results
plot_outputs(OUTPUTS,[])