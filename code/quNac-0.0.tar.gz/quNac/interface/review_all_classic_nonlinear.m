% review_all_classic_nonlinear is intended to replicate the results published in
%     "Action constrained quasi-Newton methods"
% review_all_classic_nonlinear calls all methods on all "classic nonlinear
% test functions" and saves .csv files to the "results" folder
%% Parameters
clear all;
n =100;  problem =44; tol = 1.0e-8;   opts =[];
[opts,f_eval,g_eval,Hess_opt ] = load_TEST_OPT(problem,n,tol,opts);
load_standard_parameters;
opts.plotting= 0;              
opts.prnt= 0; 
problem_set  = [7,8,9, 13, 14, 15, 18,20, 21, 44];
%% All methods All dimension ALL problems!
lPS = length(problem_set);
for j =1:lPS
    OUTPUTS_all ={};
    dims = select_problem_dimensions(problem_set(j));
    ldims = length(dims);
    for i = 1:ldims
        n =dims(i);
        opts.n = n;
        [opts,f_eval,g_eval,Hess_opt ] = load_TEST_OPT(problem_set(j),n,tol,opts);
        OUTPUTS = all_methods(opts,f_eval,g_eval,Hess_opt);
        OUTPUTS_all = [ OUTPUTS_all; OUTPUTS];
    end
    tbl_options.title = ['results/dim_'  num2str(n) '_' opts.problem_title '_d_' num2str(opts.PCG.memory_limit) '_' opts.line_search ...
    '_' opts.H0_method  'nogstart']; 
    table_output_times(OUTPUTS_all,tbl_options);
end
plot_outputs(OUTPUTS,[])