% review_all_logistic is intended to replicate the results published in
%     "Action constrained quasi-Newton methods"
% review_all_logistic calls all methods on all logisitc problems in the folder
%     tests/logistic/LIBSVM_data/
% and saves .csv files to the "results" folder
%% Load Logistic parameters   
clear all
tol = 1.0e-7;
problem ='logistic';
opts.regularizor ='huber';
opts.hubermu = 1.0e-4;
opts.regulatrizor_parameter = 1.0;
load_standard_parameters;
opts.plotting= 0;              
opts.prnt= 0; 
LIBSVMdata(1);
log_tests= get_LIBSVMdata(); 
%% call all methods varying Logistic problem
OUTPUTS_all ={};
lPS = length(log_tests);
istart =1;
iend =lPS;
for i = istart:10
    opts.LIBSVMdata = log_tests{i};
    [opts,f_eval,g_eval,Hess_opt ] = load_TEST_OPT('logistic',1,tol,opts);
    OUTPUTS = all_methods(opts,f_eval,g_eval,Hess_opt);
    OUTPUTS_all = [ OUTPUTS_all; OUTPUTS];
end
tbl_options.title = ['results/JCMB_' problem '_' num2str(istart) '_' num2str(iend) '_' opts.regularizor ...
    '_d_' num2str(opts.PCG.memory_limit) '_' opts.line_search '_' num2str(opts.tol)];
table_output_times(OUTPUTS_all,tbl_options);
save(tbl_options.title,'OUTPUTS_all')

