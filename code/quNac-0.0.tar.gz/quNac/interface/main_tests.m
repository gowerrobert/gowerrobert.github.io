 cd /data/data_s1065527/Dropbox/Matlab/quNac/
 setupquNIC
% main_test my main  file for testing stuff out
%% Load Logistic parameters  
clear all;
tol = 1.0e-6; 
problem ='logistic';
opts.regularizor ='L2';
opts.hubermu = 1.0e-4;
opts.regulatrizor_parameter = 1.0;
opts.LIBSVMdata = LIBSVMdata(1);  % For a list of data file names --> get_LIBSVMdata()
%% Load problem 
% loads the specified test function
%problem ='quadratic'; n =1000;
[opts,f_eval,g_eval,Hess_opt ] = load_TEST_OPT(problem,[],tol,opts);
opts.PCG.memory_limit =20;                  % Maximum amount of memory stored for Limited memory techiniques
opts.PCG.update_size =20;                   % number of columns in update matrix (update rank = 2*update_size)
opts.PCG.maxit = opts.PCG.memory_limit ;    % Maximum number of PCG iterations
opts.PCG.tol = 'super-linear';              % PCG tolerance 'super-linear',  'quadratic';  0.01;
opts.PCG.prnt = 0;                          % 1 - print inner PCG iterations, 0 - otherwise 
opts.plotting= 1;                           % 1 - record information for plotting, 0 - otherwise
opts.prnt= 1;                               % 1 - print outer iterations, 0 - otherwise  
opts.Timeout = 60*5;                          % permitted time in seconds                          
opts.line_search ='armijo';                 % type of linesearch where optiones are: armijo, exact, none, backtrack, strongwolfe
opts.H0_method = 'projected gradient';      % type of H0 metric huber_inverse % 'identity' % 'projected gradient'
opts.H0_opt_method = 'projected gradient';  % limited memory type of H0 metric 'projected gradient' %'huber inverse' % identity
opts.metric_reset_method ='descent-angle';  % type of metric reseting criteria: always %descent-angle % never
opts.step_method = 'Newton-CG';             % type of descent directions: 'metric-grad' %'Newton-CG'
opts.QuNic_type = 'inverse';                % type of metric matrix 'inverse' %'direct'
OUTPUTS ={};
%% Full quNac method
opts.PCG.maxit =   opts.PCG.update_size;
outquNIC = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootQuNIC, @descentQuNIC,   opts);
OUTPUTS = [ OUTPUTS {outquNIC}];
%% Limited quNac method
%opts.PCG.memory_limit =20;
opts.PCG.maxit =   opts.PCG.memory_limit;
outNewtonL_PCG= QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootNewtonL_PCG, ...
    @descentNewtonL_PCG,   opts);
OUTPUTS = [ OUTPUTS {outNewtonL_PCG}];
%% Full Limited quNac evolve
opts.PCG.maxit = opts.PCG.memory_limit;
outLPCG_evolve = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, ...
    @bootLPCG_evolve, @descentLPCG_evolve,   opts);
%% Full quNac evolve
opts.PCG.maxit = opts.n; 
outPCG_evolve = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, ...
    @bootPCG_evolve, @descentPCG_evolve,   opts);
%% Full quNac PCG Linger: all inside PCG call 
opts.PCG.maxit = opts.n; 
outPCG_line = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, ...
    @bootPCG_linger, @descentPCG_linger,   opts);
%% Full quNac Linger
opts.PCG.maxit = opts.n; 
outqunac_linger = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, ...
    @bootQuNacL, @descentQuNacL,   opts);
%% Newton CG
opts.PCG.maxit =opts.n;
opts.PCG.memory_limit =0;
 outNewton_CG= QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootNewtonL_PCG, ...
    @descentNewtonL_PCG,   opts);
OUTPUTS = [ OUTPUTS {outNewton_CG}];
%% descent_BFGS_Finite-differencing
opts.finite_differencing =1;
outBFGSF = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootBFGS, @descentBFGS,   opts);
OUTPUTS =[OUTPUTS {outBFGSF}]; 
%% descent_LBFGS_Finite-differencing
opts.finite_differencing =1;
opts.PCG.memory_limit =20;
outLBFGSF = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootLBFGS, @descentLBFGS,   opts);
OUTPUTS =[OUTPUTS {outLBFGSF}]; 
%% Gradient
outgrad = QuNICsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootgrad, @descentgrad,   opts);
OUTPUTS =[OUTPUTS {outgrad}]; 
%% plot all error X time of each object in OUTPUTS
plot_outputs(OUTPUTS,[])