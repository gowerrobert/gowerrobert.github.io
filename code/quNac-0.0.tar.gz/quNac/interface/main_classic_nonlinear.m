% main_classic_nonlinear: is a script file that allows you select any parameters and solver
% to solve a "Classic nonlinear test problem". It also plots all outputs at the end.
% Newton-PCG methods with standard parameters on the Watson function.
% Copyright (c) 2014.  Robert Gower.
%  The problems that scale with dimension are
%  problem =              7;  Watson function
%                         8;  The Penalty Function #1
%                         9;  The Penalty Function #2
%                         13;  The Trigonometric Function
%                         14;  The Extended Rosenbrock parabolic valley Function
%                         15;  The Extended Powell Singular Quartic Function
%                         18;  The Chebyquad Function
%                         20;  The Gregory and Karney Tridiagonal Matrix Function
%                         21;  The Hilbert Matrix Function
%                        'logisitc'; Requires field opts.LIBSVMdata
%------------------------------------------------------------------------------
% opts.LIBSVMdata =         a string that specifiecs a LIBSVM binary data file,
%                           exe, 'heartsc'
% opts.regularizor =        'L2' to a L2 euclidean regularizor or 'huber'
%                           for a pseudo-huber regularizor
% opts.hubermu =            a number in [0 1] specifies accuracy of
%                           pseudo-huber approxamition to the L1 norm where hubermu-> 0 as
%                           pseudo-huber tends to a L1 regularizor
%% Load general parameters
n =100;             % Select dimension
tol = 1.0e-8;       % Desired tolerance
%% Load a Classic nonlinear problem
problem =7;         % The problem Watson Problem
opts =[];
%% Load problem
% loads the specified test function
[opts,f_eval,g_eval,Hess_opt ] = load_TEST_OPT(problem,n,tol,opts);
opts.PCG.memory_limit =20;                  % Maximum amount of memory stored for Limited memory techiniques
opts.PCG.update_size =20;                   % number of columns in update matrix (update rank = 2*update_size)
opts.PCG.maxit = opts.PCG.memory_limit ;    % Maximum number of PCG iterations
opts.PCG.tol = 'super-linear';              % PCG tolerance 'super-linear',  'quadratic';  0.01;
opts.PCG.prnt = 0;                          % 1 - print inner PCG iterations, 0 - otherwise
opts.plotting= 1;                           % 1 - record information for plotting, 0 - otherwise
opts.prnt= 1;                               % 1 - print outer iterations, 0 - otherwise
opts.Timeout = 60;                          % permitted time in seconds
opts.line_search ='armijo';                 % type of linesearch where optiones are: armijo, exact, none, backtrack, strongwolfe
opts.H0_method = 'projected gradient';      % type of H0 metric huber_inverse % 'identity' % 'projected gradient'
opts.H0_opt_method = 'projected gradient';  % limited memory type of H0 metric 'projected gradient' %'huber_inverse' % identity
opts.metric_reset_method ='descent-angle';  % type of metric reseting criteria: always %descent-angle % never
opts.step_method = 'Newton-CG';             % type of descent directions: 'metric-grad' %'Newton-CG'
opts.QuNic_type = 'inverse';                % type of metric matrix 'inverse' %'direct'
OUTPUTS ={};
%% Full quNIC method
outquNIC = QuNacsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootQuNac, @descentQuNac,   opts);
OUTPUTS = [ OUTPUTS {outquNIC}];
%% descent NewtonL_PCG method
opts.PCG.maxit =   opts.PCG.memory_limit;
outNewtonL_PCG= QuNacsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootNewtonL_PCG, ...
    @descentNewtonL_PCG,   opts);
OUTPUTS = [ OUTPUTS {outNewtonL_PCG}];
%% Newton CG
opts.PCG.maxit =opts.n;
outNewton_CG= QuNacsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootNewton_CG, ...
    @descentNewtonL_PCG,   opts);
OUTPUTS = [ OUTPUTS {outNewton_CG}];
%% descent_BFGS_Finite-differencing
opts.finite_differencing =1;
outBFGSF = QuNacsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootBFGS, @descentBFGS,   opts);
OUTPUTS =[OUTPUTS {outBFGSF}];
%% descent_LBFGS_Finite-differencing
opts.finite_differencing =1;
outLBFGSF = QuNacsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootLBFGS, @descentLBFGS,   opts);
OUTPUTS =[OUTPUTS {outLBFGSF}];
%% Gradient
outgrad = QuNacsolve(opts.x0, f_eval, g_eval, Hess_opt, @bootgrad, @descentgrad,   opts);
OUTPUTS =[OUTPUTS {outgrad}];
%% plot all error X time of each object in OUTPUTS
plot_outputs(OUTPUTS,[])