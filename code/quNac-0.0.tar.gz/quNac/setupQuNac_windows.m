%RESULTSSETUP Setup file for quNac
%
%
%    Adds to path the files of the current folder
%    And compiles the mex file libsvmread for use with logistic test
%    problems

% Get root location of resultsSetup
root = fileparts(which(mfilename)); 

% ----------------------------------------------------------------------
% Add the appropriate subdirs to path.
% ----------------------------------------------------------------------

addpath(genpath(root));
fprintf('%s \n',root);

fprintf(['\nThe above directories and their subdirectories have been'  ,...
         ' temporarily added to your path.\n']);
% -------------------------------------------------------------------------
% Compile the libsvmread.c 
% -------------------------------------------------------------------------
cd([root,'\tests\logistic\LIBSVM_data\']);

try
   if exist('libsvmread','file')~=3, mex libsvmread.c; end
   fprintf('Compilation of MEX files for libsvmread was successful!\n');
catch err
    display(err);
    cd(root);
   error('Could not compile MEX files for libsvmread:');
end
cd(root);

% ---------------------------------------------------------------------
% Store the new path permanently.
% ---------------------------------------------------------------------
% while (true)
%     reply = input('Would you like to save the new path (optional)? Y/N [N]: ', 's');
%     if (strcmpi(reply,'Y') || strcmpi(reply,'N'))
%         break;   
%     end
% end
break;
if (strcmpi(reply,'Y'))
    is_saved = savepath;
    if (~is_saved)
        disp('The new path is saved.');
    else
        fprintf('\n%s \n \n',['The new path could not be saved.'       ,...
                ' Please copy the following addpath commands in your'  ,...
                ' startup.m file.']);
        for i=1:length(newpaths)
            text = ['addpath(',root,')'];
            fprintf('%s \n',text);
        end
        input('\nPress any key to continue installation', 's');
    end
else
    disp('The new path was not saved.');
end

clear;
