quNac: quasi-Newton action constrained
---------------------------------------------------------------------------

1. Introduction
===============

This is an implementation of a Newton-PCG solver which uses a
 quNac matrices as preconditioners. 
It is used to solve nonlinear unconstrained optimization problems of the form

   min_x f(x)

where f(x) is twice differentiable.

Examples are given on how to use the quNac solver in the demos directory
inside the main directory of quNac. For comparisons, package also includes 
the BFGS, LBFGS and steepest descent methods. 

2. Installation and Setup
=========================

Start Matlab and make sure that the working directory is set to the
main directory of the present package.  At the MATLAB prompt, run

  >> setupQuNac

If on linux, try

  >> setupQuNac_linux

The script adds the appropriate directories in the MATLAB path and runs mex 
on libsvmread.c, used to load the logistic problems.  
The script will try to permanently add these directories to your 
path (in pathdefs.m), but may fail due to administration reasons.  
In that case, please copy and paste to your startup.m file the 
'addpath' commands printed to the screen.

The startup.m file is not by default created in the startup folder of 
MATLAB. It has to be created by the user. For more information see:
http://www.mathworks.co.uk/help/matlab/ref/startup.html.
To find your current MATLAB startup folder type in MATLAB prompt:
  >> userpath
the returned value will be the directory of the startup folder.
For information about MATLAB startup folder see:
http://www.mathworks.co.uk/help/matlab/matlab_env/matlab-startup-folder.html.

To test if the installation and setup for the quNac have been 
completed successfully please run in the MATLAB prompt:

  >> demo_quNac


3. License
==========

 quNac or quasi-Newton action constrained 
 Copyright (C) 2014, Robert Gower

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.


4. The Authors
==============

If you have any bug reports or comments, please feel free to email 

  Robert Gower <r.m.gower@sms.ed.ac.uk>
  Robert Gower <gowerrobert@gmail.com>


Robert Gower
20 October 2014
