%% Problem tests

trigonometric

problem=13; n =6;