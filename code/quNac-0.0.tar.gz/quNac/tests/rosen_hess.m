function hd = rosen_hess(x,d)
% 
% Gradient of the Rosenbrock function
% Robert M. Gower, 2014

hd= zeros(size(d));

hd(2:end-1,:) = 2*d(2:end-1,:) +200*(d(2:end-1,:)-2.*bsxfun(@times, x(1:end-2,:),d(1:end-2,:)))...
    -200*bsxfun(@times,(d(3:end,:) -2*bsxfun(@times,x(2:end-1,:),d(2:end-1,:))).*2,x(2:end-1,:))...
    -200.*bsxfun(@times,(x(3:end,:) -x(2:end-1,:).^2).*2,d(2:end-1,:));
hd(1,:) = 2*d(1,:) -400.*bsxfun(@times,(d(2,:)-2*bsxfun(@times,x(1,:),d(1,:))),x(1,:))...
    -400.*bsxfun(@times,(x(2,:)-x(1,:).^2),d(2,:));
hd(end,:) = 200.*(d(end,:)-2.*bsxfun(@times,x(end-1,:),d(end-1,:)));