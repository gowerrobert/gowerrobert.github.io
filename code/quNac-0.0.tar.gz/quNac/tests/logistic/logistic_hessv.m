function Hv = logistic_hessv(X,y,w,v)

Xx  = X*w;
yXx = y.*Xx;
t1 =logistic_phi(yXx) ;
Hv = X'*((t1.*(1-t1).*(X*v)));

% t = 1./(1+exp(-yXx));
% Hv = X'*(t.*(1-t).*(X*v));
end