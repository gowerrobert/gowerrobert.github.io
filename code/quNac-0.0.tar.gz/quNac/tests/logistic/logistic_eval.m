function out = logistic_eval(X,y,w)

%out = sum(log(1 + exp(-(y).*(X*w))));    
    out = -sum(log(logistic_phi((y).*(X*w))));  
end