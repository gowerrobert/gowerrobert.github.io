function gout = logistic_grad(X,y,w)

Xx  = X*w;
yXx = y.*Xx;

gout = X.'*(y.*(logistic_phi(yXx) - 1));  
    
%gout1 = X.'*(y.*(t - 1));  
%  t = 1./(1+exp(-yXx));
end