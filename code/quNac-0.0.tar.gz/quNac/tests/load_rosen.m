%% Load Rosenbrock problem


x_opt = ones(n,1);
x0 = -ones(n,1);
f_eval = @(x)(rosen(x,n));
g_eval= @(x) rosen_grad(x);
Hess_opt =@(x,d)(rosen_hess(x,d));

tol = 1.0e-9;   