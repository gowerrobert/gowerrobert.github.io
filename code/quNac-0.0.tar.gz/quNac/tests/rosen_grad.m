function g = rosen_grad(x)
% 
% Gradient of the Rosenbrock function
% Robert M. Gower, 2014

g = zeros(size(x));


g(2:end-1,:) = 2*bsxfun(@plus,x(2:end-1,:),-1) ...
    + 200*( x(2:end-1,:)-x(1:end-2,:).^2 - (x(3:end,:)-x(2:end-1,:).^2).*(2*x(2:end-1,:)));
g(1,:) = 2*(bsxfun(@plus,x(1,:),-1)) -400*(x(2,:)-x(1,:).^2).*x(1,:);
g(end,:) = 200*(x(end,:)-x(end-1,:).^2);
