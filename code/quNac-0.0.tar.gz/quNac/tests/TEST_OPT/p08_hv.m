function g = p08_hv ( n, x, d )

%*****************************************************************************80
%
%% P08_G evaluates the gradient for problem 8.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    09 June 2014
%
%  Author:
%
%    Robert Gower
%
%  Parameters:
%
%    Input, integer N, the number of variables.
%
%    Input, real X(N), the values of the variables.
%
%    Output, real G(N), the gradient of the objective function.
%
  ap = 0.00001;
  g = zeros(size(d));
  t1 = - 0.25 + sum ( x(1:n).^2 );
  g = 2.0 * ap *d;
  g = g + 8* ((d')*x).*x + 4.0*t1.*d;
  
  %g(1:n,1) = 2.0 * ap * ( x(1:n,1) - 1.0 ) + 4.0 * x(1:n,1) * t1;

  return
end
