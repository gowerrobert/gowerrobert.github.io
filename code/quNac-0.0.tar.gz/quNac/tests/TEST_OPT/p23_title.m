function title = p23_title ( )

%*****************************************************************************80
%
%% P23_TITLE returns a title for problem 23.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    31 December 2000
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Output, string TITLE, a title for the problem.
%
  title = 'The De Jong Function F2';

  return
end
