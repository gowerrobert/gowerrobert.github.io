function title = p33_title ( )

%*****************************************************************************80
%
%% P33_TITLE returns a title for problem 33.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    11 January 2001
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Output, string TITLE, a title for the problem.
%
  title = 'The Shekel SQRN10 Function';

  return
end
