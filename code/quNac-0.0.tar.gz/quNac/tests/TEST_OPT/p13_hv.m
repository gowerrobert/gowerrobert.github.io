function g = p13_hv ( n, x,d )

%*****************************************************************************80
%
%% P13_G evaluates the gradient for problem 13.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    18 October 2011
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Input, integer N, the number of variables.
%
%    Input, real X(N), the values of the variables.
%
%    Output, real G(N), the gradient of the objective function.
%
g = zeros ( n, 1 );

sumcos = sum ( cos ( x(1:n) ) );
sumsin =  sum ( sin ( x(1:n) ) );
sind= (sin ( x(1:n) )')*d;
cosd = (cos ( x(1:n) )')*d;

ints = (1:n)';
for k = 1:n
    sk = sin(x(k));
    ck = cos(x(k));
    g(k) = g(k)+ (k*sk*d(k)-ck*d(k) + sind)*(k*sk-ck);  
    g(k) = g(k)+ (n+k-k*ck-sk-sumcos)*(k*ck*d(k) +sk*d(k)); 
    g(k) = g(k) + ((sin(x)')*(ints.*d) - cosd + n*sind)*sk;   
    g(k) = g(k)+ (n^2 + n*(n+1)/2 - ints'*cos(x) -sumsin- n*sumcos)*ck*d(k); 
  %  (sum(ints) - ints'*cos(x)-sumsin - n*sumcos)*ck*d(k);

end

g = 2*g;
return
end
