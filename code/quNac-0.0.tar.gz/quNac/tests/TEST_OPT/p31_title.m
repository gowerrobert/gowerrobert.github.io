function title = p31_title ( )

%*****************************************************************************80
%
%% P31_TITLE returns a title for problem 31.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    10 January 2001
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Output, string TITLE, a title for the problem.
%
  title = 'The Shekel SQRN5 Function';

  return
end
