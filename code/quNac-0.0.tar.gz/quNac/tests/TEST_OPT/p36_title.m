function title = p36_title ( )

%*****************************************************************************80
%
%% P36_TITLE returns a title for problem 36.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    16 October 2004
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Output, string TITLE, a title for the problem.
%
  title = 'The Stuckman Function';

  return
end
