function title = p22_title ( )

%*****************************************************************************80
%
%% P22_TITLE returns a title for problem 22.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    30 December 2000
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Output, string TITLE, a title for the problem.
%
  title = 'The De Jong Function F1';

  return
end
