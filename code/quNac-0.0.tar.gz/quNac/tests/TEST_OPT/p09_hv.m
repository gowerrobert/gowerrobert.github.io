function hv = p09_hv ( n, x ,d)

%*****************************************************************************80
%
%% P09_H evaluates the Hessian for problem 9.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    16 October 2011
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Input, integer N, the number of variables.
%
%    Input, real X(N), the values of the variables.
%
%    Output, real H(N,N), the N by N Hessian matrix.
%
  ap = 0.00001;
  hv = zeros ( n, 1 );
  
  t1 = - 1.0;
  for j = 1 : n
    t1 = t1 + ( n - j + 1 ) * x(j) * x(j);
  end

  d1 = exp ( 0.1 );
  d2 = 1.0;
  s2 = 0.0;
  th = 4.0 * t1;

  for j = 1 : n

    hv(j) = hv(j)+8.0 *d(j)* ( ( n - j + 1 ) * x(j) )^2 + ( n - j + 1 ) * th*d(j);

    s1 = exp ( x(j) / 10.0 );

    if ( 1 < j )

      s3 = s1 + s2 - d2 * ( d1 + 1.0 );
      hv(j) = hv(j) + (ap * s1 * ( s3 + s1 - 1.0 ...
        / d1 + 2.0 * s1 ) / 50.0)*d(j);
      hv(j-1) = hv(j-1) + (ap * s2 * ( s2 + s3 ) / 50.0)*d(j-1);
      for k = 1 : j-1
        t1 = exp ( k / 10.0 );
        hv(j) = hv(j)+(8.0 * ( n - j + 1 ) *  ( n - k + 1 ) * x(j) * x(k))*d(k);
        hv(k) = hv(k)+(8.0 * ( n - j + 1 ) *  ( n - k + 1 ) * x(j) * x(k))*d(j);
      end

      hv(j) = hv(j) + (ap * s1 * s2 / 50.0)*d(j-1);
      hv(j-1) = hv(j-1) + (ap * s1 * s2 / 50.0)*d(j);
    end

    s2 = s1;
    d2 = d1 * d2;

  end

  hv(1) = hv(1) + 2.0*d(1);

  %for i = 1 : n
  %  h(i,i+1:n) = h(i+1:n,i);
  %end

  return
end
