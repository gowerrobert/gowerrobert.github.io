function [opts,f_eval,g_eval,Hess_opt ] = load_TEST_OPT(problem,n,tol,opts)

opts.problem = problem;
if(strcmp(problem,'logistic'))
    [opts,f_eval,g_eval,Hess_opt ] =  load_logistic(problem,tol,opts); 
    assignin('caller','x0',opts.x0);
    return;
end
if(strcmp(problem,'quadratic'))
    [opts,f_eval,g_eval,Hess_opt ] =  load_quadratic(n,tol);
    opts.problem_title = ['Rand quadratic^2 n =' num2str(n) ];
    assignin('caller','x0',opts.x0);
    return;
end
title = p00_title ( problem );
display(['Loading ' title]);
[ know, x_opt ] = p00_sol( problem, n );
x0 = p00_start ( problem, n );
assignin('caller','x0',x0);
opts.problem_title = title;
if(know ==1)
    opts.x_opt = x_opt;
end
opts.x0 = x0;
opts.tol = tol;
opts.n = n;
f_eval = @(x)p00_f ( problem, n, x );
g_eval = @(x)p00_g ( problem, n, x );
switch (problem)
    case 44
        Hess_opt =p00_h ( problem, n, x0 ); 
    case 21
        Hess_opt =@(x,d)(p21_hv ( n, x,d));  
    case 20
        Hess_opt =@(x,d)(p20_hv ( n, x,d)); 
    case 15
        Hess_opt =@(x,d)(p15_hv ( n, x,d));     
        opts.tol  = 1.0e-10;
    case 14
        Hess_opt =@(x,d)(p14_hv ( n, x,d));          
    case 13
        Hess_opt =@(x,d)(p13_hv ( n, x,d));   
    case 9
        Hess_opt =@(x,d)(p09_hv ( n, x,d));        
    case 8
        Hess_opt =@(x,d)(p08_hv ( n, x,d));
    case 7
        Hess_opt =@(x,d)(p07_hv ( n, x,d));   
 %   case 7
 %       myADfun = ADfun('p44_fAD','1');
 %       ADoptions = setopt('htimesv', V);
 %       Hess_opt =@(x,d)(p07_hv ( n, x,d));   
    otherwise    
        Hess_opt =@(x,d)(p00_h ( problem, n, x )*d);  
end
end