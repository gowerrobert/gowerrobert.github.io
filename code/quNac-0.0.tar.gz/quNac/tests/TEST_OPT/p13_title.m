function title = p13_title ( )

%*****************************************************************************80
%
%% P13_TITLE returns a title for problem 13.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    16 March 2000
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Output, string TITLE, a title for the problem.
%
  title = 'The Trigonometric Function';

  return
end
