function [ fvec ] = p18_fvec ( n ,x)
% !
% !*******************************************************************************
% !
% !! P18_FVEC is an auxilliary routine for problem 18.
% !
% !
% !  Modified:
% !
% !    23 March 2000
% !
% !  Author:
% !
% !    John Burkardt
% !
% !  Parameters:
% !
% !    Input, integer N, the number of variables.
% !
% !    Input, real X(N), the argument of the objection function.
% !
% !    Output, real FVEC(N), an auxilliary vector.
% !

%   real fvec(n)
%   integer i
%   integer j
%   real t
%   real t1
%   real t2
%   real th
%   real x(n)

  fvec(1:n) = 0.0;

  for j = 1: n
    t1 = 1.0;
    t2 = 2.0 * x(j) - 1.0;
    t = 2.0 * t2;
    for i = 1: n
      fvec(i) = fvec(i) + t2;
      th = t * t2 - t1;
      t1 = t2;
      t2 = th;
    end 
  end 

  for i = 1: n
    fvec(i) = fvec(i) /typecast(n,'double');
    if ( mod ( i, 2 ) == 0 ) 
      fvec(i) = fvec(i) + 1.0 / ( typecast(i,'double') *2 - 1.0 );
    end 
  end 


end
