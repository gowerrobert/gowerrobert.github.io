function title = p26_title ( )

%*****************************************************************************80
%
%% P26_TITLE returns a title for problem 26.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    01 January 2001
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Output, string TITLE, a title for the problem.
%
  title = 'The De Jong Function F5';

  return
end
