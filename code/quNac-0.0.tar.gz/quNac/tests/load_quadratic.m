function [opts,f_eval,g_eval,Hess_opt ] =  load_quadratic(n,tol)

%% Load Quadratic problem

m=n;
A = randn(m,n);
%A = magic(n);

x_opt = rand(n,1);
b= A*x_opt;
opts.x0 = zeros(n,1);

f_eval = @(x)(func_eval_ext(x,A,b));
g_eval= @(x) grad_eval_ext(x, A,b);
Hess_opt = @(x,d) A_op_ext(A,d);

opts.n =n;
opts.problem = 'quadratic';
opts.tol = tol;
opts.x_opt = x_opt;
opts.PCG.x0 = opts.x0;
opts.PCG.iter =0;
 fprintf('Rand psd quadratic %6.0f X %6.0f \n ',n,m);
end
