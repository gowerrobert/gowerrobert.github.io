#include <iostream>
#include <time.h>
#include "NewtonsMethod.h"
#include "HalleyCheby.h"
#include "LinAlgebra.h"

using namespace std;
template <class indep_var>  indep_var f_eval(const indep_var * x, const int n){
  int  i;
  indep_var fad=1;
  /*---------------------------------------------------------------------------------*/
  /* f: R^n -> R. f(x) = fad.  You may use all basic functions, for a complete list consult the ADOL-C manuel */
  /* For futher examples of functions, see src/Functions */

  //Brachistochrone Problem NAME: bc4, princeton noncute
  double param_subtract;
  for(i=1;i<n;i++){
    param_subtract = pow(double(i)/double(n),4)-pow(double(i-1)/double(n),4);
    fad = fad +  sqrt( (1+pow((x[i] - x[i-1])/(param_subtract),2))/x[i-1] )*(param_subtract);
  }
  // Adding a quadratic penalty function for constraint
  fad = fad+ 1000*pow(x[0]-1.0E-12,2) + pow(x[n-1]-1,2);
      return fad;
}
void initial_point ( double *x_initial, const int n){
  /* CHOOSE INITIAL POINT HERE!!! *******************************/
  //Brachistochrone Problem initial point with boundary condition
  for(int i=0; i<n ; i++) x_initial[i] =double(i)/double(n);
  x_initial[0] =  1.0E-12;
  x_initial[n-1] = 1;
  /*************************************************************/
}
template double f_eval<double>(const double  *x, const int n);
template adouble f_eval<adouble>(const adouble  *x, const int n);

int main()
{
  int i;
  int n =10000;
  double *x = new double [n];

  /********* Initial point *********/
  initial_point(x,n);
  /****************************************************/
  cout<<"/****Simplest Call to Halley-Chebyshev solver*******/"<<endl<<endl;
  /***************************************************/
  double lambda = 1.0;
  double precision = 1.E-6;   // Finds an equilibria such that ||grad|| < = precision* ||grad_0 ||
  bool print_iteration = true;

  HalleyCheby  HC (n, precision,print_iteration,lambda);   // Instantiate a Halley-Chebyshev solver
  HC.set_ObjectiveFunction(n, x,  f_eval<double>,  f_eval<adouble>,"bc4");   //Set Objective function
  HC.solve(); // solve
  /****************************************************/
  cout<<"/****Setting different parameters and solving *******/"<<endl<<endl;
  /***************************************************/
  //cout<<"Dimension?"<<endl;
  //cin>>n;
  LinAlgebra LinAlg;    // LinearAlgebra Class
  int max_iter = 10*n;
  double system_precision = 1.E-4;   // linear system solve precision

  HalleyCheby  HC1 (n, precision,print_iteration,lambda);   // Instantiate a Halley-Chebyshev solver
  HC1.set_ObjectiveFunction(n, x,  f_eval<double>,  f_eval<adouble>,"bc4");
  HC1.set_x_initial(initial_point); //Set initial point by passing a function pointer
  HC1.set_system_precision(system_precision) ; // Setting system precision to solve until  ||Ax- b|| <=  system_precision * || b||. system_precision=0 is the Gunderson & Steihaug option
  HC1.set_print_system_solve(false);          // Print system solve iterations? The default is false
  HC1.set_print_iteration(true);
  HC1.set_max_iterations(max_iter); // Set maximum number of iterations
  HC1.set_linear_solver_type(LinAlg.CONJUGATEGRADIENTS);  // Set type of linear solver to LinAlg.MINIMALRESIDUAL (Default) or LinAlg.CONJUGATEGRADIENTS
  HC1.solve();
  /****************************************************/
  cout<<" /****Comparing Newton's method to HalleyCheby with different parameters. *******/"<<endl<<endl;
  /***************************************************/

  NewtonsMethod  NM (n, precision,false);   // Instantiate a Newtons-Method solver
  NM.set_ObjectiveFunction(n, x,  f_eval<double>,  f_eval<adouble>,"bc4");
  NM.set_max_iterations(max_iter); // Set maximum number of iterations

  HC1.set_linear_solver_type(LinAlg.MINIMALRESIDUAL);
  HC1.set_print_system_solve(false);
  HC1.set_print_iteration(false);
  double HC0_t, HC05_t, HC1_t, NM_t;
  string HC0_state, HC05_state, HC1_state,NM_state;
  clock_t t;

  HC1.set_lambda(0.0);
  t = clock();
  HC0_state = HC1.solve();
  HC0_t = (float(clock() -t))/CLOCKS_PER_SEC ; //*/

  HC1.set_lambda(0.5);
  t = clock();
  HC05_state = HC1.solve();
  HC05_t = (float(clock() -t))/CLOCKS_PER_SEC; //*/

  HC1.set_lambda(1.0);
  t = clock();
  HC1_state = HC1.solve();
  HC1_t = (float(clock() -t))/CLOCKS_PER_SEC; //*/

  t = clock();
  NM_state= NM.solve();
  NM_t = (float(clock() -t))/CLOCKS_PER_SEC;//*/

  cout<<"HalleyCheby0: "<<"  "<<HC0_state<<" in "<<HC0_t<<"s"<<endl;
  cout<<"HalleyCheby05: "<<"  "<<HC05_state<<" in "<<HC05_t<<"s"<<endl;
  cout<<"HalleyCheby1: "<<"  "<<HC1_state<<" in "<<HC1_t<<"s"<<endl;
  cout<<"NewtonsMethod: "<<NM_state<<" in "<<NM_t<<"s"<<endl;
  //*///
  cout<<"dimension: "<<n<<endl;
  delete[] x;
  return 0;
}

