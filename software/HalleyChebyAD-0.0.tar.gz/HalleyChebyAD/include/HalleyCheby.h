#ifndef HALLEYCHEBY_H
#define HALLEYCHEBY_H
#include <UncOpt.h>
//! The derived class that uses a Halley-Chebyshev type search direction
class HalleyCheby : public UncOpt
{
    public:
      explicit HalleyCheby(const int dimension_int, const double precision_in, const bool print_it = false, const double lambda_in =1.0);
        virtual~HalleyCheby();
        int methodstep();
	/** Alterantive step method that calculates  Newton+Halley search direction in the second system solve directly**/
//        int methodstep_alt(); 
        void set_lambda(int lambda_in);
    protected:
    private:
        double * newtdir;
        double lambda;
      //  double * direction;
};

#endif // HALLEYCHEBY_H
