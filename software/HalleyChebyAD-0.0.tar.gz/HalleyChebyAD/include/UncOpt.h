#ifndef UNCOPT_H
#define UNCOPT_H

#include<iostream>
#include<string>
#include<vector>
#include<stdio.h>
#include <sstream>
#include"ObjectiveFunction.h"
#include "Derivatives.h"
#include "LinAlgebra.h"
#include <numeric>
//! The Base class of Unconstrained Optimization solvers.
class UncOpt
{
public:
  explicit UncOpt(const int dimension_int =0, const double precision_in= 1.0E-8, std::string name_in ="no_name",const bool print_it =false);
    virtual ~UncOpt();
    void reset();
    virtual string solve(); //Can only be called by derived class.
    virtual int methodstep() = 0; //**Can only be called by derived class.*/    
   // void copy_ObjectiveFunction (const ObjectiveFunction &);
    void set_ObjectiveFunction(const int dimension_in,  double * x_initial_in,
    double (*eval_in)( const double *, int),  adouble  (*eval_a_in)( const adouble*,int),const string name_in);
    LinAlgebra LinAlg;    //Mostly linear algebra support
    double get_error(){if(gradnorm0==0) return(0.0); else return(gradnorm/gradnorm0);}
    int get_iteration(){return(iteration);}
    void set_print_iteration(const bool b);
    void set_print_system_solve(const bool b);
    void set_precision(const double prec);
    void set_system_precision(const double prec);
    void set_max_iterations(const int max_iterations_in);
    void set_x_initial(void (*initial_pointpty)(double *,const int dimension));
    void print_iteration_info();
    void print_iteration_header();
    void print_stopping_criteria();
    void set_linear_solver_type(int linear_solver_type_in){ linear_solver_type  = linear_solver_type_in;}
protected:
    /** Contains the objective function and tape capacities */
    ObjectiveFunction ObjFunc; 
    bool stopping_criteria();
    double armijo();
    double inexact_solve_precision(const double & rhs);
    std::string name;
    int dimension;
    double precision;
    int iteration;
    int max_iterations;
    int max_system_iter;
    double initial_stepsize;
    double steptaken;
    double objval;
    double gradnorm;
    double gradnorm0;
    double grad_precision;
    double system_precision;
    bool print_iteration;
    bool print_system_solve; 
    int print_title;
    int my_number;
    Derivatives Deriv;
    double func_diff;
    double * x_prev;
    double * temp_use;
    double * x;
    double * descent;
    std::string state;
    int linear_solver_type;
private:
    void operator=(const UncOpt&);  // Making the copy constructor private
    static int tape_num;
    void parameter_default();
};

#endif // UNCOPT_H
