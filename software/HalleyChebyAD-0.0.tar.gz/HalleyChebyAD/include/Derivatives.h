#ifndef DERIVATIVES_H
#define DERIVATIVES_H
#include <adolc/adolc.h>
//#include "Support.h"
//! Wraps all derivative information and communicates with ADOL-C. 
class Derivatives
{
    public:
        Derivatives(int tape_number_in, int dimension);
        virtual ~Derivatives();
        int eval_2nd_order(double * x);
        int eval_3rd_order(double * x, double * direction);
	void set(const int tape_num_in, int dimension_in){ tape_num = tape_num_in;  dimension = dimension_in;}
        double * Gradient;
        Graph * HessianGraph;
        Graph * TensorVectorGraph;
    protected:
    private:
        int tape_num;
        int dimension;
        int max_active;
};

#endif // DERIVATIVES_H
