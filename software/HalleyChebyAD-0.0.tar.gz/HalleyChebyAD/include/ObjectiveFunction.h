//! @class ObjectiveFunction
/*!
* @brief  Responsibilites: Interfaces with ADOL-C. and Taping the function.
*/

#ifndef OBJECTIVEFUNCTION_H
#define OBJECTIVEFUNCTION_H

#include<adolc/adolc.h>
class ObjectiveFunction
{
public:
    explicit ObjectiveFunction(const  int dimension_in); //Setups with standard function_eval
    ObjectiveFunction(const  int dimension_in,  double * x_initial_in,  double (*eval_in)(const double * , const int ),
                         adouble (*eval_a_in)(const adouble * , const int ), const  string name_in );
    ObjectiveFunction( const ObjectiveFunction & rhs);
    void swap(ObjectiveFunction&, ObjectiveFunction& );
    ObjectiveFunction& operator=(ObjectiveFunction rhs);
    virtual ~ObjectiveFunction();
    void set_x_initial(void (*initial_pointpty)(double *,const int dimension));
    double tape_it(const double * x, const short int tape_number);
    double (*eval)(const double * x, const int dim);
    adouble (*eval_a)(const adouble * x, const int dim);
    double * x_initial;
    void print() const;
private:
   int dimension;
   std::string name;
};
//ObjectiveFunction * setup_function_eval(int dimension);
#endif // OBJECTIVEFUNCTION_H
