#ifndef NEWTONSMETHOD_H
#define NEWTONSMETHOD_H

#include <UncOpt.h>
//! The derived class that uses NewtonMethod type search direction
class NewtonsMethod : public UncOpt
{
    public:
       // NewtonsMethod(int dimension_int);
       NewtonsMethod(const int dimension_int, const double precision_in =1.0E-8, const bool print_it =false);
        ~NewtonsMethod();
        int methodstep();
    protected:
    private:
        int tapenum; //Going to implement using Automatic differentiation.
};

#endif // NEWTONSMETHOD_H
