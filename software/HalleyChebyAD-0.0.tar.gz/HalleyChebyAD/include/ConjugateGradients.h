#include <adolc/adolc.h>
#include "SimpleVector.hpp"

template < class Vector>
class ConjugateGradients{
  public:
    enum { BELOW_TOLERANCE, REACHED_MAX_ITER, NOT_FINISHED, NEGATIVE_CURVATURE, ZERO_CURVATURE };
    string  EnumStrings[5]; // = { "REACHED_MAX_ITER", "BELOW_TOLERANCE", "NOT_FINISHED"};
    string getTextForEnum( int enumVal )
    {
      return EnumStrings[enumVal];
    }
    int iterations;
    const int max_iterations;
    double tol;
    double resid;
    Vector x;
    ConjugateGradients(const int _max_iterations, const double _tol, const Vector &Ax,  const Vector &_x,const Vector &b, Vector &p, bool print_system_solve);
    ~ConjugateGradients();
    int step(Vector &Ax, Vector &p);
    void print();
    void activate_printing(bool b);
    int get_state() const{ return(state);}
  private:
    ConjugateGradients( ConjugateGradients& other ); //Prohibit copy construct.
    int state;
    int print_multiple;
    int print_count;
    bool print_on;
    double normr0;
    Vector b;
    Vector r;
    Vector temp;
};

