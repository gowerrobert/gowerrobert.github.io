//! LinAlgebra for linear system solve and vector operations
#ifndef LINEARALGEBRA_H
#define LINEARALGEBRA_H
#include <adolc/adolc.h>
#include "ObjectiveFunction.h"
#include "ConjugateGradients.h"
#include "SimpleVector.hpp"
#include "tminres.hpp"
//#include "RVector.h"
class LinAlgebra
{
public:
     LinAlgebra();
     virtual ~LinAlgebra();
    //! The method used to solve systems.
    int solvesystem(const int max_iterations, const Graph * Mat, double *solution,  const  double * rhs,const  double precision, const bool show, const int linearsolver);
    //! Types of linearsystem_solvers
    enum {CONJUGATEGRADIENTS, MINIMALRESIDUAL};
//     string  EnumStrings[2]; // = { "REACHED_MAX_ITER", "BELOW_TOLERANCE", "NOT_FINISHED"};
//     string getlinearsolver( int enumVal )
//     {
//       return EnumStrings[enumVal];
//     }
    //! The Conjugate Gradient method. Mat is assumed to be symmetric-positive-definite
    int solveCG (const int max_iterations, const Graph * Mat, double *solution,  const  double * rhs,const  double precision, const bool show);
    //! The Least-Squares Conjugate Gradient method. Mat is assumed to be symmetric and non-singular
   // int solveCGNR(const int max_iterations, const Graph * Mat, double *solution,  const  double * rhs,const  double precision);
    //! The Minimal Residual method. Mat is assumed to be symmetric and non-singular
    int solveMinRes( const int max_iterations, const Graph * Mat, double *solution,  const  double * rhs, const  double precision, const bool show);
    void sum(double *lhs, const double * rhs, int dimension);
    void subtract(double *lhs, const double * rhs, int dimension);
    double norm(const double * x, int dimension);
    void copyvec(double *lhs,const  double * rhs, int dimension);
    void mult_scalar(double * x, int dimension, const double scal);
    double inner_prod(const double * x, const double *y, int dimension);
    template <class ArrayType>void print_array(ArrayType x, int length)
    {
        int i;
        for(i =0; i < length; i++)
            cout<<x[i]<<' ';
        cout<<endl;
    }
protected:
private:
};


//**** For interfacing with tminres.hpp ************//
class Preconditioner
{
public:
	//! Y = M\X
	virtual void Apply(const SimpleVector & X, SimpleVector & Y) const = 0;
};

//!@class Operator
/*
 * @brief A simple diagonal linear operator.
 * The first half of the diagonal entries are positive, the second half are negative
 */
class Operator
{
public:

	//!Constructor
	/*
	 * @param size_ problem size
	 */
	Operator(int size_, const Graph * _Mat) :
		size(size_), Mat(_Mat)
	{

	}

	~Operator()
	{
	}

	//! Y = A*X;
	void Apply(const SimpleVector & vec_in, SimpleVector & vec_out) const
	{
//Needs to work for MinRes!

	//	for(int i(0); i < size; ++i)
		//	vec_out[i] = (Mat->B[i])* vec_in;
			Mat->vector_mult(vec_in,vec_out);
	}


private:
	int size;
        const Graph * Mat;
};

 //double Block::operator*<RVector>(const RVector & xvec)
 //double Graph::operator*<RVector>(const RVector & xvec)
#endif // LINEARALGEBRA_H
