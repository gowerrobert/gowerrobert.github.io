HalleyChebyAD: Halley-Chebyshev method with automatic derivatives using ADOL-C and a HighOrderAD patch.
---------------------------------------------------------------------------

1. Introduction
===============

This package implements the Halley-Chebyshev methods with automatic derivatives by interfacing with the ADOL-C
and HighOrderAD package. With automatic derivatives, the user can easily test the Halley-Chebshev methods over different function.
The main features of HalleyChebyAD

=> Calculating then necessary Hessian directional derivative (D^3 f(x) \cdot v) has the same time cost as
calculating the Hessian matrix using a state-of-the-art method.
=> Uses inexact system solvers MINIMALRESIDUAL and CONJUGATEGRADIENTS.
=> Uses a sufficent decrease line-search.
=> Function evaluation needs to be written in C++

Examples are given on how to use the HalleyChebyAD in the example directory
inside the main directory HalleyChebyAD.

2. Installation and Setup
=========================

  1) Download the ADOL-C_2.5.0_HighOrderReverse-1.0  package from  http://www.maths.ed.ac.uk/~s1065527/software.html. This is a short-cut installationg of ADOL-C_2.5.0 and HighOrderReverse.
  2) Follow the README instructions contained in ADOL-C_2.5.0_HighOrderReverse-1.0. If it fails, download HighOrderReverse and ADOL-C separately and follow the HighOrderAD/README.txt.
  3) cd into HalleyChebyAD/examples. Type in the command
    $make
    This will compile and execute the example "main_simple.cpp" which is in the root directory.

  => The Class "Derivatives" uses ADOL-C and  includes the package #include <adolc/adolc.h>.
The Makefile assumes that ADOL-C is installed in the path ${HOME}/adolc_base


3. License
==========

 HalleyChebyAD Copyright (C) 2014, Robert Gower.

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.


5. The Author
==============

If you have any bug reports or comments, please feel free to email me:

  Robert Gower <gowerrobert@gmail.com>

All the best,
Robert,
20 Nov 2014
