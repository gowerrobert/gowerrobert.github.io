var class_halley_cheby =
[
    [ "HalleyCheby", "class_halley_cheby.html#aebd1b479f6815b3df936423efa965994", null ],
    [ "~HalleyCheby", "class_halley_cheby.html#a3f76bbffefd433ebe7b085f274c01035", null ],
    [ "methodstep", "class_halley_cheby.html#a93c4f551c0018202c8a7e9b9f5af0a27", null ],
    [ "set_lambda", "class_halley_cheby.html#a5f86c33d5b450b752f4166a7db55fe28", null ]
];