var class_operator =
[
    [ "Operator", "class_operator.html#aa857459e34e3d39830cecd3a0e8b6579", null ],
    [ "~Operator", "class_operator.html#a2dedbf3c020736c8962f1d8d89f6cff3", null ],
    [ "Apply", "class_operator.html#a74889bdc666dd5275e75031dba9cd137", null ]
];