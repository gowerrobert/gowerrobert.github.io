var class_derivatives =
[
    [ "Derivatives", "class_derivatives.html#a81cd30be7522cbb9243d7219f4aebeb1", null ],
    [ "~Derivatives", "class_derivatives.html#ad48565dce53659ff86c9dcc7107b6f71", null ],
    [ "eval_2nd_order", "class_derivatives.html#a17138b4db72451011c5a783de43f2bca", null ],
    [ "eval_3rd_order", "class_derivatives.html#a183fd8db8d7c075b790a69134dba0cac", null ],
    [ "set", "class_derivatives.html#a304cd84a52e90e89e6b89525a2c5816f", null ],
    [ "Gradient", "class_derivatives.html#a207a1e93563adca070b36a3094a07d57", null ],
    [ "HessianGraph", "class_derivatives.html#abdbc812100013b9b26833b0043915f4a", null ],
    [ "TensorVectorGraph", "class_derivatives.html#ad86a7a23827d92982664aa68a35f1a6d", null ]
];