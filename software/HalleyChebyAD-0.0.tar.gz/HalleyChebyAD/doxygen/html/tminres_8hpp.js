var tminres_8hpp =
[
    [ "MINRES", "tminres_8hpp.html#a48faf7db1299ca4f61d7f0271b9fa794", null ]
];