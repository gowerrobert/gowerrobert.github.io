var annotated =
[
    [ "ConjugateGradients", "class_conjugate_gradients.html", "class_conjugate_gradients" ],
    [ "Derivatives", "class_derivatives.html", "class_derivatives" ],
    [ "HalleyCheby", "class_halley_cheby.html", "class_halley_cheby" ],
    [ "NewtonsMethod", "class_newtons_method.html", "class_newtons_method" ],
    [ "ObjectiveFunction", "class_objective_function.html", "class_objective_function" ],
    [ "SimpleVector", "class_simple_vector.html", "class_simple_vector" ],
    [ "UncOpt", "class_unc_opt.html", "class_unc_opt" ]
];