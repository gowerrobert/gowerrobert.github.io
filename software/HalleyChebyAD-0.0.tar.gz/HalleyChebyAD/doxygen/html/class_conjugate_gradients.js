var class_conjugate_gradients =
[
    [ "BELOW_TOLERANCE", "class_conjugate_gradients.html#a892a9b3083de112de187daa2736718e7a7d9219615f88f4f2ada30437f9f7c81a", null ],
    [ "REACHED_MAX_ITER", "class_conjugate_gradients.html#a892a9b3083de112de187daa2736718e7a478c367ce1b57be088a86f29ff6901e0", null ],
    [ "NOT_FINISHED", "class_conjugate_gradients.html#a892a9b3083de112de187daa2736718e7aac637b3cb49eb97ce95e1bdf6b46ba65", null ],
    [ "NEGATIVE_CURVATURE", "class_conjugate_gradients.html#a892a9b3083de112de187daa2736718e7aa09b8419c891b158d2fed0a512171e51", null ],
    [ "ZERO_CURVATURE", "class_conjugate_gradients.html#a892a9b3083de112de187daa2736718e7abe53d92cb0652bd7d553e134f66da0fc", null ],
    [ "ConjugateGradients", "class_conjugate_gradients.html#ad13c3b30430184257101f03c6390eb47", null ],
    [ "~ConjugateGradients", "class_conjugate_gradients.html#af5887e64af4ff5b3acdc543025e1fae2", null ],
    [ "activate_printing", "class_conjugate_gradients.html#a4c7cce51b3161612a9750e0bb555d809", null ],
    [ "get_state", "class_conjugate_gradients.html#a6fa6850b93c5a14e064fd76666fc25fb", null ],
    [ "getTextForEnum", "class_conjugate_gradients.html#af8565e76a936b747807c477d624a68b5", null ],
    [ "print", "class_conjugate_gradients.html#aafb7722521c1af343a41f58abc08c64a", null ],
    [ "step", "class_conjugate_gradients.html#ac24ae2430ade56bcc1f2253e21138b12", null ],
    [ "EnumStrings", "class_conjugate_gradients.html#a8e956d536557149214d1bc128d26c628", null ],
    [ "iterations", "class_conjugate_gradients.html#a8acd2b9d4befe1a5f29ae331edcaaedd", null ],
    [ "max_iterations", "class_conjugate_gradients.html#ae89db78b970658916c202c9323b9b432", null ],
    [ "resid", "class_conjugate_gradients.html#adaa267e8b47ea3fd0a87ea4edbe261b2", null ],
    [ "tol", "class_conjugate_gradients.html#afc7d8a48ee6a9ad22e9d45a7553bc6c6", null ],
    [ "x", "class_conjugate_gradients.html#ab93dfd3c90e3fd06bb6d649aef09dcfe", null ]
];