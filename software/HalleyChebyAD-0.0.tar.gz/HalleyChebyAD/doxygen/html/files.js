var files =
[
    [ "ConjugateGradients.h", "_conjugate_gradients_8h_source.html", null ],
    [ "Derivatives.h", "_derivatives_8h_source.html", null ],
    [ "HalleyCheby.h", "_halley_cheby_8h_source.html", null ],
    [ "NewtonsMethod.h", "_newtons_method_8h_source.html", null ],
    [ "ObjectiveFunction.h", "_objective_function_8h_source.html", null ],
    [ "setup_functions.h", "setup__functions_8h_source.html", null ],
    [ "SimpleVector.cpp", "_simple_vector_8cpp.html", "_simple_vector_8cpp" ],
    [ "SimpleVector.hpp", "_simple_vector_8hpp.html", [
      [ "SimpleVector", "class_simple_vector.html", "class_simple_vector" ]
    ] ],
    [ "tminres.hpp", "tminres_8hpp.html", "tminres_8hpp" ],
    [ "UncOpt.h", "_unc_opt_8h_source.html", null ]
];