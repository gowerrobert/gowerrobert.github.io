var searchData=
[
  ['tminres_2ehpp',['tminres.hpp',['../tminres_8hpp.html',1,'']]]
];
