var searchData=
[
  ['newtonsmethod',['NewtonsMethod',['../class_newtons_method.html',1,'']]]
];
