var searchData=
[
  ['derivatives',['Derivatives',['../class_derivatives.html',1,'']]]
];
