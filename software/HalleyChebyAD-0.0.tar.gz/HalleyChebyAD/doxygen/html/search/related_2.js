var searchData=
[
  ['subtract',['subtract',['../class_simple_vector.html#ad1b37eaf41ad4116a13adae34f959099',1,'SimpleVector']]]
];
