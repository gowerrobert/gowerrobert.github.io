var searchData=
[
  ['conjugategradients',['ConjugateGradients',['../class_conjugate_gradients.html',1,'']]]
];
