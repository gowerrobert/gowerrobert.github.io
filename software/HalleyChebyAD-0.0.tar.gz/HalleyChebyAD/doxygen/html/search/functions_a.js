var searchData=
[
  ['_7enewtonsmethod',['~NewtonsMethod',['../class_newtons_method.html#a8a46f0dbfe9a933a0115e793ccc201b5',1,'NewtonsMethod']]],
  ['_7esimplevector',['~SimpleVector',['../class_simple_vector.html#a4b135909ad9faeda44d5a801ba5c74fc',1,'SimpleVector']]]
];
