var hierarchy =
[
    [ "ConjugateGradients< Vector >", "class_conjugate_gradients.html", null ],
    [ "Derivatives", "class_derivatives.html", null ],
    [ "ObjectiveFunction", "class_objective_function.html", null ],
    [ "SimpleVector", "class_simple_vector.html", null ],
    [ "UncOpt", "class_unc_opt.html", [
      [ "HalleyCheby", "class_halley_cheby.html", null ],
      [ "NewtonsMethod", "class_newtons_method.html", null ]
    ] ]
];