var class_support =
[
    [ "Support", "class_support.html#a19bf40018bf3004487c65f7e68c9f65e", null ],
    [ "~Support", "class_support.html#ad279b30bdefcfc501d4f06cc9b45b4c0", null ],
    [ "copyvec", "class_support.html#a780eab180f6f0c284fd4504d6669d5b7", null ],
    [ "inner_prod", "class_support.html#a448051750aa68bcb4fbc11442cd281a9", null ],
    [ "mult_scalar", "class_support.html#a667fbdef28234aed52b43513a4129578", null ],
    [ "norm", "class_support.html#a5f77c5f1490f5fa0cc118202328d4374", null ],
    [ "print_array", "class_support.html#a11b6a3c6a351b688acd78891b05b6860", null ],
    [ "solveCG", "class_support.html#a17740e381445e0331b0ee54af3db3453", null ],
    [ "solveCGNR", "class_support.html#a0ddbd35f73b8566d1d10a32fe618b3bd", null ],
    [ "solveMinRes", "class_support.html#a46b269b15f16b7bf4366707428ff0d6f", null ],
    [ "solvesystem", "class_support.html#af5cc8e7b2096deffd6caa9e3950a045d", null ],
    [ "subtract", "class_support.html#a124a6bbe57c6a0731d7637fe3e0049ac", null ],
    [ "sum", "class_support.html#afc8bf4d82d3c034078328e1d74e66b82", null ]
];