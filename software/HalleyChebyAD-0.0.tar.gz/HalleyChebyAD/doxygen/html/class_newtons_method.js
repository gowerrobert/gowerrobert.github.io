var class_newtons_method =
[
    [ "NewtonsMethod", "class_newtons_method.html#a46e9684acfb1afe17b04629fb9f40407", null ],
    [ "~NewtonsMethod", "class_newtons_method.html#a8a46f0dbfe9a933a0115e793ccc201b5", null ],
    [ "methodstep", "class_newtons_method.html#a98a8e634f4c46d033521df2bc8ecd7b6", null ]
];