#include "Derivatives.h"

Derivatives::Derivatives(int tape_num_in, int dimension_in):
    tape_num(tape_num_in),
    dimension(dimension_in),
    Gradient(NULL),
    HessianGraph(NULL),
    TensorVectorGraph(NULL)
{//Are my copy constructors appropriate for the Graphs?
}
Derivatives::~Derivatives()
{
   // cout<<"called Deriv Destructor"<<endl;
    if(Gradient != NULL)
        delete [] Gradient;
    if(HessianGraph != NULL)
        delete HessianGraph;
    if(TensorVectorGraph != NULL)
        delete TensorVectorGraph;
}

int Derivatives::eval_2nd_order(double * x){// cout<<"Hessian eval with dimension "<<dimension<<" on tape "<<tape_num<<endl;
  return(reverse_hessian(tape_num,x, &Gradient, &HessianGraph, dimension, NULL));
}
int Derivatives::eval_3rd_order(double * x, double * direction){
     return(reverse_tensorv( tape_num,  x, &Gradient, &HessianGraph,
                            &TensorVectorGraph, dimension, direction,NULL));
}
