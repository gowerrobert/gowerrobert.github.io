    #include "UncOpt.h"
using namespace std;

int   UncOpt::tape_num =1;
UncOpt::UncOpt(const int dimension_in, const double precision_in, string name_in,  const bool print_it)
               :dimension(dimension_in),
               precision(precision_in),
               name(name_in),
	           LinAlg(),
	           ObjFunc(dimension_in),
               Deriv(tape_num,dimension_in),
               print_iteration(print_it),
               linear_solver_type(LinAlg.MINIMALRESIDUAL)
               {
    /*Selecting a tape number based  on how many instances have been created */
    //cout<<"UncOpt construct"<<endl;
    my_number = tape_num;
    parameter_default();
    grad_precision= precision;

    x = new double [dimension];
    x_prev = new double [dimension];
    descent = new double [dimension];
    temp_use = new double [dimension];

    std::fill(x,x+dimension,1);
    std::fill(x_prev,x_prev+dimension,1);
    std::fill(descent,descent+dimension,0);
    std::fill(temp_use,temp_use+dimension,0);
    reset();
}
void UncOpt::parameter_default(){
     max_iterations =dimension;
     max_system_iter = dimension;
     //** The Gunderson precision type
     system_precision = 0.0;// 1.0E-1;
     print_system_solve = false;
     print_title =30;
}
UncOpt::~UncOpt()
{ //***  Descructor of father class UncOpt */
   // cout<<"Destruct Uncopt"<<endl;
    delete [] x;
    delete [] x_prev;
    delete [] descent;
    delete [] temp_use;
   // if(ObjFunc != NULL)
   //   delete ObjFunc;
}
void UncOpt::reset()
{
  // No call to  parameter_default() ???
  iteration =0;
  objval = 666.0;
  gradnorm = 666.0;
  gradnorm0 = 666.0;
  func_diff =666.0;
  steptaken = 666.0;
  initial_stepsize =1;
  steptaken = 1;

  std::copy(ObjFunc.x_initial, ObjFunc.x_initial + dimension, x);
  std::copy(x, x + dimension, x_prev);
  std::fill(descent,descent+dimension,0.0);
  std::fill(temp_use,temp_use+dimension,0.0);
}
string UncOpt::solve()
{   //! The template solver. The derived classes implement the search direction in methodstep().
    int i;
    double alpha;
    if(dimension==0)
    {
        cout<<"No dimension has been set! Use set_dimension"<<endl;
        return(0);
    }
    /** **** HOW TO DETECT NO OBJECTIVE FUNCTION? **** **/
  //  else if(ObjFunc==NULL)
  //  {
 //     cout<<"No ObjectiveFunction has been set for "<<name<<"! Use set_ObjectiveFunction"<<endl;
 //     return("0");
  //  }
    reset();
    Deriv.eval_2nd_order(x);     //Calculate 1st and 2nd order derivative info
    gradnorm0 = LinAlg.norm(Deriv.Gradient, dimension);
    gradnorm =gradnorm0;
    objval = ObjFunc.eval(x,dimension);
    if(print_iteration)
      print_iteration_info();
    //cout<<"gradient: "; LinAlg.print_array(Deriv.Gradient,dimension);
    while(stopping_criteria())
    {
	methodstep();  //Calculates descent direction
        LinAlg.mult_scalar(descent, dimension, armijo()); // determine step size
	LinAlg.sum(x,descent,dimension);//sum direction to new point
     //         cout<<"solution"<<endl;
      //  LinAlg.print_array(x,dimension);
       //  cout<<"Objval: "<<ObjFunc.eval(x,dimension)<<endl; // */
        //Updates stopping criteria info
      //  cout<<"gradient: ";
	//LinAlg.print_array(Deriv.Gradient,dimension);
	Deriv.eval_2nd_order(x);      //Calculate 1st and 2nd order derivative info
        gradnorm = LinAlg.norm(Deriv.Gradient, dimension);

        objval = ObjFunc.eval(x,dimension);
	steptaken = LinAlg.norm(descent,dimension);
        LinAlg.copyvec(x_prev,x,dimension);
        iteration++;
	if(print_iteration)
	  print_iteration_info();
    }
    if( std::isinf(objval))
      if (objval<0)
         state = "unbounded-below";
      else
	 state = "unbounded-above";
    else  if(std::isnan(objval))
	state = "Outside-domain";
    else if (get_error()  <precision)
      state = "converged";
    else if(steptaken< 0.5*pow(precision,2))
      state ="small-step";
    else if(iteration>= max_iterations)
      state = "max-iter";
    else
      state ="undefined";

    cout<<name<<" ";print_stopping_criteria();
    return(state);
}
void UncOpt::set_ObjectiveFunction(const int dimension_in,  double * x_initial_in,
double (*eval_in)( const double *, int),
adouble  (*eval_a_in)( const adouble*,int),const string name_in){
  //! Sets the Objective function and tapes it for later derivative calculations
 // if(ObjFunc !=NULL)
  //  delete ObjFunc;
//  ObjFunc = new ObjectiveFunction( dimension_in,  x_initial_in, eval_in, eval_a_in , name_in);
  ObjectiveFunction ObjFunc_temp( dimension_in,  x_initial_in, eval_in, eval_a_in , name_in);
  ObjFunc =ObjFunc_temp;
  Deriv.set(tape_num, dimension_in);
  ObjFunc.tape_it(x,tape_num);
  tape_num ++;
                               }
void UncOpt::set_print_iteration(const bool b){
  print_iteration = b;
}
void UncOpt::set_print_system_solve(const bool b){
  print_system_solve = b;
}
void UncOpt::set_system_precision(const double prec){
system_precision = prec;
}
void UncOpt::set_precision(const double prec){
precision = prec;
}
void UncOpt::set_max_iterations(const int max_in_){
  max_iterations = max_in_;
}
void UncOpt::set_x_initial(void (*initial_pointpty)(double *,const int dim)){
  ObjFunc.set_x_initial(initial_pointpty);
}
bool UncOpt::stopping_criteria()
{
   // return(gradnorm/gradnorm0>precision && steptaken> max(pow(precision,2),1.E-20) && iteration< max_iterations);
   return(std::isfinite(objval) && get_error() >precision && steptaken> 0.5*pow(precision,2) && iteration< max_iterations );
}
void UncOpt::print_stopping_criteria()
{
  cout<<"state: "<<state<<" | error:  "<<get_error()<<" < "<<precision  <<" | iterations:  "<< iteration<<" < "<<max_iterations<<" | steptaken: "<<steptaken<<endl;
}
// Adding prototpye to forcing linker of template solve function
//template int solve<double *>(double * x);
//template int solve<vector<double> >(vector<double>  x);
void UncOpt::print_iteration_info()
{
    if(iteration%print_title==0)
      print_iteration_header();
    if(iteration ==0)
      printf("%d\t 1.0000\t  %3.4e\t %3.4e \n",iteration ,objval, steptaken);
    else
      printf("%d\t %3.4e\t  %3.4e\t %3.4e \n",iteration, get_error() ,objval, steptaken);
}
void UncOpt::print_iteration_header()
{
    ObjFunc.print();
    cout<<name<<" Prec "<<precision<<endl;
    printf("iter\t error\t \t objval\t   step   \n");
}
double UncOpt::armijo()
{
  //! Find step length for suficient drease  f(x+step_length d) < f(x) + step_length d grad
    if(Deriv.Gradient ==NULL)
    {
        cout<<"must calculate gradient before armijo!!"<<endl;
        return 1;
    }
    double changeddir =0;
    double objval = ObjFunc.eval(x,dimension);
    double upper = 1;
    double future = 2;
    double armijocondition = 1E-5;
    double stepsize_ = initial_stepsize*2;
    double inprod;
    while(future>upper)
    {
        stepsize_ = stepsize_/2;
       // cout<<"stepsize_: "<<stepsize_<<endl;
        //f(x) + stepsize* d.grad
        inprod = LinAlg.inner_prod(Deriv.Gradient,descent, dimension);
       //       cout<<"inprod: "<<inprod<<endl;
        if(inprod >0 && changeddir==0)
        {
     //       cout<<"Not a descent direction, changing direction"<<endl;
	    stepsize_= -initial_stepsize;
            changeddir = 1;
            //return(stepsize);
        }
        LinAlg.copyvec(temp_use,descent,dimension);
// d*stepsize
        LinAlg.mult_scalar(temp_use,dimension,stepsize_);
// x+ d*stepsize
        LinAlg.sum(temp_use,x,dimension);
//f(x+d*stepsize)
        future = ObjFunc.eval(temp_use,dimension);

        upper= objval+ armijocondition*stepsize_*inprod;
    //      cout<<"f(x+d*stepsize) < f(x) + stepsize* d.grad:  "<<  future<<" < "<<upper<<endl;
    }
    return(stepsize_);
}
double UncOpt::inexact_solve_precision(const double & rhs){
//! Calculates system solve precision based on rhs and gradient
  if(system_precision ==0) // Gunderson & Steihaug
    return(min(0.99*(LinAlg.norm(Deriv.Gradient,dimension)),0.1));
  else if(system_precision ==1)
    return(0.5* (LinAlg.norm(&rhs,dimension)));
  else
    return(system_precision);
}
