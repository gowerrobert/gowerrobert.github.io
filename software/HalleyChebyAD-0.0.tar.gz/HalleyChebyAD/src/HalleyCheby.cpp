#include "HalleyCheby.h"
/** Halley Chebyshev descent method, inherits from UncOpt class**/
HalleyCheby::HalleyCheby(const int dimension_int, const double precision_in, const bool print_it, const double lambda_in):
    UncOpt(dimension_int, precision_in, "HalleyCheby", print_it),
    lambda(lambda_in)
{
   ostringstream strs;
   strs << lambda;
   string str = strs.str();
   name = "HalleyCheby"+str;
  newtdir = new double [dimension];
}
HalleyCheby::~HalleyCheby()
{
  delete [] newtdir;
}
void HalleyCheby::set_lambda(int lambda_in)
{
    lambda = lambda_in;
    ostringstream strs;
    strs << lambda;
    string str = strs.str();
    name = "HalleyCheby"+str;
}
/*int HalleyCheby::methodstep_alt()
{
    int system_output;
    bool temp_print_shit=0;
    Deriv.eval_2nd_order(x);//Calculate derivative info
    if(temp_print_shit)
    {
        cout<<"grad"<<endl;
        LinAlg.print_array(Deriv.Gradient,dimension);
    }
   LinAlg.copyvec(temp_use, Deriv.Gradient,dimension);  //Making a copy of the Gradient
   LinAlg.mult_scalar(temp_use, dimension, -1.0); // temp_use = - grad
    if(temp_print_shit)
    {
        cout<<"-grad"<<endl;
        LinAlg.print_array(temp_use,dimension);
    }
    system_output = LinAlg.solvesystem(max_system_iter, Deriv.HessianGraph,newtdir, temp_use,precision, print_system_iteration_info_active); //Calculating the Newton Direction, saving into newtdir
    if(temp_print_shit)
    {
        cout<<"Newtondir"<<endl;
        LinAlg.print_array(newtdir,dimension);
    }
   Deriv.eval_3rd_order(x,newtdir);  // Calculating the directional derivative of Hessian in the Newton direction
    if(temp_print_shit)
    {
        cout<<"Tensnd"<<endl;
        Deriv.TensorVectorGraph->print();
    }
    // Building system (H + (1-\lambda)/2Tn)d = -g -\lambda/2 Tnn
    Deriv.TensorVectorGraph->vector_mult(newtdir,temp_use); // temp_use = Tnd . nd
    if(temp_print_shit)
    {
        cout<<"Tndnd"<<endl;
        LinAlg.print_array(temp_use,dimension);
    }
    LinAlg.mult_scalar(temp_use, dimension, -lambda/(2.0));     // temp_use = -lambda/2 Tnd .nd
    if(temp_print_shit)
    {
        cout<<"-lambda/2 Tnd ."<<endl;
        LinAlg.print_array(temp_use,dimension);
    }
    LinAlg.copyvec(descent, Deriv.Gradient,dimension);
    LinAlg.mult_scalar(descent, dimension, -1.0);     // dsecent = - grad
    if(temp_print_shit)
    {
        cout<<"-grad"<<endl;
        LinAlg.print_array(descent,dimension);
    }
    LinAlg.sum(temp_use , descent , dimension);     // temp_use = -grad-lambda/2 Tnd nd
    if(temp_print_shit)
    {
        cout<<"-grad-lambda/2 Tnd nd"<<endl;
        LinAlg.print_array(temp_use,dimension);
    }
    (*(Deriv.TensorVectorGraph))*=((1-lambda)/2.0);     // T = (1-lambda)/2 T
    (*(Deriv.TensorVectorGraph))+=(*Deriv.HessianGraph); // T = H + (1-lambda)/2 T
    LinAlg.copyvec(descent, newtdir,dimension);
    //Solving the Halley system
    // (H + (1-lambda)/2 T) descent =
    system_output = LinAlg.solvesystem(max_system_iter, Deriv.TensorVectorGraph, descent, temp_use,precision, print_system_iteration_info_active);
    //Still have to sum the solution direction!
    return(system_output);
}
*/
int HalleyCheby::methodstep()
{
    int system_output;
    double inexact_prec;
    LinAlg.copyvec(temp_use, Deriv.Gradient,dimension);
    LinAlg.mult_scalar(temp_use, dimension, -1.0);     // temp_use = - grad
    inexact_prec = inexact_solve_precision(*temp_use); // get system solve precision based on gradient
    system_output = LinAlg.solvesystem(max_system_iter, Deriv.HessianGraph, newtdir, temp_use, inexact_prec, print_system_solve, linear_solver_type);     // Inexact   newtdir = - Deriv.HessianGraph^{-1} grad
    if(system_output ==0){ // Failed to solve system
 //     cout<<"FAILED system solve, Returning Newtons Direction"<<endl;
      LinAlg.copyvec(descent , newtdir,dimension);
      return(system_output);
    }
    Deriv.eval_3rd_order(x,newtdir);
    //*** Setting up system (H + (1-\lambda)/2Tn)d = -g -\lambda/2 Tnn      **//
    Deriv.TensorVectorGraph->vector_mult(newtdir, temp_use);      // temp_use = Tnd . nd
    LinAlg.mult_scalar(temp_use, dimension, -1.0/(2.0));     // temp_use = -1/2 Tnd .nd
    (*(Deriv.TensorVectorGraph))*=((1-lambda)/2.0);      // T = (1-lambda)/2 T
    (*(Deriv.TensorVectorGraph))+=(*Deriv.HessianGraph);      // T = H + (1-lambda)/2 T
    LinAlg.copyvec(descent, newtdir,dimension);
    inexact_prec = inexact_solve_precision(*temp_use);  // get system solve precision based on rhs
    //*** Solving the Halley system (H + (1-lambda)/2 T) descent =   -1/2 Tnd .nd **//
    system_output = LinAlg.solvesystem(max_system_iter, Deriv.TensorVectorGraph, descent, temp_use,inexact_prec, print_system_solve, linear_solver_type);
    LinAlg.sum(descent,newtdir,dimension); // Summing Newtondir and HalleyCheby correction
    return(system_output);
}
