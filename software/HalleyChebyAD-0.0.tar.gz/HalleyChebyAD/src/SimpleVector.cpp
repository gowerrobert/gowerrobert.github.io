// tminres is free software; you can redistribute it and/or modify it under the
// terms of the GNU Lesser General Public License (as published by the Free
// Software Foundation) version 2.1 dated February 1999.
//
// Authors:
// - Umberto Villa, Emory University - uvilla@emory.edu
// - Michael Saunders, Stanford University
// - Santiago Akle, Stanford University

/*!
@file
@author U. Villa - uvilla@emory.edu
@date 04/2012
*/

#include "SimpleVector.hpp"
#include <cassert>
#include <algorithm>
#include <cmath>
#include <cstdlib>

SimpleVector::SimpleVector(int length_):
	length(length_)
{
	assert(length > 0);
	data = new double[length];
	std::fill(data,data+length,0);
}

SimpleVector::~SimpleVector()
{
   // std::cout<<"Deleting SVector"<<std::endl;
	delete[] data;
}
SimpleVector::SimpleVector(const SimpleVector& other): length(other.length), data( new double [other.length])
{
  //std::cout<<"COPY CONSTRUCTOR CALL!"<<std::endl;
  std::copy(other.data, other.data + length, data); //copy ctor
}

SimpleVector & SimpleVector::operator=(const double & val)
{
	std::fill(data, data+length, val);
	return *this;
}
// Set the entry of the Vector equal to the entries in RHS
SimpleVector & SimpleVector::operator=(const SimpleVector & RHS)
{
	std::copy(RHS.data, RHS.data + RHS.length, data);
	return *this;
}

// multiply THIS by a scalar value
void SimpleVector::Scale(const double & val)
{
	for( double * it(data); it != data + length; ++it)
		(*it) *= val;
}
// Create a new vector with the same structure of THIS. Values are not initialized.
SimpleVector * SimpleVector::Clone()
{
	return new SimpleVector(length);
}

// Copies entries of THIS into dcopy
void SimpleVector::ToDouble(double * dcopy){
	//for( int i =0; i<length; i++)
    //    dcopy[it] = data[i]
    std::copy(data, data + length, dcopy);
}
// Copies entries of source into THIS
void SimpleVector::CopyDouble(const double * source){
   std::copy(source, source + length, data);
}

double & SimpleVector::operator[](const int i)
{
	assert( i < length);
	return data[i];
}
const double & SimpleVector::operator[](const int i) const
{
	assert( i < length );
	return data[i];
}

const double SimpleVector::at(const int i) const
{

	if (i<0 || i > length-1)
		return 0.0;

	return data[i];
}

void SimpleVector::Randomize(int seed)
{
	srand(seed);
	for( double * it(data); it != data + length; ++it)
		(*it) = 2.*static_cast<double>(rand())/static_cast<double>(RAND_MAX) - 1.;

	double norm2( InnerProduct(*this, *this) );
	Scale(1./sqrt(norm2));

}

void SimpleVector::Print(std::ostream & os) const
{
	for(double *it(data); it != data+length; ++it)
		os << *it << "\t ";

	os << "\n";
}
void SimpleVector::Print() const
{
	for(double *it(data); it != data+length; ++it)
		std::cout << *it << "\t ";

	std::cout << "\n";
}

// result = v1 + c2*v2
void add(const SimpleVector & v1, const double & c2, const SimpleVector & v2, SimpleVector & result)
{
	int length(result.length);
	double * rr(result.data);
	double * vv1(v1.data);
	double * vv2(v2.data);

	assert( v1.length == v2.length );
	assert( length == v1.length );

	double * end(rr + length);

	for( ; rr != end; ++rr, ++vv1, ++vv2)
		(*rr) = (*vv1) + c2*(*vv2);
}
// result = c1*v1 + c2*v2
void add(const double & c1, const SimpleVector & v1, const double & c2, const SimpleVector & v2, SimpleVector & result)
{
	int length(result.length);
	double * rr(result.data);
	double * vv1(v1.data);
	double * vv2(v2.data);

	assert( v1.length == v2.length );
	assert( length == v1.length );

	double * end(rr + length);

	for( ; rr != end; ++rr, ++vv1, ++vv2)
		(*rr) = c1*(*vv1) + c2*(*vv2);
}

// result = alpha(v1 + v2)
void add(const double & alpha, const SimpleVector & v1, const SimpleVector & v2, SimpleVector & result)
{
	int length(result.length);
	double * rr(result.data);
	double * vv1(v1.data);
	double * vv2(v2.data);

	assert( v1.length == v2.length );
	assert( length == v1.length );

	double * end(rr + length);

	for( ; rr != end; ++rr, ++vv1, ++vv2)
		(*rr) = alpha*(*vv1 +*vv2);

}

// result = v1 + v2 + v3
void add(const SimpleVector & v1, const SimpleVector & v2, const SimpleVector & v3, SimpleVector & result)
{
	int length(result.length);
	double * rr(result.data);
	double * vv1(v1.data);
	double * vv2(v2.data);
	double * vv3(v3.data);

	assert( v1.length == v2.length );
	assert( v2.length == v3.length );
	assert( length == v1.length );

	double * end(rr + length);

	for( ; rr != end; ++rr, ++vv1, ++vv2, ++vv3)
		(*rr) = (*vv1) + (*vv2) + (*vv3);

}
// result = v1 - v2
void subtract(const SimpleVector & v1, const SimpleVector & v2, SimpleVector & result)
{
	int length(result.length);
	double * rr(result.data);
	double * vv1(v1.data);
	double * vv2(v2.data);

	assert( v1.length == v2.length );
	assert( length == v1.length );

	double * end(rr + length);

	for( ; rr != end; ++rr, ++vv1, ++vv2)
		(*rr) = *vv1  - *vv2;


}

// return the inner product of v1 and v2
double InnerProduct(const SimpleVector & v1, const SimpleVector & v2)
{
	double result(0);
	int length(v1.length);
	double * vv1(v1.data);
	double * vv2(v2.data);

	assert( v1.length == v2.length );

	double * end(vv1 + length);

	for( ; vv1 != end; ++vv1, ++vv2)
		result += (*vv1) * (*vv2);

	return result;

}

double Norm(const SimpleVector & v1){
  return( sqrt(InnerProduct(v1,v1)));

}

