#include <iostream>
#include <numeric>      // std::inner_product
#include "ConjugateGradients.h"

template<class Vector> ConjugateGradients<Vector>::ConjugateGradients(const int _max_iterations, const double _tol, const Vector &Ax,  const Vector &_x,const Vector &_b, Vector &p, bool print_system_solve):
iterations(int(0)),max_iterations(_max_iterations), tol(_tol), resid(0), x(_x), state(NOT_FINISHED), print_multiple(15),
print_count(0), print_on(print_system_solve), r(_b), b(_b),   temp(_b)//, EnumStrings({"REACHED_MAX_ITER", "BELOW_TOLERANCE", "NOT_FINISHED"})
{
  EnumStrings[0] = "BELOW_TOLERANCE"; EnumStrings[1] = "REACHED_MAX_ITER"; EnumStrings[2] = "NOT_FINISHED"; EnumStrings[3] = "NEGATIVE_CURVATURE"; EnumStrings[4] = "ZERO_CURVATURE";
  r=0;
  add(r,1,b,r);  //r= b
  subtract(r,Ax,r); //r=b-Ax
  p=r;
  normr0 = Norm(r);
 /* cout<<"Ax :";
  Ax.Print();
  cout<<"b :";
  b.Print();
  cout<<"r :";
  r.Print();
  cout<<"p :";
  p.Print(); //*/
  //double normb = Norm(b);

//   resid = Norm(r);
//   if (resid <= tol)
//     state = BELOW_TOLERANCE;
//   else if (max_iterations <= 0)
//     state =REACHED_MAX_ITER;
if (max_iterations <= 0)
       state =REACHED_MAX_ITER;
state = NOT_FINISHED;
}
template<class Vector> ConjugateGradients<Vector>::~ConjugateGradients(){
//Should I delete x and p?
}

template<class Vector> int ConjugateGradients<Vector>::step(Vector &Ap, Vector &p){
double curv = InnerProduct(p,Ap);
/*cout<<"STEP"<<endl; 
cout<<"p "; p.Print();
cout<<"r "; r   .Print();
cout<<"curv: "<<curv<<endl; //*/
if(curv <=0){
  state = NEGATIVE_CURVATURE;
 // cout<<"Ap "; Ap.Print();
  // Adding scaled first search direction to x
 // cout<<"NEGATIVE_CURVATURE:  "<<curv<<endl;
 // add(x,1,p,x);
  return(-1);
}
bool print_shit =1;
double alpha, beta, rho;

if(state ==NOT_FINISHED){
     iterations++;
     rho = InnerProduct(r,r);
     alpha = rho/curv;
     Ap.Scale(alpha);        		 // Ap = alpha Ap
     add(x,alpha,p,x);         		// x = x+alpha p
     subtract(r,Ap,r);           		//r =r-alpha Ap;
     beta= InnerProduct(r,r)/rho;	// beta = InnerProduct(r,Ap)/curv;
     add(p,beta,r,p);   		//p = r +beta p;
     resid = Norm(r) / normr0;
 }
 
 if (resid <= tol)
   state= BELOW_TOLERANCE;
 else if (iterations==max_iterations-1)
   state = REACHED_MAX_ITER;
 if(print_on)
    print();
 return state;
}
template<class Vector> void ConjugateGradients<Vector>::print(){
  if(print_count==0)
    cout<<"iter	"<<"resid	"<<"state"<<endl;
  cout<<iterations<<"	"<<resid<<"	"<<getTextForEnum(state)<<endl;
}
template<class Vector>  void ConjugateGradients<Vector>::activate_printing(bool b){
print_on =b;
}
template class ConjugateGradients<SimpleVector>;
// int  CG(const Graph &A, Vector &x, const Vector &b, int &max_iter, double &tol)
// {
//   /*
//   Make the matrix-vector product external, much like MKL
//   Overload the operation Graph*Vector
//   */
//   double resid;
//   Vector p, z, q;
//   Vector alpha(1), beta(1), rho(1), rho_1(1);
//
//   double normb = norm(b);
//   Vector r = b - A*x;
//
//   if (normb == 0.0)
//     normb = 1;
//
//   if ((resid = norm(r) / normb) <= tol) {
//     tol = resid;
//     max_iter = 0;
//     return 0;
//   }
//
//   for (int i = 1; i <= max_iter; i++) {
//     //  z = M.solve(r);  //   rho(0) = dot(r, z);
//     rho(0) = dot(r,r); //inner_product(r,r+r.size(),r,0);
//     if (i == 1)
//       p = r;
//     else {
//       beta(0) = rho(0) / rho_1(0);
//       p = r + beta(0) * p;
//     }
//
//     q = A*p;
//     alpha(0) = rho(0) / dot(p, q);
//
//     x += alpha(0) * p;
//     r -= alpha(0) * q;
//
//     if ((resid = norm(r) / normb) <= tol) {
//       tol = resid;
//       max_iter = i;
//       return 0;
//     }
//
//     rho_1(0) = rho(0);
//   }
//
//   tol = resid;
//   return 1;
// }
