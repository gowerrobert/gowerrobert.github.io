#include "ObjectiveFunction.h"
#include "setup_functions.h"
#include "LinAlgebra.h"
ObjectiveFunction::ObjectiveFunction(const  int dimension_in):
    dimension(dimension_in),
   // name("function_eval"),
    eval(function_eval<double>),
    eval_a(function_eval<adouble>)
    {
  //   cout<<"ObjectiveFunction constructor"<<endl;
    x_initial = new double [dimension];
    std::fill(x_initial,x_initial+dimension,0);
}
// CHANGE: Pass a const reference for point: const double & x_initial_in
ObjectiveFunction::ObjectiveFunction(const int dimension_in,  double * x_initial_in,   double (*eval_in)(const double * , const int ),
adouble (*eval_a_in)(const adouble * , const int ) , const string name_in):
dimension(dimension_in),
name(name_in),
eval(eval_in),
eval_a(eval_a_in)
{
  //   cout<<"ObjectiveFunction constructor elaborate"<<endl;
  x_initial = new double [dimension];
  std::copy(x_initial_in, x_initial_in + dimension, x_initial);
}
//
ObjectiveFunction::ObjectiveFunction( const ObjectiveFunction & rhs):
dimension(rhs.dimension),
name(rhs.name),
eval(rhs.eval),
eval_a(rhs.eval_a)
{ /** Copy constructor*/
// cout<<"ObjectiveFunction Copy constructor"<<endl;
x_initial = new double [dimension];
std::copy(rhs.x_initial, rhs.x_initial + dimension, x_initial);
}
void ObjectiveFunction::swap(ObjectiveFunction& first, ObjectiveFunction& second){
  /** Swaps all fields of the ObjectiveFunctions*/
  using std::swap;
  swap(first.eval, second.eval);
  swap(first.eval_a, second.eval_a);
  swap(first.x_initial, second.x_initial);
  swap(first.name, second.name);
  swap(first.dimension, second.dimension);
}
ObjectiveFunction& ObjectiveFunction::operator=(ObjectiveFunction rhs){
  //! Copy Assignment using swap-copy
  swap(*this, rhs);
  return *this;
}
ObjectiveFunction::~ObjectiveFunction()
{
  delete [] x_initial;
}
void ObjectiveFunction::set_x_initial(void (*initial_pointpty)(double *,const int dim)){
  initial_pointpty(x_initial,dimension);
}
double ObjectiveFunction::tape_it(const double * x, const short int tape_num)
{   //! tapes the trace of the function eval_a  with input double * x.
int i;
double out;
adouble * xa;
xa = new adouble [dimension];
trace_on(tape_num);
adouble outa;
for(i=0; i<dimension; i++)
  xa[i] <<= x[i];	// active independs        //
  outa = eval_a(xa, dimension);
outa >>= out;
trace_off();
delete[] xa;
return(out);
}
void ObjectiveFunction::print() const
{
  LinAlgebra sup;
  std::cout<<"ObjFunc:";
  std::cout<<name<<" "<<dimension<<endl;
 // cout<<"initial point"<<endl;
 // sup.print_array(x_initial,dimension);
}
