#include "setup_functions.h"


template <class indep_var>  indep_var nondquar(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=1;
    indep_var fi=0;
    /*---------------------------------------------------------------------------------*/

//   Source: problem 57 in... name: nondquar
//   A.R. Conn, N.I.M. Gould, M. Lescrenier and Ph.L. Toint,
//   "Performance of a multi-frontal scheme for partially separable
//   optimization"
//   Report 88/4, Dept of Mathematics, FUNDP (Namur, B), 1988.

//   SIF input: Ph. Toint, Dec 1989
    for(i=0; i<n-1; i++)
        fad = fad + pow(x[i]+x[i+1]+x[n-1],4);
    fad = fad + pow(x[1]-x[2],2)+pow(x[n-1]+x[n-2],2);
    return(fad);
}


template double nondquar<double>(const double  *x, const int n);
template adouble nondquar<adouble>(const adouble  *x, const int n);
void nondquar_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++)
    {
        if(i%2==0)
            x_initial[i] =-1;
        else
            x_initial[i] =1;
    }
}