#include "setup_functions.h"


template <class indep_var>  indep_var morebv(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=1;
    indep_var fi=0;
    /*---------------------------------------------------------------------------------*/
    /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
    /*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
    /*
    morebv
    #   Source:  problem 28 in
    #   J.J. More', B.S. Garbow and K.E. Hillstrom,
    #   "Testing Unconstrained Optimization Software",
    #   ACM Transactions on Mathematical Software, vol. 7(1), pp. 17-41, 1981.

    */
    double h = 1/((double)n+1.0);

    for(i=1; i<n-1; i++)
        fad = fad + pow(2.0*x[i]-x[i-1]-x[i+1]+pow(h,2.0)*pow((x[i]+i*h+1.0),3)*0.5 ,2.0);
//for(i=1; i<n; i++)
//        fad = fad + pow(2.0*x[i]-x[i-1]+pow(h,2.0)*pow((x[i]+i*h+1.0),3)*0.5 ,2.0);

    return(fad);
}


template double morebv<double>(const double  *x, const int n);
template adouble morebv<adouble>(const adouble  *x, const int n);
void morebv_initial_point ( double *x_initial, const int dimension){
    double h;
    for(int i=0; i<dimension ; i++){
           h =  (double(i)/double(dimension+1.0));
	   x_initial[i] =h*(h-1);
    }
    x_initial[dimension-1] =0.0;
}
