#include "setup_functions.h"

template <class indep_var>  indep_var feval_ad(const indep_var *x, int N_)
{
    // return the value of the objective function
    indep_var obj_value = 0.;
    indep_var a1, a2;

    for (int i=0; i<N_-1; i++)
    {
        a1 = x[i]*x[i]-x[i+1];
        a2 = x[i] - 1.;
        obj_value =obj_value+ 100.*a1*a1 + a2*a2;
    }

    return obj_value;
}

/***************************************************************************/

template <class indep_var>  indep_var ceval_ad(const indep_var *x, int N_, int i)
{

//     for (int i=0; i<N_-2; i++)
//     {
        return( 3.*pow(x[i+1],3.) + 2.*x[i+2] - 5.
               + sin(x[i+1]-x[i+2])*sin(x[i+1]+x[i+2]) + 4.*x[i+1]
               - x[i]*exp(x[i]-x[i+1]) - 3.);
//     }
}
template <class indep_var>  indep_var chainros_trigexp(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=1;
    indep_var fi=0;
    indep_var  c;
    /*---------------------------------------------------------------------------------*/
    /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
    /*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

//Name: Chained Rosenbrook function with Trigonometric and exponencial constraints.
    /* Problem 5.1 of
    Ladislav Luksan, Jan Vlcek:
    Sparse and partially separable test problems for unconstrained and equality constrained optimization.
    Tech. Rep. V-767, ICS AS CR, December 1998
    //*/
//3-5 D
    int N_ = n/2;
    int M_ = N_ -2;
    fad = feval_ad(x, N_);
    for(i=0; i<M_; i++)
      fad = fad + ceval_ad(x,  N_,  i)*ceval_ad(x,  N_,  i);
     // fad = fad + x[N_+i]*ceval_ad(x,  N_,  i);
    return(fad);
}


template double chainros_trigexp<double>(const double  *x, const int n);
template adouble chainros_trigexp<adouble>(const adouble  *x, const int n);
void chainros_trigexp_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++)
    {
        if(i%2==0)
            x_initial[i] =1;
        else
            x_initial[i] = -1.2;
    }
}