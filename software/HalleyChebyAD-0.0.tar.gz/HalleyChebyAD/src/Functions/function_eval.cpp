#include "setup_functions.h"
template <class indep_var>  indep_var function_eval(const indep_var * x, const int n){
  int  i, j;
  indep_var fad=1;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

for(i=0; i<n-1; i++)
  fad = fad + pow(log(pow(x[i],2)+1),4)*pow(log(pow(x[i+1],2)+1),4);
    return fad;
}//*/
template double function_eval<double>(const double  *x, const int n);
template adouble function_eval<adouble>(const adouble  *x, const int n);

void function_eval_initial_point ( double *x_initial, const int dimension){
/* CHOOSE INITIAL POINT HERE!!! *******************************/
    for(int i=0; i<dimension ; i++) x_initial[i] =2.0;
/*************************************************************/
}