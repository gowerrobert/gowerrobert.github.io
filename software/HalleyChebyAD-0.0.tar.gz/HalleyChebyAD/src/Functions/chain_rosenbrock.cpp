
#include "setup_functions.h"
template <class indep_var> indep_var chain_rosenbrock(const indep_var * x, const int n){
  int  i, j;
  indep_var fad=1;
  indep_var fi=0;
  /*---------------------------------------------------------------------------------*/
  //  The Chained RosenBrock Function
  // Toint, B. P. L. (1978). Some Numerical Results Using a Sparse Matrix, 32(143), 839–851.
  for(i=1; i<n-1; i++)
    fad = fad +6.4*pow(x[i-1] - pow(x[i],2),2) + pow(1-x[i],2);


  return(fad);
}

template double chain_rosenbrock<double>(const double  *x, const int n);
template adouble chain_rosenbrock<adouble>(const adouble  *x, const int n);
void chain_rosenbrock_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =0.0;
}