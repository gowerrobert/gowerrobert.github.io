#include "setup_functions.h"


template <class indep_var> indep_var bc4(const indep_var * x, const int n){
  int  i;
  indep_var fad=1;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
//Brachistochrone Problem NAME: bc4, princeton noncute
//fad =1;
double param_subtract;
for(i=1;i<n;i++){
  param_subtract = pow(double(i)/double(n),4)-pow(double(i-1)/double(n),4);
  fad = fad +  sqrt( (1+pow((x[i] - x[i-1])/(param_subtract),2))/x[i-1] )*(param_subtract);
}
    
fad = fad+ pow(x[0]-1.0E-12,2) + pow(x[n-1]-1,2);

/* Old version, with extra allocation

indep_var * dydx;
dydx = new indep_var [n];
for(i=0;i<n;i++)
param[i] = pow(double(i)/double(n),4);
for(i=1;i<n;i++)
dydx[i] = (x[i] - x[i-1])/(param[i] - param[i-1]);
for(i=1;i<n;i++)
fad = fad +  sqrt( (1+pow(dydx[i],2))/x[i-1] )*(param[i]-param[i-1]);
fad = fad+ pow(x[0]-1.0E-12,2) + pow(x[n-1]-1,2);
delete [] indep_var
delete [] param;
*/

return(fad);
}

template double bc4<double>(const double  *x, const int n);
template adouble bc4<adouble>(const adouble  *x, const int n);
void bc4_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =double(i)/double(dimension);
    x_initial[0] =  1.0E-12;
    x_initial[dimension-1] = 1;
}