#include "setup_functions.h"


template <class indep_var> indep_var bdexp(const indep_var * x, const int n){
  int  i;
  indep_var fad=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
/*A banded exponential problem.
10
11	*   Source: Problem 56 in
12	*   A.R. Conn, N.I.M. Gould, M. Lescrenier and Ph.L. Toint,
13	*   "Performance of a multifrontal scheme for partially separable
14	*   optimization",
15	*   Report 88/4, Dept of Mathematics, FUNDP (Namur, B), 1988.*/
//3-5 D
    int ngs = n-2;

    /** This function is unbounded below for x_i -> + infty ?*/
   for(i=0; i<ngs; i++)
	 fad = fad + (x[i]+x[i+1])*exp((x[i]+x[i+1])*(-x[i+2]));

    return(fad);
}


template double bdexp<double>(const double  *x, const int n);
template adouble bdexp<adouble>(const adouble  *x, const int n);
void bdexp_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =1;
}