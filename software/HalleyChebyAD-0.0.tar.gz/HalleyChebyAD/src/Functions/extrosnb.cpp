#include "setup_functions.h"


template <class indep_var> indep_var extrosnb(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=1;
    indep_var fi=0;
    /*---------------------------------------------------------------------------------*/
//	#   Source: problem 10 in
//13	#   Ph.L. Toint,
//14	#   "Test problems for partially separable optimization and results
//15	#   for the routine PSPMIN",
//16	#   Report 83/4, Department of Mathematics, FUNDP (Namur, B), 1983.
//17
//18	#   See also Buckley#116.  Note that MGH#21 is the separable version.
//19	#   SIF input: Ph. Toint, Dec 1989.
//20
//21	#   classification SUR2-AN-V-0

    fad =    pow((x[0]-1),2);
    for (i=1; i<n; i++)
        fad = fad + 100*pow(x[i]-pow(x[i-1],2),2);
    return(fad);

}
template double extrosnb<double>(const double  *x, const int n);
template adouble extrosnb<adouble>(const adouble  *x, const int n);

void extrosnb_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++)
        if(i%2)
            x_initial[i] =-1.2;
        else
            x_initial[i] = 1;
}