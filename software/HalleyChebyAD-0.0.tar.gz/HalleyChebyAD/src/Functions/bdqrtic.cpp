#include "setup_functions.h"


template <class indep_var> indep_var bdqrtic(const indep_var * x, const int n){
  int  i, j;
  indep_var fad=1;
  indep_var fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

//minimize f:
//NAME: bdqrtic from cute
//arrow + 3-7 D
/*
From Performance of a multifrontal scheme
problem 61
*/
   for(i=0; i<n-4; i++)
        fad = fad + pow(-4*x[i]+3.0,2)
              +pow((pow(x[i],2)+2*pow(x[i+1],2)
	      +3*pow(x[i+2],2)+4*pow(x[i+3],2)
	      +5*pow(x[n-1],2)),2);
    return(fad);
}


template double bdqrtic<double>(const double  *x, const int n);
template adouble bdqrtic<adouble>(const adouble  *x, const int n);
void bdqrtic_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =1;
}