
#include "setup_functions.h"
template <class indep_var> indep_var rosenbrock(const indep_var * x, const int n){
  int  i, j;
  indep_var fad=1;
  indep_var fi=0;
  /*---------------------------------------------------------------------------------*/
  //  The Generalized RosenBrock Function

  for(i=0; i<n-1; i++)
    fad = fad +100*pow(x[n-1] - pow(x[i],2),2) + pow(1-x[i],2);


  return(fad);
}

template double rosenbrock<double>(const double  *x, const int n);
template adouble rosenbrock<adouble>(const adouble  *x, const int n);
void rosenbrock_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =0.0;
}