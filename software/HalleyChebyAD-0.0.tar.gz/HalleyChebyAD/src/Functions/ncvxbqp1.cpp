#include "setup_functions.h"


template <class indep_var>  indep_var ncvxbqp1(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=1;
    indep_var fi=0;
    /*---------------------------------------------------------------------------------*/
    /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
    /*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
//Name: ncvxbqp1
//** https://projects.coin-or.org/Coopr/browser/coopr.pyomo/trunk/coopr/pyomo/tests/NL/CUTE/ncvxbqp1_cute.py?rev=2882 **/
// AMPL Model by Hande Y. Benson
// Copyright (C) 2001 Princeton University
//param N:=10000;  <--- large domain
    int N =n;
//    int M =N/2;
    int NPLUS = N/4;

    for(i=0; i<NPLUS; i++)
        fad =fad+ 0.5*i*pow((x[i]+x[(2*i-1) % N ] +x[(3*i-1) % N ]),2);
    for(i=NPLUS; i<n; i++)
        fad = fad - 0.5*i*pow((x[i]+x[(2*i-1) % N] +x[(3*i-1) % N]),2) ;
    return(fad);
}

template double ncvxbqp1<double>(const double  *x, const int n);
template adouble ncvxbqp1<adouble>(const adouble  *x, const int n);
void ncvxbqp1_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =0.5;
}