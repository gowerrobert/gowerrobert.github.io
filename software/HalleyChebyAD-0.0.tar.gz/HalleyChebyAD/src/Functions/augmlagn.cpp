#include "setup_functions.h"


template <class indep_var> indep_var augmlagn(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=1;
    indep_var fi=0;
    /*---------------------------------------------------------------------------------*/
    /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
    /*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

    /*
    An augmented Lagragian for a generalizaed hock and schittkowski
    80-th problem   name: AUGMLAGN
     Test examples for nonlinear programming codes
    Journal	Journal of Optimization Theory and Applications
    W. Hock1 and K. Schittkowski1
    i = 5, 10 ,15, 20...
    */
//THIS IS A TRIANGULAR MATRIX!
    double lambda1, lambda2, lambda3, p;
    lambda1 = -0.002008;
    lambda2 = -0.001900;
    lambda3 = -0.000261;
    p =20;
    fi=0;
    for(i=1; i<n-4; i=i+5)
    {
        fad = fad+ exp(x[i]*x[i+1]*x[i+2]*x[i+3]*x[i+4]);
        fi=0;
        for(j=0; j<5; j++)
            fi = fi+ pow(x[i+j],2) -10 -lambda1;
        fad = fad + pow(fi,2)+
              pow(x[i+1]*x[i+2] - 5*x[i+3]*x[i+4] - lambda2,2) +
              pow( pow(x[i],3) + pow(x[i+1],3) +1 -lambda3, 2) +
              exp(x[i]*x[i+1]*x[i+2]*x[i+3]*x[i+4]);
        //+0.5*p*()
    }
    return(fad);
}

template double augmlagn<double>(const double  *x, const int n);
template adouble augmlagn<adouble>(const adouble  *x, const int n);
void augmlagn_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++)
    {
        switch(i%5)
        {
        case 0:
            x_initial[i] =-2;
            break;
        case 1:
            x_initial[i] = 2;
            break;
        case 2:
            x_initial[i] = 2;
            break;
        case 3:
            x_initial[i] =-1;
            break;
        case 4:
            x_initial[i] =-1;
            break;
        default:
            break;
        }
    }
}