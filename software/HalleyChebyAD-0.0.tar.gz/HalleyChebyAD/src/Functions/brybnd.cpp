#include "setup_functions.h"


template <class indep_var> indep_var brybnd(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=1;
    indep_var fi=0;
    /*---------------------------------------------------------------------------------*/
    /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
    /*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
//B r o y d e n  b a n d e d  f u n c t i o n as in:   name:
//Testing unconstrained optimization software.
//As a minimun squared sum : name: brybnd
    // fi = 0;
    if(n<7)
    {
        cout<<"dimension must be bigger then 7!!"<<endl;
        return(fad);
    }
    fad =0;
    for(i=1; i<7; i++)
    {
        fi = x[i-1]*(2+5*x[i-1])+ 1;
        for(j=1; j<i+1; j++)
            fi = fi + x[j-1]*(1+x[j-1]);
        fad = fad +fi*fi;
        fi=0;
    }

    for(i=7; i<n; i++)
    {
        fi = x[i-1]*(2+5*x[i-1])+ 1;
        for(j=i-5; j<=i+1; j++)
            fi = fi + x[j-1]*(1+x[j-1]);
        fad = fad+ fi*fi;
        fi=0;
    }

    fi = x[n-1]*(2+5*x[n-1])+ 1;
    for(j=n-5; j<=n; j++)
        fi = fi + x[j-1]*(1+x[j-1]);
    fad = fad+ fi*fi;

    return(fad);
}
template double brybnd<double>(const double  *x, const int n);
template adouble brybnd<adouble>(const adouble  *x, const int n);
void brybnd_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++)
        x_initial[i] =-1;
}