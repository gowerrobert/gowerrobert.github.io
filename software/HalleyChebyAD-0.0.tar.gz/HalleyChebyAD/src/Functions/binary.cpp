#include "setup_functions.h"

template <class indep_var> indep_var binary_inter(const indep_var * x, const int n, int left, int right);

template <class indep_var> indep_var binary(const indep_var * x, const int n){
  int  i, j;
  indep_var fad=1;

  if(n%4 != 0)
    cout<<"Calling binary function with n not even divisible by 4!"<<endl;
  /*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
/*
binary example
*/
   fad= binary_inter( x,  n, 0, n);

    return(fad);
}

template <class indep_var> indep_var binary_inter(const indep_var * x, const int n, int left, int right){
  indep_var fad;
  if(right-left>4){
       fad= binary_inter( x,  n, left, (left+right)/2);
       fad = fad+ binary_inter( x,  n, (left+right)/2, right);
  }
  else{
      fad =  x[left]*x[left+1]+x[left+2]*x[left+3];
  }
      return (fad);

}


template double binary<double>(const double  *x, const int n);
template adouble binary<adouble>(const adouble  *x, const int n);
void binary_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =0.5;
}
