#include "setup_functions.h"


template <class indep_var>  indep_var cragglevy(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=1;
    indep_var fi=0;

//   Source:  problem 32 in
//   Ph. L. Toint,
//   "Test problems for partially separable optimization and results
//   for the routine PSPMIN",
//   Report 83/4, Department of Mathematics, FUNDP (Namur, B), 1983.

//   See  also Buckley#18
//   SIF input: Ph. Toint, Dec 1989.
//Very unstable numerically
//cragg and levy function  name: CRAGGLEVY
    /*
    Have to get in library
    Study on a supermemory gradient method for the minimization of functions
    Jornal of optimization theory and applications. 191-205
    */
    for(i=1; i<n/2 -1; i++)
    {
        fad = fad+ pow((exp(x[2*i-1])-x[2*i]),4.0) +
              100.0*pow(x[2*i]-x[2*i+1],6.0) +
              pow(sin(x[2*i+1]-x[2*i+2])/cos(x[2*i+1]-x[2*i+2])+x[2*i+1]-x[2*i+2],4.0) +
              pow(x[2*i-1],8.0) +
              pow(x[2*i+2]-1.0,2.0);
    }

    return(fad);
}

template double cragglevy<double>(const double  *x, const int n);
template adouble cragglevy<adouble>(const adouble  *x, const int n);
void cragglevy_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =2;
    x_initial[0] =1;
}