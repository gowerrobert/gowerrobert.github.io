#include "setup_functions.h"
template <class indep_var> indep_var arwhead(const indep_var * x, const int n){
  int  i;
  indep_var fad=1;
  /*---------------------------------------------------------------------------------*/
  //   Source: Problem 55 in
  //   A.R. Conn, N.I.M. Gould, M. Lescrenier and Ph.L. Toint,
  //   "Performance of a multifrontal scheme for partially separable
  //   optimization",
  //   Report 88/4, Dept of Mathematics, FUNDP (Namur, B), 1988.
  //   SIF input: Ph. Toint, Dec 1989.
  //   classification OUR2-AN-V-0
  //NAME: arwhead
  fad =0;
  for(i=0; i<n-1; i++)
    fad = fad-4*x[i]+3.0+ pow((pow(x[i],2)+pow(x[n-1],2)),2);
  
  return(fad);
}

template double arwhead<double>(const double  *x, const int n);
template adouble arwhead<adouble>(const adouble  *x, const int n);
void arwhead_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =1.0;
}