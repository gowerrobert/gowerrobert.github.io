#include "setup_functions.h"
// **cosine from CUTE  */
template <class indep_var>  indep_var cosine(const indep_var * x, int n){
  int  i, j;
  indep_var fad=1;
  indep_var fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */


    fad =0;
    fi=0;
    for(i=0; i<n-1; i++)
       fad = fad+ cos(-0.5*x[i+1]+pow(x[i],2));

    return(fad);
}

template double cosine<double>(const double  *x, int n);
template adouble cosine<adouble>(const adouble  *x, int n);

void cosine_initial_point (double *x_initial, const int dimension){
std::fill(x_initial, x_initial+dimension,1.0);
}
