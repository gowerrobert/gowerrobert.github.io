#include "setup_functions.h"


template <class indep_var>  indep_var pspdoc(const indep_var * x, const int n){
  int  i, j;
  indep_var fad=1;
  indep_var fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

// Source: problem 47 in   in CUTe pspdoc
//   Ph.L. Toint,
//   "Test problems for partially separable optimization and results
//for the routine PSPMIN",
//   Report 83/4, Department of Mathematics, FUNDP (Namur, B), 1983.
int NGS = n -2;
for(i=0; i<NGS-1; i++)
    fad = fad + sqrt(pow(x[i],2)+pow((x[i+1]-x[i+2]),2)+1);

    return(fad);
}

template double pspdoc<double>(const double  *x, const int n);
template adouble pspdoc<adouble>(const adouble  *x, const int n);
void pspdoc_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =3;
}