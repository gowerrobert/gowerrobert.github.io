#include "setup_functions.h"


template <class indep_var>  indep_var lminsurf(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=0;
    /*---------------------------------------------------------------------------------*/
    /*
    lMinSurf as in:
     A Griewank and Ph. Toint,
    #   "Partitioned variable metric updates for large structured
    #   optimization problems",
    with additional quadratic penalty function based on the constraints.
    */
    int P=sqrt(n);
    int h00 = 1;
    int slopej = 4;
    int slopei = 8;

    float ston= slopei/(P-1);
    float wtoe= slopej/(P-1);
    float h01 = h00+slopej;
    float h10 = h00+slopei;

    for(i=0; i<P-1; i++)
        for(j=0; j<P-1; j++) //sqrt((P-1)^2*((x[i,j]-x[i+1,j+1])^2+(x[i+1,j]-x[i,j+1])^2)/2+1)/(P-1)^2;
            fad = fad + sqrt(pow((P-1),2)*(pow((x[i*P+j]-x[(i+1)*P+j+1]),2)+pow((x[(i+1)*P+j]-x[i*P+j+1]),2))/2+1)/pow((P-1),2);
	
	for(i=0; i<P-1; i++){
	  fad = fad +  pow(x[i*P+1] -((i-1)*ston+h00) ,2) + pow(x[i*P+P-1] -((i-1)*ston+h01) ,2) + pow(x[1*P+i] -((i-1)*wtoe+h00),2) + pow(x[(P-1)*P+i] -((j-1)*wtoe+h10) ,2) ;
	}
    return(fad);
    
    //Boundary constriants
    /* subject to cons1{j in 1..P}:
    x[1,j] = (j-1)*wtoe+h00;
    subject to cons2{j in 1..P}:
    x[P,j] = (j-1)*wtoe+h10;
    subject to cons3{i in 2..P-1}:
    x[i,P] = (i-1)*ston+h01;
    subject to cons4{i in 2..P-1}:
    x[i,1] = (i-1)*ston+h00; //*/
    /*   for(i=1; i<P-1; i++){
    x[i*P+1] = (i-1)*ston+h00;
    x[i*P+P-1] = (i-1)*ston+h01;	
    x[1*P+i] = (i-1)*wtoe+h00;
    x[(P-1)*P+i] = (j-1)*wtoe+h10;
    } //*/
}

template double lminsurf<double>(const double  *x, const int n);
template adouble lminsurf<adouble>(const adouble  *x, const int n);
void lminsurf_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =0.0;
}
