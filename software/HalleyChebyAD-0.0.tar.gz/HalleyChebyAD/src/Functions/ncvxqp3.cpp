#include "setup_functions.h"


template <class indep_var>  indep_var ncvxqp3(const indep_var * x, const int n){
  int  i, j;
  indep_var fad=1;
  indep_var fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

//name: MODIFIED ncvxqp3
// AMPL Model by Hande Y. Benson
// Copyright (C) 2001 Princeton University
// With a change to the power "2*i/2 % 5". This is to allow large scale testing. Otherwise initial point grows exponential with dimension.
int M =n/2;
int nPLUS = 3*n/4;
//minimize f:
//
//
//minimize f:
//sum {i in 1..NPLUS} (x[i]+x[(2*i-1) mod N + 1]
//+x[(3*i-1) mod N + 1])^2*i/2 -
//sum {i in NPLUS+1..N} (x[i]+x[(2*i-1) mod N + 1]
//+x[(3*i-1) mod N + 1])^2*i/2 ;
//
//subject to cons1{i in 1..M}:
//x[i]+2*x[(4*i-1) mod N + 1] + 3*x[(5*i-1) mod N + 1] = 6.0 ;

	for(i=1; i<nPLUS; i++){//cout<<"(2*i-1) % n+1  "<<((2*i-1) % (n-1)+1)<<endl;
	    fad =fad+ pow((x[i]+x[(2*i-1) % (n-1)+1 ] +x[(3*i-1) % (n-1)+1 ]), 2 )*(i/2);
	}
	for(i=nPLUS+1; i<n; i++)
	    fad = fad + pow((x[i]+x[(2*i-1) % (n-1)+1] +x[(3*i-1) % (n-1)+1]),2)*(i/2) ;
     for(i=0; i<M;i++)
        fad = fad+ 10*pow(x[i]+2*x[(4*i-1) % (n-1)+1] + 3*x[(5*i-1) % (n-1)+1] - 6.0,2);

    return(fad);
}

template double ncvxqp3<double>(const double  *x, const int n);
template adouble ncvxqp3<adouble>(const adouble  *x, const int n);
void ncvxqp3_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =0.5;
}
