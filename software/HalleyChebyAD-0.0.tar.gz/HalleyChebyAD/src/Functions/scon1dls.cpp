#include "setup_functions.h"


template <class indep_var>  indep_var scon1dls(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=1;
    indep_var fi=0;
    /*---------------------------------------------------------------------------------*/
    /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
    /*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

// Source: problem 10 in   in CUTE: scon1dls
//   J.J. More',
//   "A collection of nonlinear model problems"
//   Proceedings of the AMS-SIAM Summer seminar on the Computational
//   Solution of Nonlinear Systems of Equations, Colorado, 1988.
//   Argonne National Laboratory MCS-P60-0289, 1989.

//   SIF input: Ph. Toint, Dec 1989.

//   classification SBR2-AN-V-Vm
//% 1 to 6 diagonals, good sparsity
    double A = -0.00009;
    double B = 0.00001;

//double N = 1000;
//double LN = 900;
    int LN = (int)(((float)n)*(9.0/10.0));

    double UA = 0.0;
    double UB = 700.0;

    double CA = 1.0;
    double CB = 1.0;
    double BETA = 40.0;

    double LAMBDA = 1.0;

    double H = (B-A)/(n+1);
    double LB = LAMBDA*BETA;
    double LUA = LAMBDA*UA;
    double LUB = LAMBDA*UB;
    double ULW = LUA-5;
    double UUP = LUB+5;

//var u{i in 0..N+1} <= UUP, >= ULW, := if (i == 0) then LUA
//			else if (i==N+1) then LUB else 0.0;

//minimize f:
    for(i=1; i<LN; i++)
        fad = fad +
              pow((x[i-1]-2*x[i]+x[i+1]-pow(LAMBDA*H,2)*CA +
                   pow(LAMBDA*H,2)*CA*exp(-LB*(x[i]-LUA))),2);
    for(i=LN; i<n-1; i++)
        fad = fad+ pow((x[i-1]-2*x[i]+x[i+1]+pow(LAMBDA*H,2)*CB -
                        pow(LAMBDA*H,2)*CB*exp(LB*(x[i]-LUB))),2);

    return(fad);
}

template double scon1dls<double>(const double  *x, const int n);
template adouble scon1dls<adouble>(const adouble  *x, const int n);
void scon1dls_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =double(i);
}