#include "setup_functions.h"


template <class indep_var>  indep_var noncvxu2(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=1;
    /*---------------------------------------------------------------------------------*/
    /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
    /*  You may use all basic functions, for a complete list consult the ADOL-C manuel */


//Name: noncvxu2
//# AMPL Model by Hande Y. Benson
//#
//# Copyright (C) 2001 Princeton University
//EdgePushing super winner
    for(i=1; i<n; i++)
    {
        //cout<<"((3*i-2)%n): "<<((3*i-2)%n)<<endl;
        //cout<<"((7*i-3) % n): "<<((7*i-3) % n)<<endl;

        fad = fad + pow( (x[i] + x[((3*i-2)%n)] + x[((7*i-3) % n)]),2) +
              4*cos(x[i] + x[((3*i-2) % n)] + x[((7*i-3) % n)]) ;

    }

    return(fad);
}

template double noncvxu2<double>(const double  *x, const int n);
template adouble noncvxu2<adouble>(const adouble  *x, const int n);
void noncvxu2_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =double(i);
}
