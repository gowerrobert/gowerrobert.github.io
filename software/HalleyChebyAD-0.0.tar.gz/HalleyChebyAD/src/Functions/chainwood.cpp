#include "setup_functions.h"


template <class indep_var>  indep_var chainwood(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=1;
    indep_var fi=0;
    /*---------------------------------------------------------------------------------*/
    /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
    /*  You may use all basic functions, for a complete list consult the ADOL-C manuel */


    /* Chain Wood
    #   Source:  problem 8 in
    #   A.R.Conn,N.I.M.Gould and Ph.L.Toint,
    #   "Testing a class of methods for solving minimization
    #   problems with simple bounds on their variables,
    #   Mathematics of Computation 50, pp 399-430, 1988.
    */

    for(i =1; i<n/2-2; i++)
    {
        fad = fad +
              100*pow((x[2*i]-pow(x[2*i-1],2)),2) +
              pow((1.0-x[2*i-1]),2) +
              90*pow((x[2*i+2]-pow(x[2*i+1],2)),2) +
              pow((1.0-x[2*i+1]),2) +
              10*pow((x[2*i]+x[2*i+2]-2.0),2) +
              pow((x[2*i]-x[2*i+2]),2)/10;
    }
    return(fad);
}

template double chainwood<double>(const double  *x, const int n);
template adouble chainwood<adouble>(const adouble  *x, const int n);
void chainwood_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++)
    {
        if(i%2==0)
            x_initial[i] =-2;
        else
            x_initial[i] =0;
    }
    x_initial[0] = -3;
    x_initial[1] = -1;
    x_initial[2] = -3;
    x_initial[3] = -1;
}