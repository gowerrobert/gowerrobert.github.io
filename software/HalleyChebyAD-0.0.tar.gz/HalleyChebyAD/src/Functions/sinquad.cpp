#include "setup_functions.h"


template <class indep_var>  indep_var sinquad(const indep_var * x, const int n)
{
    int  i, j;
    indep_var fad=1;
    indep_var fi=0;
    /*---------------------------------------------------------------------------------*/
    /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
    /*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
//   Source:   in CUTE  sinquad
//   N. Gould, private communication.
//   SIF input: N. Gould, Dec 1989.
    fad = pow((x[0]-1),4);
    for(i=1; i<n; i++)
        fad = fad+pow((sin(x[i]-x[n-1])-pow(x[1],2)+pow(x[i],2)),2);
    fad = fad+pow((pow(x[n-1],2)-pow(x[1],2)),2);

    return(fad);
}

template double sinquad<double>(const double  *x, const int n);
template adouble sinquad<adouble>(const adouble  *x, const int n);
void sinquad_initial_point ( double *x_initial, const int dimension){
    for(int i=0; i<dimension ; i++) x_initial[i] =0.1;
}