#include "LinAlgebra.h"
LinAlgebra::LinAlgebra()
{//ctor
// EnumStrings[0] = "CONJUGATEGRADIENTS"; EnumStrings[1] = "MINIMALRESIDUAL"; 
}
LinAlgebra::~LinAlgebra()
{//dtor
}
int LinAlgebra::solvesystem(const int max_iterations, const Graph * Mat, double *solution,  const  double * rhs,const  double precision, bool print_system_solve, const int linearsolver ){
   /** Where the type of system solve is determined, e.g., CG or MINRES or CGNR ...etc**/
   // solveMinRes( max_iterations, Mat,solution,  rhs, precision, print_system_solve );
   int state;
   switch (linearsolver)
   {
     case	CONJUGATEGRADIENTS :
       state = solveCG(max_iterations, Mat, solution, rhs, precision, print_system_solve);
       if(state <= 1) //       cout<<"CG state: "<<state<<endl;
	return(1); 
       return(0);
       
       break;
     default:
       state = solveMinRes(max_iterations, Mat, solution, rhs, precision,print_system_solve);
       if(0<=state <= 4)  //      cout<<"Minres state: "<<state<<endl;
	return(1);
       return(0);
       break;   
   }

 }
 int LinAlgebra::solveCG(const int max_iterations, const Graph * Mat, double *solution,  const  double * rhs, const double precision, bool print_system_solve)
{
  int length(Mat->N);  //(1) Define the length of the problem we want to solve
  Operator op(length,Mat);  //(2) Define the linear operator "op" we want to solve.
  int i;
  SimpleVector p(length);
  SimpleVector Ap(length);
  SimpleVector _solution(length);
  SimpleVector _rhs(length);
  _solution.CopyDouble(solution);
  /*Figure this out, zero sol start or not? */
  _solution =0;
  _rhs.CopyDouble(rhs);
  op.Apply(_solution,Ap);  //Ap = Mat*solution;
  // Force a zero solution to start 
  //cout<<"rhs: "; _rhs.Print();
   ConjugateGradients<SimpleVector> CG(max_iterations,precision, Ap, _solution,_rhs,p, print_system_solve);

  /*If negative curvature on first iteration, return x =p. Otherwise, do not update x! */
  for (i=0; i<max_iterations;i++){
    if(CG.get_state() == CG.NOT_FINISHED ){
      op.Apply(p,Ap);  //Ap = Mat*p;
      CG.step(Ap,p);
    }
    else
      break;
  }
  if(i ==1 && CG.get_state() == CG.NEGATIVE_CURVATURE){
   // cout<<"Negative curv iter =1"<<endl;
    _rhs.ToDouble(solution);
    
  }else
      CG.x.ToDouble(solution);
  

  /*print_array(solution, length); 
  cout<<CG.getTextForEnum(CG.get_state())<<endl;//*/
  return(CG.get_state());
}
int LinAlgebra::solveMinRes( const int max_iterations, const Graph * Mat, double *solution,  const  double * rhs,  double precision, const bool show)
{
  int length(Mat->N); //(1) Define the length of the problem we want to solve
  Operator op(length,Mat); //(2) Define the linear operator "op" we want to solve.
  SimpleVector _solution(length);
 // _solution.CopyDouble(solution);
  SimpleVector _rhs(length); 
  _rhs.CopyDouble(rhs); //(4) Define the "rhs" as "rhs = op*sol"
  Preconditioner * prec = NULL;//(5) We don't use any preconditioner. Let prec be a null pointer.
  _solution = 0; //(6) Use an identically zero initial guess
  double shift(0); //(7) Set the minres parameters
  int max_iter(max_iterations);
  int istop = MINRES(op, _solution, _rhs, prec, shift, max_iter, precision, show); //(8) Solve the problem with minres
  _solution.ToDouble(solution);
  return(istop);
}
/* int LinAlgebra::solveCGNR(const int max_iterations, const Graph * Mat, double *solution,  const  double * rhs, const double precision)
{ 
  int length(Mat->N);//(1) Define the length of the problem we want to solve
  Operator op(length,Mat);//(2) Define the linear operator "op" we want to solve.
  int STATE;
  int i;
  SimpleVector p(length);
  SimpleVector Ap(length);
  SimpleVector _solution(length);
  SimpleVector Arhs(length);
  _solution.CopyDouble(solution);
  Arhs.CopyDouble(rhs);
  
  op.Apply(Arhs,Arhs);
  cout<<"_solution: "; _solution.Print();
  op.Apply(_solution,Ap);  //Ap = Mat*solution;
  op.Apply(Ap,Ap);  //Ap = Mat*Mat*solution;
  cout<<"AAsol: "; Ap.Print();
  cout<<"Arhs: "; Arhs.Print();
  ConjugateGradients<SimpleVector> CG(max_iterations,precision, Ap, _solution,Arhs,p);
  
  for (i=0; i<max_iterations;i++){
    if(CG.get_state() == CG.NOT_FINISHED ){
      op.Apply(p,Ap);  //Ap = Mat*p;
      cout<<"Ap: "; Ap.Print();
      op.Apply(Ap,Ap);  //Ap = Mat*Mat*p;
      cout<<"AAp: "; Ap.Print();
      CG.step(Ap,p);
    }
    else
      break;
  }
  CG.print();
  _solution.ToDouble(solution);
  
} **/
void LinAlgebra::sum(double * lhs, const double *rhs, int dimension)
{
    for(int i = 0; i< dimension; i++)
        lhs[i] = lhs[i] + rhs[i];
}
void LinAlgebra::subtract(double * lhs,const  double *rhs, int dimension)
{
    for(int i = 0; i< dimension; i++)
        lhs[i] = lhs[i] - rhs[i];
}
void LinAlgebra::copyvec(double *lhs,const  double * rhs, int dimension){
    for(int i = 0; i< dimension; i++)
        lhs[i] = rhs[i];
}
double LinAlgebra::norm(const double * x, int dimension)
{
    double norm_out =0;
    for(int i = 0; i< dimension; i++)
        norm_out += pow(x[i],2);
    norm_out = pow(norm_out,0.5);
}
void LinAlgebra::mult_scalar(double * x, int dimension, const double scal){
    for(int i=0; i< dimension; i++)
         x[i] = scal*x[i];
   // return(x);
}
double LinAlgebra::inner_prod(const double * x, const double *y, int dimension){
    double tot =0;
    for(int i=0; i< dimension; i++)
         tot += y[i]*x[i];
    return(tot);
}