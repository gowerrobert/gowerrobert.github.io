#include "NewtonsMethod.h"
/** NewtonsMethod with line search. Son of UncOpt class. Only implements the methodstep */
NewtonsMethod::~NewtonsMethod()
{
    //cout<<"called Newton Destructor"<<endl;
}
NewtonsMethod::NewtonsMethod(const int dimension_int, const double precision_in, const  bool print_it):
    UncOpt(dimension_int, precision_in, "NewtonsMethod", print_it)
    {}
int NewtonsMethod::methodstep(){
    int system_output;
    double inexact_prec;
    //cout<<"grad"<<endl;
    //LinAlg.print_array(Deriv.Gradient,dimension);
    LinAlg.copyvec(temp_use,Deriv.Gradient,dimension);
    LinAlg.mult_scalar(temp_use, dimension, -1.0);
    // Starting point for CG iteration
    LinAlg.copyvec(descent, Deriv.Gradient,dimension);
   // rhsnorm =LinAlg.norm(temp_use,dimension);
  //  rhsnorm = min(system_precision*pow(rhsnorm,1.1),0.3);
  inexact_prec = inexact_solve_precision(*Deriv.Gradient); // Get system solve desired precision
  //cout<<"NEwton"<<endl;
   system_output = LinAlg.solvesystem(max_system_iter, Deriv.HessianGraph,descent, temp_use,inexact_prec,  print_system_solve, linear_solver_type);     //Solve system and store solution in descent
return(system_output);
}
