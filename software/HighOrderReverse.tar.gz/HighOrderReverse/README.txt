****************************************
What is HighOrderReverse?
******************************************

An additional package of ADOL-C that uses reverse mode to calculate large sparse instances of the Hessian matrix, it's sparsity pattern
and a direction derivative of the Hessian matrix, in particular it includes
->reverse_hessian() Calculates Hessians  [1]
->sparsity_pattern() Calculate the sparsity pattern of Hessian [2]
->reverse_tensorv() Calculates a directional derivative of the Hessian matrix [3]

See HighOrderReverse/Examples/README.txt for detailed inputs and outputs of the above functions.
To install HighOrderReverse one must first download and unpack a version 2.3.0 or above of ADOL-C, but
do not install. Tests have mainly been carried out with ADOL-C-2.3.0 , ADOL-C-2.4.0 and ADOL-C-2.4.1

Installation also works with ADOL-C-2.5.0 though the example in HighOrderReverse/Examples/RefereeExamples/main.cpp
currently does not work due to a change functioning and a bug in ADOL-C-2.5.0.

Other required packages are autoconf, libtools, g++ and gcc.

*******************************************
Installing
*******************************************
To install the HighOrderReverse Package please do following

1) Unzip HighOrderReverse
2) Move the folder HighOrderReverse into ADOL-C-(version)/ThirdParty/
3) cd into ADOL-C-(version)/ThirdParty/HighOrderReverse
4) Run the Python script install.py by writting the command line
    $ python install.py
5) cd into the top folder ADOL-C-(version)
6) Run the autoreconf tools
    $ autoreconf --force --install
(NOTE: Autoconf version 2.67 or higher is required)
7) Proceed with standard ADOL-C installation, e.g,
    cd into 'ADOL-C-(version)/' then run the following
    $./configure
    $make
    $make install   

********************************************
Running and Linking
********************************************
No additional linking is required in relation to the standard ADOL-C linking procedure. Please see

HighOrderReverse/Examples/ToyExample/

where you will find an example  main.cpp and makefile. To reproduce the tests presented in [3], please see

HighOrderReverse/Examples/RefereeExample/

To compile and run these ready made example, please see the additional README.txt in

HighOrderReverse/Examples/



*******************************************
Citations
******************************************
When citing this software, or it's methodology, please cite

[1] Gower, R. M., & Mello, M. P. (2012).
A new framework for the computation of Hessians. Optimization Methods and Software, 27(2), 251–273. doi:10.1080/10556788.2011.580098

[2] Gower, R. M., & Mello, M. P. (2012).
Computing the Sparsity Pattern of Hessians using Automatic Differentiation. ACM Trans. Math. Software (to Appear), 1–16.

[3] Gower, R., & Gower, A. (2013). Higher-order Reverse Automatic Differentiation with emphasis on the third-order. (pp. 1–22).
http://arxiv.org/abs/1309.5479
