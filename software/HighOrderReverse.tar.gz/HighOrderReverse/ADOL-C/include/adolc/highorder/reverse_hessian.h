
#if !defined(adolc_highorder_reverse_hess)
#define adolc_highorder_reverse_hess 1

#include <iostream>
#include <adolc/common.h>
#include <adolc/highorder/graph_blocks.h>
BEGIN_C_DECLS

/****************************************************************************/
/*                                                                 tape_doc */
/* tape_doc(tag, m, n, x[n], y[m])                                          */

// Make a class out of these methods. Make better use of intersecting code between them.

ADOLC_DLL_EXPORT int reverse_hessian(short, double *x, double ** grad, Graph ** E, int, int * options);
ADOLC_DLL_EXPORT int reverse_hessian_lag(short, double *x, double *la, Graph ** E, int n, int m, int repeat);
ADOLC_DLL_EXPORT int reverse_hessian_lag_3(short tape_num, double *x, double *la, int * nnz, int ** row, int ** col,
					 double **val, int N, int M, int repeat );
ADOLC_DLL_EXPORT int sparsity_pattern(short,  Graph **, int);
END_C_DECLS
#endif
