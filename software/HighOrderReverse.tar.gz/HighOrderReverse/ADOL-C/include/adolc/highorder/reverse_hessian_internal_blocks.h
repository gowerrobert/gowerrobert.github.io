
//#if !defined(adolc_reverse_internal)
//#define adolc_reverse_internal 1

#include <adolc/common.h>
#include <adolc/highorder/graph_blocks.h>
#include <adolc/highorder/translate_tape.h>
#include <vector>
BEGIN_C_DECLS
//#include <tapedoc/RevsereHessian_internal.h>
#define Lin 0
#define NonL 1
#define BiL 2
#define Not_son -1

using namespace std;

int reverse_hessian_internal_blocks(opt_list * v,Graph * v_values, double * grad, Graph *, int n);
//int read_opt_list(opt_list * vlist,Graph * vals);
//int read_tape_doc(int max_active,Graph values);
int derivative_info(opt * v, deriv_info * der, Graph * values);
int increment_edge(int vi, int x, int y, double ww,  Graph * E, Block * reused_node_block);
int create_edges(opt * aux, deriv_info * der, double Adj, Graph * E, Block * reused_node_block);
void pushing(opt * v, deriv_info * der, Graph * E, Block * reused_node_block);
void  push_edge(int xx, double ww, opt * v, deriv_info * der, Graph * E, Block * reused_node_block);
void calculate_adjoint(opt * v, deriv_info* der, double * Adjoints);
void reverse_hessian_iteration(  opt * aux,   deriv_info * der, double * Adjoints, Graph * values, Graph *E, Block * reused_node_block);
double get_graph_last_in_value(Graph * lastvalues, int vi, int target);
/*enum OPCODES {
death_not,    //  0
assign_ind,   //  1
assign_dep,   //  2
assign_a,     //  3
assign_d, //  4
eq_plus_d,    //  5
eq_plus_a,    //  6
eq_min_d, //  7
eq_min_a, //  8
eq_mult_d,    //  9
eq_mult_a,    //  10
plus_a_a, //  11
plus_d_a, //  12
min_a_a,  //  13
min_d_a,  //  14
mult_a_a, //  15
mult_d_a, //  16
div_a_a,  //  17
div_d_a,  //  18
exp_op,   //  19
cos_op,   //  20
sin_op,   //  21
atan_op,  //  22
log_op,   //  23
pow_op,   //  24
asin_op,  //  25
acos_op,  //  26
sqrt_op,  //  27
asinh_op, //  28
acosh_op, //  29
atanh_op, //  30
gen_quad, //  31
end_of_tape,  //  32
start_of_tape,    //  33
end_of_op,    //  34
end_of_int,   //  35
end_of_val,   //  36
cond_assign,  //  37
cond_assign_s,    //  38
take_stock_op,    //  39
assign_d_one, //  40
assign_d_zero,    //  41
incr_a,   //  42
decr_a,   //  43
neg_sign_a,   //  44
pos_sign_a,   //  45
min_op,   //  46
abs_val,  //  47
eq_zero,  //  48
neq_zero, //  49
le_zero,  //  50
gt_zero,  //  51
ge_zero,  //  52
lt_zero,  //  53
eq_plus_prod, //  54
eq_min_prod,  //  55
erf_op,   //  56
ceil_op,  //  57
floor_op, //  58
ext_diff, //  59
ignore_me,    //  60
};*/

END_C_DECLS

//#endif
