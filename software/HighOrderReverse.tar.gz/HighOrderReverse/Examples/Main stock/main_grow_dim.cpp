#define ARRAY_SIZE 100
#define NUM_FUNCS 21

#include <iostream>
using std::ofstream;
#include <string.h>
#include <stdio.h>
#include <sys/time.h>
#include <math.h>
#include <sys/types.h>
#include "../function_input.h"
#include <adolc.h>
#include <vector>
#include <iomanip>
#include <adolc.h>
#include <adolc_sparse.h>

using namespace std;

void setup_func_pointer(adouble (*funcArr2[])(adouble *, int), string func_names[]);

double tape_pattern_time( adouble  (*pt2Func)(adouble *, int),  string func_name, int tape_num, int N,
			  double * x, adouble *xp, double y, adouble yp,  bool print_it){
  int i,j;
  struct timeval start, end;
  long mtime, seconds, useconds;
  Graph *H_pat;
  H_pat = NULL;
  unsigned int  **HP=NULL;                /* compressed block row storage */
  HP = (unsigned int **) malloc(N*sizeof(unsigned int*));
  
  trace_on(tape_num);
  
  for(i=0; i<N ;i++) 
  {
    xp[i] <<= x[i];				  // active independs        //  
  } 
  
  yp = pt2Func(xp, N);
  yp >>= y;
  
  trace_off();
  
  
  gettimeofday(&start, NULL);
  Sparsity_pattern( tape_num,  &H_pat,  N);
  gettimeofday(&end, NULL);
  seconds  = end.tv_sec  - start.tv_sec;
  useconds = end.tv_usec - start.tv_usec;
  mtime = ((seconds) * 1000 + useconds/1000.0) + 0.5;
  printf("%d , %ld ", N, mtime);
  
  gettimeofday(&start, NULL);
  //hess_pat(tape_num, N, x, HP, 0);
  gettimeofday(&end, NULL);
  seconds  = end.tv_sec  - start.tv_sec;
  useconds = end.tv_usec - start.tv_usec;
  mtime = ((seconds) * 1000 + useconds/1000.0) + 0.5;
  printf(" ,%ld\n",  mtime);
  
  if(print_it){
    H_pat->print_square(1);  
    printf("\n");
    printf("Sparsity pattern of Hessian: \n");
    for (i=0;i<N;i++) {
      printf(" %d: ",i);
      for (j=1;j<= (int) HP[i][0];j++)
	printf(" %d ",HP[i][j]);
      printf("\n");
    }
    printf("\n");
    
  }
  
  delete H_pat;
  for (i=0;i<N;i++) 
    free (HP[i]);
  free(HP);  //*/
}

int main()
{
  struct timeval start, end;
  long mtime, seconds, useconds;    
  int  N,M;	int i,j;
  long double c0,c1, Mytime;
  int tape_num =1;
  cout<<"Dimension:"<<endl;
  cin>>N;
  
  //----------------------------------------*/
  // Setting up the array of function pointers and their names   //
  /*--------------------------------------------------------------------------*/
  
  adouble (*funcArr2[NUM_FUNCS])(adouble *, int) = {NULL};
  string func_names[NUM_FUNCS];
  setup_func_pointer(funcArr2, func_names);
  //----------------------------------------*/
  // Variables associated to function calculation and the functions tape!
  /*--------------------------------------------------------------------------*/
  adouble * xp;
  double * x;
  adouble yp;
  double y;
  int fn = 14;
  
  /*--------------------------------------------------------------------------*/
  /*---------------Taping the function---------------------------------------*/
  

  
  
  cout<<func_names[fn];
  printf(" , edge\_pushing\_sp, hess\_pat\n");
  for(i=0; i<5; i++ ){ //NUM_FUNCS
    x = new double [N]; 
    xp = new adouble [N];
    
    for(j=0; j<N; j++)
      x[j] =   ((double)j +1)/N;
    
    tape_num =i;
    tape_pattern_time( funcArr2[fn],func_names[fn], tape_num, N, x, xp, y, yp, (bool)0);
    N = N+10000; 
    delete [] x;
    delete [] xp;
  }
  
  return 0;
  
}


void setup_func_pointer(adouble (*funcArr2[])(adouble *, int), string func_names[]){
  /*
  funcArr2[14] = morebv; 
  funcArr2[2] = sinquad;
  funcArr2[10] = brybnd;
  funcArr2[18] = chainros_trigexp;
  funcArr2[17] = ncvxbqp1;; // */
  
  
  funcArr2[0] = pspdoc;
  func_names[0]= "pspdoc";
  funcArr2[1] = scon1dls;
  func_names[1] = "scon1dls";
  funcArr2[2] = sinquad;
  func_names[2] = "sinquad";
  funcArr2[3] = nondquar;
  func_names[3] = "nondquar";
  funcArr2[4] = bc4;
  func_names[4] = "bc4";  
  funcArr2[5] = cragglevy;
  func_names[5] = "cragglevy";  
  funcArr2[6] = augmlagn;
  func_names[6] = "augmlagn";  
  funcArr2[7] = arwhead;
  func_names[7] = "arwhead";  
  funcArr2[8] = cosine;
  func_names[8] = "cosine";  
  funcArr2[9] = bdexp;
  func_names[9] = "bdexp";  
  funcArr2[10] = brybnd;
  func_names[10] = "brybnd";  
  funcArr2[11] = bdqrtic;
  func_names[11] = "bdqrtic";  
  funcArr2[12] = lminsurf;
  func_names[12] = "lminsurf";  
  funcArr2[13] = chainwood;
  func_names[13] = "chainwood";  
  funcArr2[14] = morebv;
  func_names[14] = "morebv";  
  funcArr2[15] = noncvxu2;
  func_names[15] = "noncvxu2";  
  funcArr2[16] = ncvxqp3;
  func_names[16] = "ncvxqp3";  
  funcArr2[17] = ncvxbqp1;
  func_names[17] = "ncvxbqp1";
  funcArr2[18] = chainros_trigexp;
  func_names[18] = "chainros_trigexp"; 
  funcArr2[19] = binary;
  func_names[19] = "binary"; 
  funcArr2[20] = toiqmerg;
  func_names[20] = "toiqmerg";   
  //*/
  
}

