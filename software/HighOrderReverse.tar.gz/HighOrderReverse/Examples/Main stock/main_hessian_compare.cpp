#include <iostream>
using std::ofstream;
#include <unistd.h>
#include <ios>
#include <fstream>
#include <string>
#include <stdio.h>
#include <math.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "../function_input.h"
#include <iomanip>
#include <adolc/adolc.h>

using namespace std;
void printmat(const char* kette, int n, int m, double** M);
void process_mem_usage(double& vm_usage, double& resident_set);
void compare_hessian_reverse(Graph * HG,   double **H_mat, int N);

int main()
{
  
  int  N,M;	int i,j,k,nz;
  int tape_num =1;
  cout<<"Dimension?"<<endl;
  cin>>N;
  Graph *HG;
  Graph *H_pat;
  double * gradient;
  /*Necessary flag for first run            */
  H_pat = NULL;
  HG = NULL;
  gradient = NULL;
  /* ---------------------------------------*/
  //----------------------------------------*/
  // Variables associated to function calculation and the functions tape!
  /*--------------------------------------------------------------------------*/
  adouble yp;
  double y;
  adouble * xp;
  
  double * x;
  x = new double [N]; 
  xp = new adouble [N];
  
  /*--------------------------------------------------------------------------*/
  /*---------------Taping the function---------------------------------------*/  
  for(j=0; j<N; j++)
    x[j] =   j+1;
  
  trace_on(tape_num);
  
  for(i=0; i<N ;i++) 
    xp[i] <<= x[i];				  // active independs        //  
    // You may also call any function in the folder ReverseHessian/EdgePushingToyExample/Functions   
    // e.g., 
    //  yp = function_input(xp, N); chainros_trigexp bdqrtic  augmlagn toiqmerg  brybnd  noncvxu2 sinquad
    yp = toiqmerg(xp, N);
  
  yp >>= y;
  
  trace_off();
  // Allocate the Graph, see previous example
  
  for(j=0; j<N; j++)
    x[j] =   j+1;
  
  
  sparsity_pattern( tape_num,  &H_pat,  N);
  reverse_hessian( tape_num,  x, &gradient,  &HG,  N, NULL);  
  HG->print();
  HG->print_square(1);
  
  
  double **H;
  H = myalloc2(N,N);
  hessian(tape_num,N,x,H);
  printmat(" H",N,N,H);
  printf("\n");
  
  //Checking they are equal
  compare_hessian_reverse(HG,   H,  N);
  
  
  delete [] x;
  delete [] xp;
  delete [] gradient;
  delete HG;
  delete H;
  return 0;
  
}

void compare_hessian_reverse( Graph * HG,   double **H_mat, int N){
  int i,j;
  int node, node_pos;
  double edge;
  bool fail =1;
  double eps = pow(10,-12);
  double diff;
  
  /*Sweeping nonzeros of HG*/
  for(i=0; i<N; i++){ 
    for(j=HG->get_first_position(i) ; j< HG->get_last_position(i)+1; j++){
      node = HG->get_neighbor_node(i,j); 
      edge = HG->get_edge_weight(i,j); 
      diff= abs((H_mat[i][node]- edge)/edge);
      if(diff>eps){
	cout<<"("<<i<<","<<node<<") "<<" edge "<<edge<<" "<<" H[i,node]: "<<H_mat[i][node]<<"  diff: "<<diff<<endl;
	fail =0;
      }
    }
  }
  /*Sweeping nonzeros of H_mat*/
  for(i=0; i<N; i++)
    for(j=0; j<i; j++)
      if(abs(H_mat[i][j]) > eps){
	node_pos = HG->get_neighbor_position(i,j);
	if(node_pos ==-1){
	  cout<<"("<<i<<","<<j<<")  Not in Graph!   H[i][node]: "<<H_mat[i][j]<<endl;
	  fail =0;
	}
	else{
	  edge = HG->get_edge_weight(i,node_pos); 
	  diff= abs((H_mat[i][j]- edge)/H_mat[i][j]);
	  if(diff>eps){
	    cout<<"("<<i<<","<<j<<") "<<" edge "<<edge<<" "<<" H[i][node]: "<<H_mat[i][j]<<"  diff: "<<diff<<endl;
	    fail =0;
	  }
	}
      }
      
      
      if(fail==0)
	cout<<"TEST FAILED with precision: "<<eps<<endl;
      else
	cout<<"TEST SUCCESS with precision: "<<eps<<endl; 
      
}
void printmat(const char* name, int m, int n, double** M) {
  int i,j;
  
  printf("%s \n",name);
  for(i=0; i<m ;i++) {
    printf("\n %d: ",i);
    for(j=0;j<n ;j++)
      printf(" %10.4f ", M[i][j]);
  }
  printf("\n");
}
