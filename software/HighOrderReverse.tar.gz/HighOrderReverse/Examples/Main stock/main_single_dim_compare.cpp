#include <iostream>
using std::ofstream;
#include <string.h>
#include <stdio.h>
#include <sys/time.h>
#include <math.h>
#include <sys/types.h>
#include "../function_input.h"
#include <adolc/adolc.h>
#include <vector>
#include <iomanip>
#include <adolc/adolc_sparse.h>

using namespace std;
#define ARRAY_SIZE 100
#define NUM_FUNCS 21
#define IS_ADOLC2_3 1

double tape_pattern_time( adouble  (*pt2Func)(adouble *, int),  string func_name, int tape_num, int N,
			  double * x, adouble *xp, double y, adouble yp,  bool print_it){
  int i,j;
  struct timeval start, end;
  long mtime, seconds, useconds;
  unsigned int  **HP=NULL;                /* compressed block row storage */
  HP = (unsigned int **) malloc(N*sizeof(unsigned int*));
  
  trace_on(tape_num);
  
  for(i=0; i<N ;i++) 
  {
    xp[i] <<= x[i];				  // active independs        //  
  } 
  
  yp = pt2Func(xp, N);
  yp >>= y;
  
  trace_off();
  
  
  cout<<func_name;
  gettimeofday(&start, NULL);
  hess_pat(tape_num, N, x, HP, 0);
  gettimeofday(&end, NULL);
  seconds  = end.tv_sec  - start.tv_sec;
  useconds = end.tv_usec - start.tv_usec;
  mtime = ((seconds) * 1000 + useconds/1000.0) + 0.5;
  printf(" ,%ld\n",  mtime);
  
  if(print_it){ 
    printf("\n");
    printf("Sparsity pattern of Hessian: \n");
    for (i=0;i<N;i++) {
      printf(" %d: ",i);
      for (j=1;j<= (int) HP[i][0];j++)
	printf(" %d ",HP[i][j]);
      printf("\n");
    }
    printf("\n");
  } 
  for (i=0;i<N;i++) 
    free (HP[i]);
  free(HP);  //*/
}

int main()
{
  struct timeval start, end;
  long mtime, seconds, useconds;    
  int  N,M;	int i,j;
  long double c0,c1, Mytime;
  int tape_num =1;
  cout<<"Dimension:"<<endl;
  cin>>N;
  
  //----------------------------------------*/
  // Setting up the array of function pointers and their names   //
  /*--------------------------------------------------------------------------*/
  
  adouble (*funcArr2[NUM_FUNCS])(adouble *, int) = {NULL};
  string func_names[NUM_FUNCS];
  setup_func_pointer(funcArr2, func_names);
  //----------------------------------------*/
  // Variables associated to function calculation and the functions tape!
  /*--------------------------------------------------------------------------*/
  adouble * xp;
  double * x;
  adouble yp;
  double y;
 
 // cout<<func_names[19];
 // printf(" ,  hess\_pat\n");
  for(i=18; i<NUM_FUNCS; i++ ){ //NUM_FUNCS
    x = new double [N]; 
    xp = new adouble [N];
    
    for(j=0; j<N; j++)
      x[j] =   ((double)j +1)/N;
    
    tape_num =i;
    tape_pattern_time( funcArr2[i],func_names[i], tape_num, N, x, xp, y, yp, (bool)0);
   // N = N+10000; 
    delete [] x;
    delete [] xp;
  }
  
  return 0;
  
}




