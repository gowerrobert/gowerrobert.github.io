#include "../function_input.h"


adouble pspdoc(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

// Source: problem 47 in   in CUTe pspdoc
//   Ph.L. Toint,
//   "Test problems for partially separable optimization and results
//for the routine PSPMIN",
//   Report 83/4, Department of Mathematics, FUNDP (Namur, B), 1983.
int NGS = n -2;
for(i=0; i<NGS-1; i++)
    fad = fad + sqrt(pow(x[i],2)+pow((x[i+1]-x[i+2]),2)+1);

    return(fad);
}
double pspdoc(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            

// Source: problem 47 in   in CUTe pspdoc
//   Ph.L. Toint,
//   "Test problems for partially separable optimization and results
//for the routine PSPMIN",
//   Report 83/4, Department of Mathematics, FUNDP (Namur, B), 1983.
int NGS = n -2;
for(i=0; i<NGS-1; i++)
    fad = fad + sqrt(pow(x[i],2)+pow((x[i+1]-x[i+2]),2)+1.0);
return(fad);
}



