#include "../function_input.h"

adouble feval_ad(adouble *x, int N_)
{
  // return the value of the objective function
  adouble obj_value = 0.;
  adouble a1, a2;

  for (int i=0; i<N_-1; i++) {
    a1 = x[i]*x[i]-x[i+1];
    a2 = x[i] - 1.;
    obj_value =obj_value+ 100.*a1*a1 + a2*a2;
  }
 
  return obj_value;
}

/***************************************************************************/

void ceval_ad(adouble *x, adouble *c, int N_) {

  for (int i=0; i<N_-2; i++) {
    c[i] = 3.*pow(x[i+1],3.) + 2.*x[i+2] - 5.
           + sin(x[i+1]-x[i+2])*sin(x[i+1]+x[i+2]) + 4.*x[i+1]
           - x[i]*exp(x[i]-x[i+1]) - 3.;
  }
}
   
    
adouble chainros_trigexp(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */

//Name: Chained Rosenbrook function with Trigonometric and exponencial constraints.
/* Problem 5.1 of
Ladislav Luksan, Jan Vlcek:
Sparse and partially separable test problems for unconstrained and equality constrained optimization.
Tech. Rep. V-767, ICS AS CR, December 1998
//*/
//3-5 D
int N_ = n/2;
int M_ = N_ -2;

//cout<<"N_, M_ ="<<N_<<", "<<M_<<endl;

adouble * cad;
cad = new adouble[M_];

fad = feval_ad(x, N_);
ceval_ad(x,cad,N_);

for(i=0;i<M_;i++)
  fad = fad + x[N_+i]*cad[i];

return(fad);
}
double chainros_trigexp(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            
//Name: bdexp   
//3-5 D
cout<<"NOT PROGRAMMED"<<endl;


return(fad);
}



