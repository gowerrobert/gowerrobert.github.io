#include "../function_input.h"


adouble chainwood(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */


/* Chain Wood
#   Source:  problem 8 in
#   A.R.Conn,N.I.M.Gould and Ph.L.Toint,
#   "Testing a class of methods for solving minimization 
#   problems with simple bounds on their variables, 
#   Mathematics of Computation 50, pp 399-430, 1988.
*/

for(i =1; i<n/2-2; i++){
	fad = fad +
	100*pow((x[2*i]-pow(x[2*i-1],2)),2) +
	pow((1.0-x[2*i-1]),2) +
	90*pow((x[2*i+2]-pow(x[2*i+1],2)),2) +
	pow((1.0-x[2*i+1]),2) +
	10*pow((x[2*i]+x[2*i+2]-2.0),2) +
	pow((x[2*i]-x[2*i+2]),2)/10;
}
    return(fad);
}
double chainwood(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            
/* Chain Wood
#   Source:  problem 8 in
#   A.R.Conn,N.I.M.Gould and Ph.L.Toint,
#   "Testing a class of methods for solving minimization 
#   problems with simple bounds on their variables, 
#   Mathematics of Computation 50, pp 399-430, 1988.
*/

for(i =1; i<n/2-2; i++){
	fad = fad +
	100*pow((x[2*i]-pow(x[2*i-1],2)),2) +
	pow((1.0-x[2*i-1]),2) +
	90*pow((x[2*i+2]-pow(x[2*i+1],2)),2) +
	pow((1.0-x[2*i+1]),2) +
	10*pow((x[2*i]+x[2*i+2]-2.0),2) +
	pow((x[2*i]-x[2*i+2]),2)/10;
}


return(fad);
}



