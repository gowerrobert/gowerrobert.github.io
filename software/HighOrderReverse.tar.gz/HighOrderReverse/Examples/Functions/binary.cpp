#include "../function_input.h"

adouble binary_inter(adouble * x, int n, int left, int right);

adouble binary(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
  
  if(n%4 != 0) 
    cout<<"Calling binary function with n not even divisible by 4!"<<endl;
  /*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
/*
binary example
*/
   fad= binary_inter( x,  n, 0, n);

    return(fad);
}

adouble binary_inter(adouble * x, int n, int left, int right){
  adouble fad;
  if(right-left>4){
       fad= binary_inter( x,  n, left, (left+right)/2);
       fad = fad+ binary_inter( x,  n, (left+right)/2, right);
  }
  else{
      fad =  x[left]*x[left+1]+x[left+2]*x[left+3];
  }
      return (fad);
  
}
double binary(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            
cout<<"NOT PROGRAMMED"<<endl;

return(fad);
}



