#include "../function_input.h"


adouble augmlagn(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
  
/*
An augmented Lagragian for a generalizaed hock and schittkowski
80-th problem   name: AUGMLAGN
 Test examples for nonlinear programming codes
Journal	Journal of Optimization Theory and Applications
W. Hock1 and K. Schittkowski1
i = 5, 10 ,15, 20...
*/
//THIS IS A TRIANGULAR MATRIX!
double lambda1, lambda2, lambda3, p;
lambda1 = -0.002008;
lambda1 = -0.001900;
lambda1 = -0.000261;
p =20;
fi=0;
   for(i=1; i<n-4; i=i+5){
	fad = fad+ exp(x[i]*x[i+1]*x[i+2]*x[i+3]*x[i+4]);
	fi=0;
	for(j=0; j<5; j++)
	    fi = fi+ pow(x[i+j],2) -10 -lambda1;
	fad = fad + pow(fi,2)+
	pow(x[i+1]*x[i+2] - 5*x[i+3]*x[i+4] - lambda2,2) +
	pow( pow(x[i],3) + pow(x[i+1],3) +1 -lambda3, 2) +
	exp(x[i]*x[i+1]*x[i+2]*x[i+3]*x[i+4]);
	//+0.5*p*()
   }
    return(fad);
}
double augmlagn(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            
  
double lambda1, lambda2, lambda3, p;
lambda1 = -0.002008;
lambda1 = -0.001900;
lambda1 = -0.000261;
p =20;
fi=0;
   for(i=1; i<n-4; i=i+5){
	fad = fad+ exp(x[i]*x[i+1]*x[i+2]*x[i+3]*x[i+4]);
	fi=0;
	for(j=0; j<5; j++)
	    fi = fi+ pow(x[i+j],2) -10 -lambda1;
	fad = fad + pow(fi,2)+
	pow(x[i+1]*x[i+2] - 5*x[i+3]*x[i+4] - lambda2,2) +
	pow( pow(x[i],3) + pow(x[i+1],3) +1 -lambda3, 2) +
	exp(x[i]*x[i+1]*x[i+2]*x[i+3]*x[i+4]);
	//+0.5*p*()
   }
return(fad);
}