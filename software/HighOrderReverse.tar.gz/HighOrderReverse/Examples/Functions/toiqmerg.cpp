#include "../function_input.h"


adouble toiqmerg(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
  /*---------------------------------------------------------------------------------*/
  /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
  /*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
  
 /* //minimize f:
  //NAME: Toint Quadratic Merging problem
  //Luksan, L., Vlcek, J.: Sparse and partially separable test problems
  for unconstrained and equality constrained optimization. ICS AS CR V-767, Academy of Sciences of the Czech Republic (1998)
  //arrow + 3-7 D //*/
  
  for(i=0; i<n-4; i++){
    j = i%6;
    switch(j){
      case 1:
	fad = fad +pow(( x[i]+3*x[i+1]*(x[i+2]-1) +pow(x[i+3],2) -1),2);
	break;
      case 2:
	fad = fad + pow(pow(x[i]+x[i+1],2) +pow(x[i+2]-1,2) -x[i+3]-3,2);
	break;
      case 3:
	fad = fad + pow(x[i]*x[i+1] -x[i+2]*x[i+3],2);
	break;
      case 4:
	fad = fad + pow(2*x[i]*x[i+2] +x[i+1]*x[i+3] -3,2);
	break;
      case 5:
	fad = fad + pow(pow(x[i]+x[i+1]+x[i+2] +x[i+3],2) +pow(x[i]-1,2),2);
	break;
      case 0:
	fad = fad + pow((x[i]*x[i+1]*x[i+2]*x[i+3]) +pow((x[i+3]-1),2)-1,2);
	break;
      default:
	break;
    }
  }
  return(fad);
}
double toiqmerg(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
  /*---------------------------------------------------------------------------------*/
  /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
  /*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
  /*---------------------------------------------------------------------------------*/            
  
  for(i=0; i<n-4; i++){
    j = i%6;
    switch(j){
      case 1:
	fad = fad +pow(( x[i]+3*x[i+1]*(x[i+2]-1) +pow(x[i+3],2) -1),2);
	break;
      case 2:
	fad = fad + pow(pow(x[i]+x[i+1],2) +pow(x[i+2]-1,2) -x[i+3]-3,2);
	break;
      case 3:
	fad = fad + pow(x[i]*x[i+1] -x[i+2]*x[i+3],2);
	break;
      case 4:
	fad = fad + pow(2*x[i]*x[i+2] +x[i+1]*x[i+3] -3,2);
	break;
      case 5:
	fad = fad + pow(pow(x[i]+x[i+1]+x[i+2] +x[i+3],2) +pow(x[i]-1,2),2);
	break;
      case 0:
	fad = fad + pow((x[i]*x[i+1]*x[i+2]*x[i+3]) +pow((x[i+3]-1),2)-1,2);
	break;
      default:
	break;
    }
  }
  
  return(fad);
}



