
#include "../function_input.h"
adouble arwhead(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
  /*---------------------------------------------------------------------------------*/
  /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
  /*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
  
  //   Source: Problem 55 in
  //   A.R. Conn, N.I.M. Gould, M. Lescrenier and Ph.L. Toint,
  //   "Performance of a multifrontal scheme for partially separable
  //   optimization",
  //   Report 88/4, Dept of Mathematics, FUNDP (Namur, B), 1988.
  
  //   SIF input: Ph. Toint, Dec 1989.
  
  //   classification OUR2-AN-V-0
  //NAME: arwhead
  //arrow head, Coloring is better.
  fad =0;
  fi=0;
  for(i=1; i<n-1; i++)
    fad = fad-4*x[i]+3.0+ pow((pow(x[i],2)+pow(x[n-1],2)),2); 
  
  return(fad);
}
double arwhead(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
  int N =n;
  /*---------------------------------------------------------------------------------*/
  /*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
  /*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
  /*---------------------------------------------------------------------------------*/            
  
  //   Source: Problem 55 in
  //   A.R. Conn, N.I.M. Gould, M. Lescrenier and Ph.L. Toint,
  //   "Performance of a multifrontal scheme for partially separable
  //   optimization",
  //   Report 88/4, Dept of Mathematics, FUNDP (Namur, B), 1988.
  
  //   SIF input: Ph. Toint, Dec 1989.
  
  //   classification OUR2-AN-V-0
  //NAME: arwhead
  //arrow head, Coloring is better.
  fad =0;
  fi=0;
  for(i=1; i<n-1; i++)
    fad = fad-4*x[i]+3.0+ pow((pow(x[i],2)+pow(x[n-1],2)),2); 
  return(fad);
}



