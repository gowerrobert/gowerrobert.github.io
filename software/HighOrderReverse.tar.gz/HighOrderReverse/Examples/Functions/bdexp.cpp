#include "../function_input.h"


adouble bdexp(adouble * x, int n){
  int  i, j;
  adouble fad=1;
  adouble fi=0;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel */
//Name: bdexp   
//3-5 D
    int ngs = n-3;
//var x{1..N} := 1.0;

//minimize f:

   for(i=0; i<ngs; i++)
	 fad = fad + (x[i]+x[i+1])*exp((x[i]+x[i+1])*(-x[i+2]));

    return(fad);
}
double bdexp(double *x,int n){
  int  i, j;
  double fad =0;
  double fi;
/*---------------------------------------------------------------------------------*/
/*the one dimensional output variable is fad, in other words, f: R^n -> R. f(x) = fad */
/*  You may use all basic functions, for a complete list consult the ADOL-C manuel  */
/*---------------------------------------------------------------------------------*/            
//Name: bdexp   
//3-5 D
    int ngs = n-3;
//var x{1..N} := 1.0;

//minimize f:

   for(i=0; i<ngs; i++)
	 fad = fad + (x[i]+x[i+1])*exp((x[i]+x[i+1])*(-x[i+2]));


return(fad);
}



