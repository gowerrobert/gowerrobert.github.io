#include <adolc/adolc.h>
#include "../function_input.h"


adouble function_input(adouble * x, int n){
  int  i, j;
  adouble fad=0;
  fad = x[0]; 
  
  for (i=0; i<n-1; i++)
      fad = fad+x[i+1]*x[i]+sin(x[i]);
  return fad;
}
double function_input(double *x,int n){
  int  i, j;
  double fad =0;
  fad = x[0]; 
  
  for (i=0; i<n-1; i++)
    fad = fad+ x[i+1]*x[i] + sin(x[i]);
  return fad;
return(fad);
}



