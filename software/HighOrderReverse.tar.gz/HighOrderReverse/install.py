# -*- coding: utf-8 -*-
import glob
import os
import shutil

topfolder = '../../'
alreadycompiled = '# HighOrderReverse has been installed!\n'
ADOLCParent =0 
MakefileParent =0 
configureParent =0 
dirParent=os.listdir("../..")
lostwarning= "I'm in the wrong directory, can't find "

for fname in dirParent:
    if "ADOL-C" in fname:
       ADOLCParent = 1
    if "Makefile.am" in fname:
       MakefileParent = 1       
    if "configure.ac" in fname:
       configureParent = 1       

if ADOLCParent ==0:
        print lostwarning + "../../Makefile.am"
        quit()
if ADOLCParent ==0:
        print lostwarning + "../../ADOL-C"
        quit()
if ADOLCParent ==0:
        print lostwarning + "../../configure.ac"        
        quit()        
print "Apparantelly I'm in the right place"        
        	
# Adding two lines to configure.ac
print "Altering configure.ac \n"
src_configure_ac = "ADOL-C/src/tapedoc/Makefile"
include_configure_ac = "ADOL-C/include/adolc/tapedoc/Makefile"
newline_src_configure_ac = "                ADOL-C/src/tapedoc/Makefile\n                ADOL-C/src/highorder/Makefile\n"
newline_include_configure_ac = "                ADOL-C/include/adolc/tapedoc/Makefile\n                ADOL-C/include/adolc/highorder/Makefile\n"
rfile = open(topfolder + 'configure.ac')
rtext = rfile.readlines()
rfile.close()
counter =1;
for line in rtext:
    if counter ==2:
       if line == alreadycompiled:
	 print alreadycompiled
	 quit()
       break	 
    counter = counter +1
counter =1;    
os.remove(topfolder + 'configure.ac')
wfile = open(topfolder + 'configure.ac','w')
for line in rtext:
    if counter ==2:
       wfile.write(alreadycompiled)
       wfile.write(line)
    elif src_configure_ac in line:  
	wfile.write(newline_src_configure_ac) 
    elif include_configure_ac in line:	
	wfile.write(newline_include_configure_ac)    
    else: 	
	wfile.write(line)
    counter = counter +1
wfile.close()	

# Adding lines to ADOL-C/include/adolc/Makefile.am
include_makefile = topfolder + 'ADOL-C/include/adolc/Makefile.am'
print "Altering" + include_makefile + "\n"
include_makefile_subdir = "SUBDIRS = drivers tapedoc"
newline_include_makefile_subdir = "SUBDIRS = drivers tapedoc highorder\n"
rfile = open(include_makefile)
rtext = rfile.readlines()
rfile.close()
os.remove(include_makefile)
wfile = open(include_makefile,'w')
for line in rtext:
    if not include_makefile_subdir in line:
	wfile.write(line) 
    else: 	
	wfile.write(newline_include_makefile_subdir)
wfile.close()	

# Adding lines to /ADOL-C/Makefile.am 
ADOLC_makefile = topfolder + 'ADOL-C/Makefile.am'
print "Altering" + ADOLC_makefile + "\n"
src_lib_adds =  "src/tapedoc/libtapedoc.la" 
ammend_src_lib_adds = " src/highorder/libhighorder.la\n"  
rfile = open(ADOLC_makefile)
rtext = rfile.readlines()
rfile.close()
os.remove(ADOLC_makefile)
wfile = open(ADOLC_makefile,'w')
for line in rtext:
    if src_lib_adds in line:
	wfile.write(line.rstrip('\n') + ammend_src_lib_adds)
    else:
        wfile.write(line)
wfile.close()	

# Adding lines to ADOL-C/src/Makefile.am  
src_makefile = topfolder + 'ADOL-C/src/Makefile.am'
print "Altering" + src_makefile + "\n"
src_makefile_subdirs_1 = "= drivers sparse tapedoc"
src_makefile_subdirs_2 = "= drivers tapedoc"
src_makefile_la  = "tapedoc/libtapedoc.la"
new_src_makefile_subdirs_1 = "SUBDIRS              = drivers sparse tapedoc highorder\n"
new_src_makefile_subdirs_2 = "SUBDIRS              = drivers tapedoc highorder\n"  
ammend_src_makefile_la  = " highorder/libhighorder.la\n"
rfile = open(src_makefile)
rtext = rfile.readlines()
rfile.close()
os.remove(src_makefile)
wfile = open(src_makefile,'w')
for line in rtext:
    if src_makefile_subdirs_1 in line: 
	wfile.write(new_src_makefile_subdirs_1) 
    elif  src_makefile_subdirs_2 in line: 
	wfile.write(new_src_makefile_subdirs_2)
    elif src_makefile_la in line:
	wfile.write(line.rstrip('\n') + ammend_src_makefile_la)	
    else:
        wfile.write(line)
wfile.close()	

includefolder =  'ADOL-C/include/adolc/highorder/'
srcfolder =  'ADOL-C/src/highorder/'

dest_includefolder = topfolder +includefolder
dest_srcfolder = topfolder +srcfolder

# Altering /ADOL-C-(version)/ADOL-C/include/adolc/adolc.h
include_adolch = topfolder + 'ADOL-C/include/adolc/adolc.h'
print "Altering" + include_adolch + "\n"
tapedoc_include_adolch = "#include <adolc/tapedoc/tapedoc.h>"
highorder_include_adolch  = "#include <adolc/highorder/reverse_hessian.h>"
rfile = open(include_adolch)
rtext = rfile.readlines()
rfile.close()
os.remove(include_adolch)
wfile = open(include_adolch,'w')
for line in rtext:
    if tapedoc_include_adolch in line: 
        wfile.write(line)
        wfile.write('                                                                              \n')        
        wfile.write('/*--------------------------------------------------------------------------*/\n')
        wfile.write('/* interfaces to HighOrderReverse package */\n')
        wfile.write('#include <adolc/highorder/reverse_hessian.h>\n')
        wfile.write('#include <adolc/highorder/reverse_tensorv.h>\n')
        wfile.write('                                                                              \n')  
    else:
        wfile.write(line)
wfile.close()	

# Moving files
# Copying files into dest_includefolder
print "copying files into " + dest_includefolder
if not os.path.exists(dest_includefolder):
    os.makedirs(dest_includefolder)
dirList=os.listdir(includefolder)
for fname in dirList:
    filepath = includefolder +fname
    dst = dest_includefolder +fname
    print 'Moving ' + filepath + '\n to ' + dst
    shutil.copyfile(filepath, dst)
    
# Copying files into dest_includefolder
print "copying files into " + dest_srcfolder
if not os.path.exists(dest_srcfolder):
    os.makedirs(dest_srcfolder)
dirList=os.listdir(srcfolder)
for fname in dirList:
    if fname == ".deps" or fname == ".libs":
	continue
    filepath = srcfolder +fname
    dst = dest_srcfolder +fname
    print 'Moving ' + filepath + '\n to ' + dst
    shutil.copyfile(filepath, dst)
    
#Call autoconf and automake?
